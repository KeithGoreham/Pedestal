//////////////////////////////////////////////////////////////
// Implementation file for the function used to write out 
// the Pedestal application preferences to an external file.
//
// �2007 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//======================================================================
// WritePreferencesFile() - Function used to read preferences from an
// external .xml file.
//======================================================================
int WritePreferencesFile(void)
{
	char buffer[9];

	// Our Main node.
	XMLNode xMainNode = XMLNode::createXMLTopNode("pedestalApplicationPreferences");
	
	// Create our category nodes.
	XMLNode xDisplayPrefs    = xMainNode.addChild("displayPreferences");
	XMLNode xFullScreenPrefs = xMainNode.addChild("fullScreenPreferences");
	XMLNode xStereoPrefs     = xMainNode.addChild("stereoPreferences");

	//------------------------------------------------------------
	// Create nodes for all of the display preferences.
	//------------------------------------------------------------
	XMLNode xAppWinWidth = xDisplayPrefs.addChild("appWinWidth");
	sprintf(buffer, "%d", g_appWinWidth);
	xAppWinWidth.addText(buffer);

	XMLNode xAppWinHeight = xDisplayPrefs.addChild("appWinHeight");
	sprintf(buffer, "%d", g_appWinHeight);
	xAppWinHeight.addText(buffer);

	XMLNode xAppIsMaximized = xDisplayPrefs.addChild("appIsMaximized");
	if (g_isAppMaximized == false){xAppIsMaximized.addText("0");}
	else						  {xAppIsMaximized.addText("1");}

	XMLNode xAppWinBPPColor = xDisplayPrefs.addChild("appWinBPPColor");
	sprintf(buffer, "%d", g_appWinBPPColor);
	xAppWinBPPColor.addText(buffer);

	XMLNode xAppWinBPPDepth = xDisplayPrefs.addChild("appWinBPPDepth");
	sprintf(buffer, "%d", g_appWinBPPDepth);
	xAppWinBPPDepth.addText(buffer);

	XMLNode xAppWinBPPAlpha = xDisplayPrefs.addChild("appWinBPPAlpha");
	sprintf(buffer, "%d", g_appWinBPPAlpha);
	xAppWinBPPAlpha.addText(buffer);

	XMLNode xAppWinBPPAccum = xDisplayPrefs.addChild("appWinBPPAccum");
	sprintf(buffer, "%d", g_appWinBPPAccum);
	xAppWinBPPAccum.addText(buffer);

	//------------------------------------------------------------
	// Create nodes for all of the full-screen preferences.
	//------------------------------------------------------------
	
	// First we create sub-nodes for each monitor we need to save preferences for.
	XMLNode xFSNMonitor1 = xFullScreenPrefs.addChild("fsnMonitor1");
	XMLNode xFSNMonitor2 = xFullScreenPrefs.addChild("fsnMonitor2");
	XMLNode xFSNMonitor3 = xFullScreenPrefs.addChild("fsnMonitor3");
	XMLNode xFSNMonitor4 = xFullScreenPrefs.addChild("fsnMonitor4");

	// Create sub-nodes for monitor 1:
	XMLNode xFSNWidth  = xFSNMonitor1.addChild("fsnWidth");
	sprintf(buffer, "%d", g_fullScreenResolutions[0].x);
	xFSNWidth.addText(buffer);

	XMLNode xFSNHeight = xFSNMonitor1.addChild("fsnHeight");
	sprintf(buffer, "%d", g_fullScreenResolutions[0].y);
	xFSNHeight.addText(buffer);

	// Create sub-nodes for monitor 2:
	xFSNWidth = xFSNMonitor2.addChild("fsnWidth");
	sprintf(buffer, "%d", g_fullScreenResolutions[1].x);
	xFSNWidth.addText(buffer);

	xFSNHeight = xFSNMonitor2.addChild("fsnHeight");
	sprintf(buffer, "%d", g_fullScreenResolutions[1].y);
	xFSNHeight.addText(buffer);

	// Create sub-nodes for monitor 3:
	xFSNWidth = xFSNMonitor3.addChild("fsnWidth");
	sprintf(buffer, "%d", g_fullScreenResolutions[2].x);
	xFSNWidth.addText(buffer);

	xFSNHeight = xFSNMonitor3.addChild("fsnHeight");
	sprintf(buffer, "%d", g_fullScreenResolutions[2].y);
	xFSNHeight.addText(buffer);

	// Create sub-nodes for monitor 4:
	xFSNWidth = xFSNMonitor4.addChild("fsnWidth");
	sprintf(buffer, "%d", g_fullScreenResolutions[3].x);
	xFSNWidth.addText(buffer);

	xFSNHeight = xFSNMonitor4.addChild("fsnHeight");
	sprintf(buffer, "%d", g_fullScreenResolutions[3].y);
	xFSNHeight.addText(buffer);

	//------------------------------------------------------------
	// Create nodes foe all of the stereo preferences.
	//------------------------------------------------------------
	XMLNode xSTORenderingMethod = xStereoPrefs.addChild("stoRenderingMethod");
	sprintf(buffer, "%d", g_curStereoMethod);
	xSTORenderingMethod.addText(buffer);

	XMLNode xSTOSeparation = xStereoPrefs.addChild("stoSeparation");
	sprintf(buffer, "%f", g_stereoSeparation);
	xSTOSeparation.addText(buffer);

	XMLNode xSTOAsymmetry = xStereoPrefs.addChild("stoAsymmetry");
	sprintf(buffer, "%f", g_stereoAsymmetry);
	xSTOAsymmetry.addText(buffer);

	XMLNode xSTOSwapEyes = xStereoPrefs.addChild("stoSwapEyes");
	if (g_isSwapEyesOn == false){xSTOSwapEyes.addText("0");}
	else						{xSTOSwapEyes.addText("1");}

	//------------------------------------------------------------
	// And finally write out the file.
	//------------------------------------------------------------
	xMainNode.writeToFile(APP_PREFERENCES_FILE);

	return 0;
}