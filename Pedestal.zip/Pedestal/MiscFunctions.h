//////////////////////////////////////////////////////////////
// Misc Functions - Interface File
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Other preprocessor declarations:
#pragma once

// Function declarations:
void Pause(int &milliSecs);								// Pause function. To stop code execution for a set period.
void DebugOut(char* string);							// Streamlined function to output messages to the debug window.
void Pause(int &milliSecs);								// Used to pause the program for a set period of time.
void DebugOut(char* someString);						// Used to send custom debug messages to the output window.
inline float absF(float someFloat);						// Finds the absolute value of a floating point number.
inline int randRanged(int loBound, int hiBound);		// Generates a random integer within a specified range.
float* MakePureHueValueTable();							// Fills an array with the precalculated values of several hues. 
