//////////////////////////////////////////////////////////
// eInBasicLight.h - Interface file for the CeInBasicLight
// class.
//
// This class provides an easy way to store and manipulate
// information about a 3D lightsource.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Preprocessor Directives:
#pragma once

// Includes:
#include "stdAfx.h"

// Typedefs:
typedef UINT EINenum;

// Constants used with this class:
#define ATTEN_CONSTANT  (EINenum) 1001
#define ATTEN_LINEAR    (EINenum) 1002
#define ATTEN_QUADRATIC (EINenum) 1003

class CeInBasicLight
{
	bool isEnabled;						// Stores whether the light is "turned on" or not.
	bool isDefined;						// Stores whether the light's default parameters have ever been changed.

	eRGBf ambient;						// Stores the ambient color of the light.
	eRGBf diffuse;						// Stores the diffuse color of the light.
	eRGBf specular;						// Stores the specular color of the light.
	
	bool isDirectional;					// Stores whether this is a directional or a positional light.

	eVECT3 position;						// Stores the 3D position of the light.
	eVECT3 spotDirection;				// Stores the direction in which the light is facing.

	float spotExponent;					// Stores the intensity distribution of the light.
	float spotCutoff;					// Stores the spread angle of the light.

	EINenum attenuationType;			// Stores the current attenuation mode.

public:
	//--------------------------------------------------------
	// Constructors and Destructor:
	//--------------------------------------------------------

	// Constructors:
	CeInBasicLight(void);							// Default constructor.

	// Destructor:
	~CeInBasicLight(void);
	
	//--------------------------------------------------------
	// Data access functions:
	//--------------------------------------------------------

	// Get/Set enabled:
	inline bool GetIsEnabled()					   {return isEnabled;}
	inline void SetIsEnabled(const bool &someBool) {isEnabled = someBool;}

	// Get/Set defined:
	inline bool GetIsDefined()					   {return isDefined;}
	inline bool SetIsDefined(const bool &someBool) {isDefined = someBool;}

	// Get/Set ambient color:
	inline eRGBf GetAmbient()						{return ambient;}
	inline void SetAmbient(const eRGBf &someAmbient) {ambient = someAmbient;}

	// Get/Set diffuse color:
	inline eRGBf GetDiffuse()						{return diffuse;}
	inline void SetDiffuse(const eRGBf &someDiffuse) {diffuse = someDiffuse;}

	// Get/Set specular color:
	inline eRGBf GetSpecular()						  {return specular;}
	inline void SetSpecular(const eRGBf &someSpecular) {specular = someSpecular;}

	// Get/Set directionality:
	inline bool GetIsDirectional()					   {return isDirectional;}
	inline void SetIsDirectional(const bool &someBool) {isDirectional = someBool;}

	// Get/Set position:
	inline eVECT3 GetPosition()					   {return position;}
	inline void  SetPosition(const eVECT3 &somePos) {position = somePos;}

	// Get/Set spotDirection:
	inline eVECT3 GetSpotDirection()						{return spotDirection;}
	inline void	 SetSpotDirection(const eVECT3 &someDir) {spotDirection = someDir;}

	// Get/Set spotExponent:
	inline float GetSpotExponent()					   {return spotExponent;}
	inline void  SetSpotExponent(const float &someExp) {spotExponent = someExp;}

	// Get/Set spotCutoff:
	inline float GetSpotCutoff()						{return spotCutoff;}
	inline void  SetSpotCutoff(const float &someCutoff) {spotCutoff = someCutoff;}

	// Get/Set attenuationType:
	inline EINenum GetAttenuationType()						  {return attenuationType;}
	inline void    SetAttenuationType(const EINenum someType) {attenuationType = someType;}
};
