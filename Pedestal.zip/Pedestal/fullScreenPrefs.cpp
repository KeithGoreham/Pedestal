//////////////////////////////////////////////////////////////
// Implementation file for the Full Screen Preferences window.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

// Global Variables:
UINT	numDisplays;
ePOINT2	goodResolutionList[16];
UINT	numGoodResolutions;
//string	displayNames[9];

INT_PTR CALLBACK DlgProc_FullScreenPrefs(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HWND		hWndCboMonitor;
	static HWND		hWndCboPixelResolution;
	
	switch (uMsg)
	{
	case WM_INITDIALOG:
		{
			// Get the handles for the combo boxes on this panel.
			hWndCboMonitor			= GetDlgItem(hWnd, cboMonitor);
			hWndCboPixelResolution	= GetDlgItem(hWnd, cboPixelResolution);

			// Set up the Monitor Combobox:
			int result = 0;					// Variable to hold the result of our monitor queries.
			int i = 0;						// Loop variable
			int primaryMonitor;				// Stores which	display is set as the primary display.
			
			DISPLAY_DEVICE displayInfo;		// Structure to hold the display info.

			// Before we can use this object, we have to pass in it's size.
			displayInfo.cb = sizeof(displayInfo);
			
			// Now we'll loop through all the monitors attached to the system. We don't know
			// ahead of time how many there might be.
			while ((EnumDisplayDevices(NULL, i, &displayInfo, NULL)) && (i <= 9))
			{
				// If the Monitor is currently active...
				if (displayInfo.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP)
				{
					// If the monitor is the primary display...
					if (displayInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE)	
					{
						// Add a listing to the monitor combobox.
						SendMessage(hWndCboMonitor, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Primary Display");

						// Store the index of this monitor for the default.
						primaryMonitor = i;

						// Add another display to the total count.
						numDisplays += 1;
					}
					// If this is not the primary display...
					else															
					{
						// Add a listing to the monitor combobox.
						char monitorName[32];
						sprintf(monitorName, "Monitor %d", i + 1);
						SendMessage(hWndCboMonitor, CB_ADDSTRING, (WPARAM) 0, (LPARAM) monitorName);

						// Add another display to the total count.
						numDisplays += 1;
					}
				}

				i++;
			}
		
			// Now we decide which monitor comes up as the default in the monitor combobox. First 
			// we need to figure out which monitor our app is mostly on and get a handle to it.
			RECT windowRect;
			GetWindowRect(g_hWndMain, &windowRect);
			HMONITOR hMonitor = MonitorFromRect(&windowRect, MONITOR_DEFAULTTOPRIMARY);

			// Now we can retrieve the information for this monitor.
			MONITORINFOEX monitorInfo;
			monitorInfo.cbSize = sizeof(MONITORINFOEX);
			GetMonitorInfo(hMonitor, &monitorInfo);

			// Need this as a string for comparison purposes.
			string monitorName = monitorInfo.szDevice;
			UINT   whichMonitor = 0;

			// Now we'll decide which monitor comes up in the listbox by default.
			if (monitorName == "\\\\.\\DISPLAY1")
			{
				SendMessage(hWndCboMonitor, CB_SETCURSEL, (WPARAM) 0, (LPARAM) 0);
				whichMonitor = 0;
			}
			else if (monitorName == "\\\\.\\DISPLAY2")
			{
				SendMessage(hWndCboMonitor, CB_SETCURSEL, (WPARAM) 1, (LPARAM) 0);
				whichMonitor = 1;
			}
			else if (monitorName == "\\\\.\\DISPLAY3")
			{
				SendMessage(hWndCboMonitor, CB_SETCURSEL, (WPARAM) 2, (LPARAM) 0);
				whichMonitor = 2;
			}
			else if (monitorName == "\\\\.\\DISPLAY4")
			{
				SendMessage(hWndCboMonitor, CB_SETCURSEL, (WPARAM) 3, (LPARAM) 0);
				whichMonitor = 3;
			}
		
			// Now, we'll take the chosen monitor and build a list of the resolutions which are supported for it.
			int modeNum = 0;
			int defaultMode = 0;

			// Structure to hold requested display mode.
			DEVMODE devMode;
			ZeroMemory(&devMode, sizeof(DEVMODE));

			// Fill in our display struct.
			devMode.dmSize = sizeof(DEVMODE);

			// Buffer for string operations.
			char buffer[256];

			// Reset the count of good resolutions for subsequent callings of this function.
			numGoodResolutions = 0;

			// Enumerate each display mode supported.
			while(EnumDisplaySettings(monitorInfo.szDevice, modeNum++, &devMode))
			{
				// Make sure the display frequency of the mode is 60 Hz
				if ((devMode.dmBitsPerPel == g_appWinBPPColor) && (devMode.dmDisplayFrequency == 60))
				{
					// Make sure the width of the display mode is at least 640 pixels.
					if (devMode.dmPelsWidth >= 640)
					{
						// Make sure the display mode can be switched to without a restart.
						if (ChangeDisplaySettingsEx(monitorInfo.szDevice, &devMode, NULL, CDS_TEST, NULL) == DISP_CHANGE_SUCCESSFUL)
						{
							numGoodResolutions += 1;
							goodResolutionList[numGoodResolutions - 1].x = devMode.dmPelsWidth;
							goodResolutionList[numGoodResolutions - 1].y = devMode.dmPelsHeight;

							sprintf(buffer, "%d x %d", devMode.dmPelsWidth, devMode.dmPelsHeight);
							SendMessage(hWndCboPixelResolution, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buffer);
							
							if ((devMode.dmPelsWidth  == g_fullScreenResolutions[whichMonitor].x) && 
								(devMode.dmPelsHeight == g_fullScreenResolutions[whichMonitor].y))
							{
								defaultMode = numGoodResolutions; 
							}
						}
					}
				}
			}

			// Set the default choice on the resolution list.
			if (defaultMode >= 1){SendMessage(hWndCboPixelResolution, CB_SETCURSEL, (WPARAM) defaultMode - 1, (LPARAM) 0);}
			else				 {SendMessage(hWndCboPixelResolution, CB_SETCURSEL, (WPARAM) 0, (LPARAM) 1);}
	
			return true;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDOK:
				{
					// Figure out which monitor is currently selected.
					UINT whichMonitor = SendMessage(hWndCboMonitor, CB_GETCURSEL, NULL, NULL) + 1;
	
					// Save the selected resolution:
					int curDispMode = SendMessage(hWndCboPixelResolution, CB_GETCURSEL, NULL, NULL);

					if		(whichMonitor == 1){g_fullScreenResolutions[0].x = goodResolutionList[curDispMode].x;
												g_fullScreenResolutions[0].y = goodResolutionList[curDispMode].y;}
					else if (whichMonitor == 2){g_fullScreenResolutions[1].x = goodResolutionList[curDispMode].x;
												g_fullScreenResolutions[1].y = goodResolutionList[curDispMode].y;}
					else if (whichMonitor == 3){g_fullScreenResolutions[2].x = goodResolutionList[curDispMode].x;
												g_fullScreenResolutions[2].y = goodResolutionList[curDispMode].y;}
					else if (whichMonitor == 4){g_fullScreenResolutions[3].x = goodResolutionList[curDispMode].x;
												g_fullScreenResolutions[3].y = goodResolutionList[curDispMode].y;}

					EndDialog(hWnd, 0);

					return true;
				}
			case IDCANCEL:
				{
					EndDialog(hWnd, 0);

					return true;
				}
			case cboMonitor:				// Monitor combo box has changed.
				{
					int curMon = SendMessage(hWndCboMonitor, CB_GETCURSEL, NULL, NULL);

					// Now, we'll take the selected monitor and build a list of the resolutions which are supported for it.
					int modeNum = 0;
					int defaultMode = 0;

					// Structure to hold requested display mode.
					DEVMODE devMode;
					ZeroMemory(&devMode, sizeof(DEVMODE));

					// Fill in our display struct.
					devMode.dmSize = sizeof(DEVMODE);

					// Buffer for string operations.
					char buffer[256];

					// Reset the count of good resolutions for subsequent callings of this function.
					numGoodResolutions = 0;

					// Clear whatever is in the combobox already.
					SendMessage(hWndCboPixelResolution, CB_RESETCONTENT, (WPARAM) 0, (LPARAM) 0);

					// Determine the proper display name for EnumDisplaySettings.
					string displayName;

					if		(curMon == 0){displayName = "\\\\.\\DISPLAY1";}
					else if (curMon == 1){displayName = "\\\\.\\DISPLAY2";}
					else if (curMon == 2){displayName = "\\\\.\\DISPLAY3";}
					else if (curMon == 3){displayName = "\\\\.\\DISPLAY4";}


					// Enumerate each display mode supported.
					while(EnumDisplaySettings(displayName.c_str(), modeNum++, &devMode))
					{
						// Make sure the display frequency of the mode is 60 Hz
						if ((devMode.dmBitsPerPel == g_appWinBPPColor) && (devMode.dmDisplayFrequency == 60))
						{
							// Make sure the width of the display mode is at least 640 pixels.
							if (devMode.dmPelsWidth >= 640)
							{
								// Make sure the display mode can be switched to without a restart.
								if (ChangeDisplaySettingsEx(displayName.c_str(), &devMode, NULL, CDS_TEST, NULL) == DISP_CHANGE_SUCCESSFUL)
								{
									numGoodResolutions += 1;
									goodResolutionList[numGoodResolutions - 1].x = devMode.dmPelsWidth;
									goodResolutionList[numGoodResolutions - 1].y = devMode.dmPelsHeight;

									sprintf(buffer, "%d x %d", devMode.dmPelsWidth, devMode.dmPelsHeight);
									SendMessage(hWndCboPixelResolution, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buffer);
									
									if ((devMode.dmPelsWidth  == g_fullScreenResolutions[curMon].x) && 
										(devMode.dmPelsHeight == g_fullScreenResolutions[curMon].y))
									{
										defaultMode = numGoodResolutions; 
									}
								}
							}
						}
					}

					// Set the default choice on the resolution list.
					if (defaultMode >= 1){SendMessage(hWndCboPixelResolution, CB_SETCURSEL, (WPARAM) defaultMode - 1, (LPARAM) 0);}
					else				 {SendMessage(hWndCboPixelResolution, CB_SETCURSEL, (WPARAM) 0, (LPARAM) 1);}

					return 0;
				}
			case cboPixelResolution:		// Pixel resolution combo box has changed.
				{
					return 0;
				}
			}
			break;
		}
	}
	return 0;
}

//======================================================================
// CreateFullScreenPrefsWindow() - Creates our Full-Screen preferences
// panel.
//======================================================================
int CreateFullScreenPrefsWindow()
{
	CreateDialog(g_hInstance, MAKEINTRESOURCE(dlgFullScreenPrefs), g_hWndMain, DlgProc_FullScreenPrefs);

	return 0;
}