// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4C56C914_BF28_44B4_8239_6ADF67E533E9__INCLUDED_)
#define AFX_STDAFX_H__4C56C914_BF28_44B4_8239_6ADF67E533E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Other Defines.
#define WIN32_LEAN_AND_MEAN			// Leaves out the Microsoft Foundation Classes.
#define WIN32_EXTRA_LEAN			// Leaves out other rarely used Windows crap we don't need.
#define INITGUID					// Includes all GUIDs for input devices.

// Standard C++ non-system include files:
#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <fstream>

// Windows API headers:
#include <windows.h>
#include <Commdlg.h>					// Common Dialog Boxes.
#include <commctrl.h>					// Windows Common Controls.

// OpenGL Include Files:
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
#include <gl/wglext.h>
#include <gl/glext.h>

// DirectX Version Defines:
#define DIRECTINPUT_VERSION 0x0800

// DirectX Include Files:
#include <objbase.h>					// Needed for Input Device GUID definitions.

// e1ngine include files:
#include "e1nMath.h"
#include "e1nInput.h"
#include "e1nScene.h"

// 3rd Party Include Files:
#include "xmlParser\xmlParser.h"

// Resource Definitions:
#include "resource.h"				// Application menu definition.

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4C56C914_BF28_44B4_8239_6ADF67E533E9__INCLUDED_)
