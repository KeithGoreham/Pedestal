//////////////////////////////////////////////////////////
// RenderMesh.cpp - Implementation file. Part of
// the eIngine game engine.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// includes:
#include "eInDisplay.h"
#include "stdafx.h"


extern PFNGLCREATEPROGRAMOBJECTARBPROC			glCreateProgramObjectARB;
extern PFNGLCREATESHADEROBJECTARBPROC			glCreateShaderObjectARB;
extern PFNGLLINKPROGRAMARBPROC					glLinkProgramARB;
extern PFNGLCOMPILESHADERARBPROC				glCompileShaderARB;
extern PFNGLGETINFOLOGARBPROC					glGetInfoLogARB;
extern PFNGLDELETEOBJECTARBPROC					glDeleteObjectARB;
extern PFNGLUSEPROGRAMOBJECTARBPROC				glUseProgramObjectARB;
extern PFNGLSHADERSOURCEARBPROC					glShaderSourceARB;
extern PFNGLATTACHOBJECTARBPROC					glAttachObjectARB;
extern PFNGLGETOBJECTPARAMETERIVARBPROC			glGetObjectParameterivARB;
extern PFNGLGETUNIFORMLOCATIONARBPROC			glGetUniformLocationARB;
extern PFNGLDISABLEVERTEXATTRIBARRAYARBPROC		glDisableVertexAttribArrayARB;
extern PFNGLENABLEVERTEXATTRIBARRAYARBPROC		glEnableVertexAttribArrayARB;
extern PFNGLUNIFORM4FARBPROC					glUniform4fARB;
extern PFNGLUNIFORM2FARBPROC					glUniform2fARB;
extern PFNGLUNIFORM1FARBPROC					glUniform1fARB;
extern PFNGLUNIFORM1IARBPROC					glUniform1iARB;

extern GLhandleARB glslContext;
extern GLhandleARB glslVertexShader;
extern GLhandleARB glslPixelShader;

//------------------------------------------------------------
// This function is used to render a mesh object.
//------------------------------------------------------------
bool CeInDisplay::RenderMesh(eSTATIC_MESH &someMesh)
{
	// Face rendering switch:
	switch (curRenderMode)
	{
	case EIN_RENDER_WIREFRAME:		// White wireframe render with an object wire color fill.
		{
			// Pointers for the three verts that make up each face.
			eVECT3* faceVert1Pos;
			eVECT3* faceVert2Pos;
			eVECT3* faceVert3Pos;

			// Pointers for the two verts that make up each edge.
			eVECT3* edgeVert1Pos;
			eVECT3* edgeVert2Pos;

			// OpenGL prep for this rendering mode:
			glDisable(GL_LIGHTING);
			glDisable(GL_TEXTURE_2D);

			glEnable(GL_DEPTH_TEST);
					
			// Ok, first thing to do is to render the faces of the model inside-out using the
			// mesh's wire color.
		//	glBegin(GL_TRIANGLES);
			glBegin(GL_LINES);
			
				// Loop through each face.
				for (UINT i = 0; i < someMesh.numFaces; i++)
				{
					// Grab the verts for the current face.
					faceVert1Pos = &someMesh.verts[someMesh.faces[i].x];
					faceVert2Pos = &someMesh.verts[someMesh.faces[i].y];
					faceVert3Pos = &someMesh.verts[someMesh.faces[i].z];
					
					// Set the color:
					glColor3f(someMesh.wireColor.r, someMesh.wireColor.g, someMesh.wireColor.b);

					// Draw the face:
					glVertex3f(faceVert1Pos->x, faceVert1Pos->y, faceVert1Pos->z);		
					glVertex3f(faceVert2Pos->x, faceVert2Pos->y, faceVert2Pos->z);		
					glVertex3f(faceVert3Pos->x, faceVert3Pos->y, faceVert3Pos->z);		
				}
			glEnd();

			// Now it's time to render the visible edges on top of the geometry we just rendered.

			glDisable(GL_DEPTH_TEST);		// So we can render a full wireframe on top of the mesh's solid color.

			// First we loop through each of the mesh's edges.
			//for (UINT i = 0; i < someMesh.numEdges; i++)
			//{
			//	// Grab the positions of the two verts which define this edge.
			//	edgeVert1Pos = &someMesh.verts[someMesh.edges[i].x];
			//	edgeVert2Pos = &someMesh.verts[someMesh.edges[i].y];

			//	// Set the drawing color to white:
			//	glColor3f(1.0f, 1.0f, 1.0f);
			//
			//	// Draw the edge:
			//	glBegin(GL_LINES);
			//		glVertex3f(edgeVert1Pos->x, edgeVert1Pos->y, edgeVert1Pos->z);
			//		glVertex3f(edgeVert2Pos->x, edgeVert2Pos->y, edgeVert2Pos->z);
			//	glEnd();
			//}

			break;
		}
	case EIN_RENDER_VERTCOLORS:
		{
			eBASIC_MAT* curMat;		// Pointer to our model's material list.
			
			// Enable the various rendering modes:
			glEnable(GL_MULTISAMPLE_ARB);			// Turn on Anti-Aliasing
			glEnable(GL_CULL_FACE);					// Turn on Face Culling
			glEnable(GL_DEPTH_TEST);				// Turn on the depth buffer
			glDisable(GL_TEXTURE_2D);

			// Rendering Parameters:
			glCullFace(GL_BACK);									// Cull the backs of faces.

			// Enable the various vertex arrays:
			glEnableClientState(GL_VERTEX_ARRAY);
			glEnableClientState(GL_COLOR_ARRAY);

			// Feed the vertex array pointers their data:
			glVertexPointer	 (3, GL_FLOAT, 0, someMesh.vertArray);
			glColorPointer	 (3, GL_FLOAT, 0, someMesh.cpvArray);

			// Step through each material.
			for (UINT i = 0; i < someMesh.numMaterials; i++)
			{
				curMat = &someMesh.materials[i];
				
				// Calculate where and how many faces to draw:
				UINT numVerts2Draw = (((someMesh.materials[i].lastMatFace - someMesh.materials[i].firstMatFace) + 1) * 3); 
				UINT firstVert2Draw = someMesh.materials[i].firstMatFace * 3;

				// Render the model:
				glDrawArrays(GL_TRIANGLES, firstVert2Draw, numVerts2Draw);
			}

			glDisableClientState(GL_VERTEX_ARRAY);
			glDisableClientState(GL_COLOR_ARRAY);

			glDisable(GL_MULTISAMPLE_ARB);

			break;
		}
	case EIN_RENDER_MATCOLORS:
		{
			eBASIC_MAT* curMat;		// Pointer to our model's material list.
			
			// Enable the various rendering modes:
			glEnable(GL_MULTISAMPLE_ARB);			// Turn on Anti-Aliasing
			glEnable(GL_CULL_FACE);					// Turn on Face Culling
			glEnable(GL_BLEND);						// Turn on Blending
			glEnable(GL_DEPTH_TEST);				// Turn on the depth buffer
			glEnable(GL_TEXTURE_2D);				// Turn on 2D texture mapping

			// Rendering Parameters:
			glCullFace(GL_BACK);									// Cull the backs of faces.
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// Blending Params.

			// Enable the various vertex arrays:
			glEnableClientState(GL_VERTEX_ARRAY);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);

			// Feed the vertex array pointers their data:
			glVertexPointer	 (3, GL_FLOAT, 0, someMesh.vertArray);
			glTexCoordPointer(2, GL_FLOAT, 0, someMesh.tVertArray);

			// Set the drawing color.
			glColor3f(1.0, 1.0, 1.0);		

			// Step through each material.
			for (UINT i = 0; i < someMesh.numMaterials; i++)
			{
				curMat = &someMesh.materials[i];

				// Bind the appropriate texture already in the video card's memory.
				glBindTexture(GL_TEXTURE_2D, boundTextures[i]);

				// GLfloat arrays for the various material colors.
				GLfloat matAmbient[]  = {curMat->ambient.r,  curMat->ambient.g,  curMat->ambient.b};
	  			GLfloat matSpecular[] = {curMat->specular.r, curMat->specular.g, curMat->specular.b};
				GLfloat matEmissive[] = {curMat->emissive.r, curMat->emissive.g, curMat->emissive.b};
				
				// Material parameters
				glMaterialfv(GL_FRONT, GL_AMBIENT, matAmbient);
				glMaterialfv(GL_FRONT, GL_SPECULAR, matSpecular);
				glMaterialfv(GL_FRONT, GL_EMISSION, matEmissive);
				glMaterialf (GL_FRONT, GL_SHININESS, (float) curMat->shininess);

				// Calculate where and how many faces to draw:
				UINT numVerts2Draw = (((someMesh.materials[i].lastMatFace - someMesh.materials[i].firstMatFace) + 1) * 3); 
				UINT firstVert2Draw = someMesh.materials[i].firstMatFace * 3;

				// Render the model:
				glDrawArrays(GL_TRIANGLES, firstVert2Draw, numVerts2Draw);
			}

			glDisableClientState(GL_VERTEX_ARRAY);
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);

			glDisable(GL_MULTISAMPLE_ARB);

			break;
		} 
	case EIN_RENDER_COMBINED:
		{
			eBASIC_MAT* curMat;		// Pointer to our model's material list.
			
			// Enable the various rendering modes:
			glEnable(GL_MULTISAMPLE_ARB);			// Turn on Anti-Aliasing
			glEnable(GL_CULL_FACE);					// Turn on Face Culling
			glEnable(GL_BLEND);						// Turn on Blending
			glEnable(GL_DEPTH_TEST);				// Turn on the depth buffer
			glEnable(GL_TEXTURE_2D);				// Turn on 2D texture mapping

			// Rendering Parameters:
			glCullFace(GL_BACK);									// Cull the backs of faces.
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// Blending Params.

			// Enable the various vertex arrays:
			glEnableClientState(GL_VERTEX_ARRAY);
			glEnableClientState(GL_COLOR_ARRAY);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);

			// Feed the vertex array pointers their data:
			glVertexPointer	 (3, GL_FLOAT, 0, someMesh.vertArray);
			glColorPointer	 (3, GL_FLOAT, 0, someMesh.cpvArray);
			glTexCoordPointer(2, GL_FLOAT, 0, someMesh.tVertArray);

			// Step through each material.
			for (UINT i = 0; i < someMesh.numMaterials; i++)
			{
				curMat = &someMesh.materials[i];

				// Bind the appropriate texture already in the video card's memory.
				glBindTexture(GL_TEXTURE_2D, boundTextures[i]);

				// GLfloat arrays for the various material colors.
				GLfloat matAmbient[]  = {curMat->ambient.r,  curMat->ambient.g,  curMat->ambient.b};
	  			GLfloat matSpecular[] = {curMat->specular.r, curMat->specular.g, curMat->specular.b};
				GLfloat matEmissive[] = {curMat->emissive.r, curMat->emissive.g, curMat->emissive.b};
				
				// Material parameters
				glMaterialfv(GL_FRONT, GL_AMBIENT, matAmbient);
				glMaterialfv(GL_FRONT, GL_SPECULAR, matSpecular);
				glMaterialfv(GL_FRONT, GL_EMISSION, matEmissive);
				glMaterialf (GL_FRONT, GL_SHININESS, (float) curMat->shininess);

				// Calculate where and how many faces to draw:
				UINT numVerts2Draw = (((someMesh.materials[i].lastMatFace - someMesh.materials[i].firstMatFace) + 1) * 3); 
				UINT firstVert2Draw = someMesh.materials[i].firstMatFace * 3;

				// Render the model:
				glDrawArrays(GL_TRIANGLES, firstVert2Draw, numVerts2Draw);
			}

			glDisableClientState(GL_VERTEX_ARRAY);
			glDisableClientState(GL_COLOR_ARRAY);
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);

			glDisable(GL_MULTISAMPLE_ARB);

			break;
		}
	case EIN_RENDER_TESTMODE:
		{
			// Use Shaders.
			glUseProgramObjectARB(glslContext);

			eBASIC_MAT* curMat;		// Pointer to our model's material list.
			
			// Enable the various rendering modes:
			glEnable(GL_MULTISAMPLE_ARB);			// Turn on Anti-Aliasing
			glEnable(GL_CULL_FACE);					// Turn on Face Culling
			glEnable(GL_BLEND);						// Turn on Blending
			glEnable(GL_DEPTH_TEST);				// Turn on the depth buffer
	//		glEnable(GL_TEXTURE_2D);				// Turn on 2D texture mapping

			// Rendering Parameters:
			glCullFace(GL_BACK);									// Cull the backs of faces.
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// Blending Params.

			// Enable the various vertex arrays:
			glEnableClientState(GL_VERTEX_ARRAY);
			glEnableClientState(GL_COLOR_ARRAY);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);

			// Feed the vertex array pointers their data:
			glVertexPointer	 (3, GL_FLOAT, 0, someMesh.vertArray);
			glColorPointer	 (3, GL_FLOAT, 0, someMesh.cpvArray);
			glTexCoordPointer(2, GL_FLOAT, 0, someMesh.tVertArray);

			glDrawArrays(GL_TRIANGLES, 0, (someMesh.numFaces - 1) * 3);
			
			//// Step through each material.
			//for (UINT i = 0; i < someMesh.numMaterials; i++)
			//{
			//	curMat = &someMesh.materials[i];

			//	// Bind the appropriate texture already in the video card's memory.
			//	glBindTexture(GL_TEXTURE_2D, boundTextures[i]);

			//	// GLfloat arrays for the various material colors.
			//	GLfloat matAmbient[]  = {curMat->ambient.r,  curMat->ambient.g,  curMat->ambient.b};
	  //			GLfloat matSpecular[] = {curMat->specular.r, curMat->specular.g, curMat->specular.b};
			//	GLfloat matEmissive[] = {curMat->emissive.r, curMat->emissive.g, curMat->emissive.b};
			//	
			//	// Material parameters
			//	glMaterialfv(GL_FRONT, GL_AMBIENT, matAmbient);
			//	glMaterialfv(GL_FRONT, GL_SPECULAR, matSpecular);
			//	glMaterialfv(GL_FRONT, GL_EMISSION, matEmissive);
			//	glMaterialf (GL_FRONT, GL_SHININESS, (float) curMat->shininess);

			//	// Calculate where and how many faces to draw:
			//	UINT numVerts2Draw = (((someMesh.materials[i].lastMatFace - someMesh.materials[i].firstMatFace) + 1) * 3); 
			//	UINT firstVert2Draw = someMesh.materials[i].firstMatFace * 3;

			//	// Render the model:
			//	glDrawArrays(GL_TRIANGLES, firstVert2Draw, numVerts2Draw);
			//}

			glDisableClientState(GL_VERTEX_ARRAY);
			glDisableClientState(GL_COLOR_ARRAY);
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);

			glDisable(GL_MULTISAMPLE_ARB);

			glUseProgramObjectARB(NULL);

			break;
		}
	}

	return true;
}