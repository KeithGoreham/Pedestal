//////////////////////////////////////////////////////////////
// Implementation file for the GameResize function.
//
// This function is called whenever either the application
// window is resized or the resolution is changed in
// full-screen mode.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInDisplay.h"
#include "eInStaticMesh.h"

// Externally defined variables:
extern eDISPLAY_OBJECT* g_renderer;
extern eSTATIC_MESH*	g_playerMesh;
extern bool				g_isAppFullScreen;
extern bool			    g_suspendResize;
extern UINT				g_appWinWidth;
extern UINT				g_appWinHeight;

// Function definition.
int GameResize(UINT &newWidth, UINT &newHeight, UINT &newBPPColor, UINT &newBPPDepth)
{
	OutputDebugString("--->Game Resize function called.\n");

	g_appWinWidth  = newWidth;
	g_appWinHeight = newHeight;

	// Reset the renderer's display mode.
	g_renderer->SetVideoMode(newWidth, newHeight, newBPPColor, newBPPDepth, g_isAppFullScreen);

	// Re-Send our Textures to the video card.
	g_renderer->BindObjectTextures(*g_playerMesh);


	return 0;
}