//////////////////////////////////////////////////////////////
// Implementation file for the Main UI Main Window functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

// Externally Defined Variables:
extern UINT    g_appWinWidth;
extern UINT    g_appWinHeight;
extern UINT    g_appWinBPPColor;
extern UINT    g_appWinBPPDepth;
extern UINT    g_appWinBPPAlpha;
extern UINT    g_appWinBPPAccum;
extern float   g_fullScreenCustomAspect;
extern bool	   g_suspendResize;
extern ePOINT2 g_windowedPosition;

//======================================================================
// WndProc_Main() - Our Windows event handler for the main window.
//======================================================================
long CALLBACK WndProc_Main(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	// Grab a handle to the main window's menu bar.
	HMENU hMenu = GetMenu(hWnd);

	// Now we run a switch on the message to decide what to do.
	switch (uMessage)
	{
	case WM_CREATE:				// Called when the window is created.
		{
			// Make sure the checkmark for stereo in the view menu reflects whether stereo is on or not.
			if (g_isStereoOn == true)
			{
				CheckMenuItem(hMenu, ID_VIEW_3DSTEREO, MF_CHECKED);
			}

			return 0;
		}
	case WM_MENUSELECT:			// Called whenever highlights a menu item while browsing.
		{
			EINenum oldMode = g_renderer->GetRenderMode();

			switch (LOWORD(wParam))
			{
			case ID_RENDER_WIREFRAME:
				{
					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_WIREFRAME);
					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}
					
					g_renderer->SetRenderMode(oldMode);

					return 0;
				}
			case ID_RENDER_VERTCOLORS:
				{
					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_VERTCOLORS);
					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}

					g_renderer->SetRenderMode(oldMode);

					return 0;
				}
			case ID_RENDER_MATERIALCOLORS:
				{
					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_MATCOLORS);
					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}

					g_renderer->SetRenderMode(oldMode);

					return 0;
				}
			case ID_RENDER_COMBINED:
				{
					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_COMBINED);
					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}

					g_renderer->SetRenderMode(oldMode);

					return 0;
				}
			case ID_RENDER_TESTMODE:
				{
					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_TESTMODE);
					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}

					g_renderer->SetRenderMode(oldMode);

					return 0;
				}
			default:
				{					
					// Update the display:
					if (g_isStereoOn == true)
					{
						GameDisplayStereo();
					}
					else
					{
						GameDisplay();
					}
					
					return 0;
				}
			}

			return 0;
		}
	case WM_COMMAND:			// Called whenever a user clicks on a menu item.
		{
			switch (LOWORD(wParam))
			{
			case ID_FILE_EXIT:
				{
					if (g_isAppFullScreen == true)
					{
						// Structure to hold requested display mode.
						DEVMODE devMode;
						ZeroMemory(&devMode, sizeof(DEVMODE));

						// Fill in our display struct.
						devMode.dmSize       = sizeof(DEVMODE);
						devMode.dmPelsWidth  = g_desktopSize.x;
						devMode.dmPelsHeight = g_desktopSize.y;
						devMode.dmFields	 = DM_PELSWIDTH | DM_PELSHEIGHT;
						
						// Use the struct to change the screen resolution.
						ChangeDisplaySettings(&devMode, 0);
					}

					// Save out our preferences.
					WritePreferencesFile();

					// Tell Windows to put a WM_QUIT message in our message queue
					PostQuitMessage(0);

					return 0;
				}
			case ID_FILE_OPENMODEL:
				{
					OPENFILENAME ofn;					// Common dialog box structure.
					char fileName[260];					// Buffer for file name.

					ZeroMemory(&ofn, sizeof(ofn));

					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner   = g_hWndMain;
					ofn.lpstrFile   = fileName;

					ofn.lpstrFile[0]    = '\0';
					ofn.nMaxFile        = sizeof(fileName);
					ofn.lpstrFilter     = "All\0*.*\0eIngine Single Static Mesh\0*.ESSM\0";
					ofn.nFilterIndex    = 1;
					ofn.lpstrFileTitle  = NULL;
					ofn.nMaxFileTitle   = 0;
					ofn.lpstrInitialDir = NULL;
					ofn.Flags           = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

					if(GetOpenFileName(&ofn) == TRUE)
					{
						// Run the display function to refresh the screen.
						GameDisplay();

						if (g_playerMesh == NULL)
						{
							g_playerMesh = new eSTATIC_MESH;
						}
						else
						{
							delete g_playerMesh;
							g_playerMesh = new eSTATIC_MESH;
						}

						g_playerMesh->loadESSM(fileName);
						g_renderer->BindObjectTextures(*g_playerMesh);

						player.pos.x = 0.0f;
						player.pos.y = 0.0f;
						player.pos.z = 0.0f;

						player.rot.x = 0.0f;
						player.rot.y = 0.0f;
					}
					
					g_resetView = true;

					return 0;
				}
			case ID_VIEW_3DSTEREO:
				{
					UINT winWidth;
					UINT winHeight;

					// Whichever rendering mode we're in (stereo or mono), switch our state to
					// the opposite and mark the menu appropriately.
					if (g_isStereoOn == false)		
					{
						g_isStereoOn = true;
						CheckMenuItem(hMenu, ID_VIEW_3DSTEREO, MF_CHECKED);
					}
					else
					{
						g_isStereoOn = false;
						CheckMenuItem(hMenu, ID_VIEW_3DSTEREO, MF_UNCHECKED);
					}

					// Ok, first we need to figure out which monitor we're on and get a handle to it.
					RECT windowRect;
					GetWindowRect(g_hWndMain, &windowRect);
					HMONITOR hMonitor = MonitorFromRect(&windowRect, MONITOR_DEFAULTTOPRIMARY);

					// Now we can retrieve the information for this monitor.
					MONITORINFOEX monitorInfo;
					monitorInfo.cbSize = sizeof(MONITORINFOEX);
					GetMonitorInfo(hMonitor, &monitorInfo);

					if (g_isAppFullScreen == true)		// If we're running full-screen...
					{
						// Hide the main window.
						ShowWindow(g_hWndMain, SW_HIDE);

						// Release the OGL drawing context associated with this window.
						ReleaseDC(g_hWndMain, g_renderer->mainDC);

						// Destroy the window.
						DestroyWindow(g_hWndMain);

						// Windows will automatically restore the original desktop resolution once
						// we destroy the previous window. So we need to change the display settings
						// once again.

						// Figure out an integer (0 - 3) for which monitor we're working with.
						UINT   whichMonitor = 0;
						string displayName  = monitorInfo.szDevice;

						if		(displayName == "\\\\.\\DISPLAY1"){whichMonitor = 0;}
						else if (displayName == "\\\\.\\DISPLAY2"){whichMonitor = 1;}
						else if (displayName == "\\\\.\\DISPLAY3"){whichMonitor = 2;}
						else if (displayName == "\\\\.\\DISPLAY4"){whichMonitor = 3;}

						// Structure to hold requested display mode.
						DEVMODE devMode;
						ZeroMemory(&devMode, sizeof(DEVMODE));

						// Fill in our display struct.
						devMode.dmSize       = sizeof(DEVMODE);
						devMode.dmPelsWidth  = g_fullScreenResolutions[whichMonitor].x;
						devMode.dmPelsHeight = g_fullScreenResolutions[whichMonitor].y;
						devMode.dmFields	 = DM_PELSWIDTH | DM_PELSHEIGHT;
						
						// Change the display resolution for the selected monitor.
						ChangeDisplaySettingsEx(monitorInfo.szDevice, &devMode, NULL, 4, NULL);

						// Bug fix. Tried to put this up at the top of this event, but the setting would somehow be forgotten by this point.
						g_suspendResize = true;

						// Create a new full-screen render window.
						CreateFullScreenRenderWindow(whichMonitor);

						// Hide the menu.
						SetMenu(g_hWndMain, NULL);

						// Now we figure out the size and position of the render window.
						RECT mainWindowRect;

						winWidth  = g_fullScreenResolutions[whichMonitor].x;
						winHeight = g_fullScreenResolutions[whichMonitor].y;

						// Update the display class with it's new window.
						g_renderer->mainWnd = g_hWndMain;

						// Get a new OGL drawing context for this window.
						g_renderer->mainDC  = GetDC(g_hWndMain);

						// Update the window's position:
						SetWindowPos(g_hWndMain, 
									 HWND_TOPMOST, 
									 monitorInfo.rcMonitor.left, 
									 monitorInfo.rcMonitor.top, 
									 NULL, 
									 NULL, 
									 SWP_SHOWWINDOW | SWP_NOSIZE);

						// Show the window.
						ShowWindow(g_hWndMain, SW_SHOW);

						// Set our global state variable.
						g_isAppFullScreen = true;
					}		
					else								// If we're not running full-screen...						  
					{
						// Hide the render sub-window.
						ShowWindow(g_hWndRender, SW_HIDE);

						// Release the OGL drawing context associated with this window.
						ReleaseDC(g_hWndRender, g_renderer->mainDC);

						// Destroy this window.
						DestroyWindow(g_hWndRender);

						// Create a new rendering sub-window.
						CreateRenderWindow();

						// Now we figure out the size and position of the render window and the client area.
						RECT mainWindowRect;			// Rect for the entire application window.
						RECT mainClientRect;			// Rect for the application area of the main application window.
						RECT statusRect;				// Rect for the status bar at the bottom of the main application window.
						
						GetWindowRect(g_hWndMain, &mainWindowRect);
						GetClientRect(g_hWndMain, &mainClientRect);
						GetWindowRect(g_hWndStatusBar, &statusRect);
						
						// Figure out our window's width, height, position, and the thickness of the border around the application window.
						UINT xBorder		 = ((mainWindowRect.right - mainWindowRect.left) - mainClientRect.right) / 2;
						UINT statusBarHeight = statusRect.bottom - statusRect.top;

						winWidth  = mainClientRect.right;
						winHeight = mainClientRect.bottom - statusBarHeight;
						

						// Update the display class with it's new window.
						g_renderer->mainWnd = g_hWndRender;

						// Get a new OGL drawing context for this window.
						g_renderer->mainDC  = GetDC(g_hWndRender);

						// Set our global state variable.
						g_isAppFullScreen = false;
					}		
					
					// Enable or Disable OGL Quad-Buffer Stereo.
					if (g_isStereoOn == true)
					{
						if (g_curStereoMethod == STEREOMETHOD_OPENGL){g_renderer->EnableStereo(true);}
						else										 {g_renderer->EnableStereo(false);}
					}
					else
					{
						g_renderer->EnableStereo(false);
					}

					// Show the new window.
					if (g_isAppFullScreen == true){ShowWindow(g_hWndMain,   SW_SHOW);}
					else						  {ShowWindow(g_hWndRender, SW_SHOW);}

					// Set the video mode and load the mesh textures onto the video card.
					g_renderer->SetVideoMode(winWidth, winHeight, g_appWinBPPColor, g_appWinBPPDepth, g_isAppFullScreen);
					g_renderer->BindObjectTextures(*g_playerMesh);

					// Run the display function to refresh the screen.
					GameDisplay();

					// Since we've changed windows, we need a new input object to get keyboard and mouse input.
					if (g_input != NULL){delete g_input;}
					g_input = new Ce1nInputDI8(g_hInstance, g_hWndMain, false);

					// Allow the resize function to update the window again.
					g_suspendResize = false;

					return 0;
				}
			case ID_VIEW_SWAPEYES:
				{
					if (g_isSwapEyesOn == false)
					{
						g_isSwapEyesOn = true;
						CheckMenuItem(hMenu, ID_VIEW_SWAPEYES, MF_CHECKED);
					}
					else
					{
						g_isSwapEyesOn = false;
						CheckMenuItem(hMenu, ID_VIEW_SWAPEYES, MF_UNCHECKED);
					}

					return 0;
				}
			case ID_VIEW_FULLSCREEN:
				{
					// Keep the resize function from trying to update the window.
					g_suspendResize = true;

					// Ok, first we need to figure out which monitor we're on and get a handle to it.
					RECT windowRect;
					GetWindowRect(g_hWndMain, &windowRect);
					HMONITOR hMonitor = MonitorFromRect(&windowRect, MONITOR_DEFAULTTOPRIMARY);

					// Now we can retrieve the information for this monitor.
					MONITORINFOEX monitorInfo;
					monitorInfo.cbSize = sizeof(MONITORINFOEX);
					GetMonitorInfo(hMonitor, &monitorInfo);

					if (g_isAppFullScreen == false)		// If we're not full-screen...
					{
						// Hide the existing application window.
						ShowWindow(g_hWndMain, SW_HIDE);
						
						// Release the OGL drawing context associated with this window.
						ReleaseDC(g_hWndMain, g_renderer->mainDC);

						// Destroy the window.
						DestroyWindow(g_hWndMain);

						// Figure out an integer (0 - 3) for which monitor we're working with.
						UINT   whichMonitor = 0;
						string displayName  = monitorInfo.szDevice;

						if		(displayName == "\\\\.\\DISPLAY1"){whichMonitor = 0;}
						else if (displayName == "\\\\.\\DISPLAY2"){whichMonitor = 1;}
						else if (displayName == "\\\\.\\DISPLAY3"){whichMonitor = 2;}
						else if (displayName == "\\\\.\\DISPLAY4"){whichMonitor = 3;}

						// Structure to hold requested display mode.
						DEVMODE devMode;
						ZeroMemory(&devMode, sizeof(DEVMODE));

						// Fill in our display struct.
						devMode.dmSize       = sizeof(DEVMODE);
						devMode.dmPelsWidth  = g_fullScreenResolutions[whichMonitor].x;
						devMode.dmPelsHeight = g_fullScreenResolutions[whichMonitor].y;
						devMode.dmFields	 = DM_PELSWIDTH | DM_PELSHEIGHT;
						
						// Change the display resolution for the selected monitor.
						ChangeDisplaySettingsEx(monitorInfo.szDevice, &devMode, NULL, 4, NULL);

						// Create a new full-screen render window.
						CreateFullScreenRenderWindow(whichMonitor);
						
						// Hide the menu.
						SetMenu(g_hWndMain, NULL);

						// Update the display class with it's new window.
						g_renderer->mainWnd = g_hWndMain;

						// Get a new OGL drawing context for this window.
						g_renderer->mainDC  = GetDC(g_hWndMain);

						// Need to copy these to UINT variables for the SetVideoMode function.
						UINT winWidth  = g_fullScreenResolutions[whichMonitor].x;
						UINT winHeight = g_fullScreenResolutions[whichMonitor].y;

						// Update the window's position:
						SetWindowPos(g_hWndMain, 
									 HWND_TOPMOST, 
									 monitorInfo.rcMonitor.left, 
									 monitorInfo.rcMonitor.top, 
									 NULL, 
									 NULL, 
									 SWP_SHOWWINDOW | SWP_NOSIZE);

						// Show the new window.
						ShowWindow(g_hWndMain, SW_SHOW);

						// Update our global state variable.
						g_isAppFullScreen = true;

						// Set the video mode and load the mesh textures onto the video card.
						g_renderer->SetVideoMode(winWidth, 
												winHeight, 
												g_appWinBPPColor, 
												g_appWinBPPDepth, 
												g_isAppFullScreen);

						g_renderer->BindObjectTextures(*g_playerMesh);

						// Update the renderer's aspect ratio to match this monitor.
						UINT deskWidth  = monitorInfo.rcMonitor.right  - monitorInfo.rcMonitor.left;
						UINT deskHeight = monitorInfo.rcMonitor.bottom - monitorInfo.rcMonitor.top;

						g_renderer->setFullScreenAspect(deskWidth, deskHeight);

						// Run the display function to refresh the screen.
						GameDisplay();

						// Since we've changed windows, we need a new input object to get keyboard and mouse input.
						delete g_input;
						g_input = new Ce1nInputDI8(g_hInstance, g_hWndMain, false);
					}
					else							// If we are full-screen...
					{
						// Update our global state variable.
						g_isAppFullScreen = false;				

						// Hide the existing application window.
						ShowWindow(g_hWndMain, SW_HIDE);

						// Destroy the window.
						DestroyWindow(g_hWndMain);

						// Structure to hold requested display mode.
						DEVMODE devMode;
						ZeroMemory(&devMode, sizeof(DEVMODE));

						// Fill in our display struct.
						devMode.dmSize       = sizeof(DEVMODE);
						devMode.dmPelsWidth  = g_desktopSize.x;
						devMode.dmPelsHeight = g_desktopSize.y;
						devMode.dmFields	 = DM_PELSWIDTH | DM_PELSHEIGHT;
						
						// Change the display resolution for the current monitor.
						ChangeDisplaySettingsEx(monitorInfo.szDevice, NULL, NULL, NULL, NULL);

						// Figure out the proper position for centering the window.
						UINT mainPosX = (g_desktopSize.x  / 2) - (APP_WINDOW_WIDTH  / 2);
						UINT mainPosY = (g_desktopSize.y / 2)  - (APP_WINDOW_HEIGHT / 2);

						// Create the main application window.
						CreateMainWindow();

						// Create the status bar and render windows.
						CreateStatusBarWindow();
						CreateRenderWindow();

						// Now we figure out the size and position of the render window.
						RECT mainWindowRect;
						RECT mainClientRect;
						RECT statusRect;
						
						GetWindowRect(g_hWndMain, &mainWindowRect);
						GetClientRect(g_hWndMain, &mainClientRect);
						GetWindowRect(g_hWndStatusBar, &statusRect);

						// Figure out our window's width, height, and position.
						UINT statusBarHeight = statusRect.bottom - statusRect.top;
						UINT winWidth		 = mainClientRect.right;
						UINT winHeight		 = mainClientRect.bottom - statusBarHeight;

						// Update the display class with it's new window.
						g_renderer->mainWnd = g_hWndRender;

						// Release the OGL drawing context associated with this window.
						ReleaseDC(g_hWndMain, g_renderer->mainDC);
						g_renderer->mainDC  = GetDC(g_hWndRender);

						// Run the display function to refresh the screen.
						GameDisplay();

						// Set the video mode and load the mesh textures onto the video card.
						g_renderer->SetVideoMode(winWidth, winHeight, g_appWinBPPColor, g_appWinBPPDepth, g_isAppFullScreen);
						g_renderer->BindObjectTextures(*g_playerMesh);

						// Create UINTs for the window's position to be used with SetWindowPos().
						UINT posX = g_windowedPosition.x;
						UINT posY = g_windowedPosition.y;
						
						// Update the window's position:
						SetWindowPos(g_hWndMain, 
									 HWND_TOPMOST, 
									 posX,
									 posY,
									 NULL, 
									 NULL, 
									 SWP_SHOWWINDOW | SWP_NOSIZE);

						// Show the new window.
						ShowWindow(g_hWndMain, SW_SHOW);

						// Since we've changed windows, we need a new input object to get keyboard and mouse input.
						delete g_input;
						g_input = new Ce1nInputDI8(g_hInstance, g_hWndMain, false);
					}

					// Allow the resize function to update the window again.
					g_suspendResize = false;

					return 0;
				}
			case ID_VIEW_STEREOPREFERENCES:
				{
					CreateStereoPrefsWindow();

					return 0;
				}
			case ID_VIEW_FULLSCREENPREFERENCES:
				{
					CreateFullScreenPrefsWindow();

					return 0;
				}
			case ID_RENDER_WIREFRAME:
				{
					// Check this item in the menu:
					CheckMenuItem(hMenu, ID_RENDER_WIREFRAME, MF_CHECKED);

					// And un-check everything else:
					CheckMenuItem(hMenu, ID_RENDER_VERTCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_MATERIALCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_TESTMODE, MF_UNCHECKED);

					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_WIREFRAME);
					GameDisplay();

					return 0;
				}
			case ID_RENDER_VERTCOLORS:
				{
					// Check this item in the menu:
					CheckMenuItem(hMenu, ID_RENDER_VERTCOLORS, MF_CHECKED);

					// And un-check everything else:
					CheckMenuItem(hMenu, ID_RENDER_WIREFRAME, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_MATERIALCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_TESTMODE, MF_UNCHECKED);

					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_VERTCOLORS);
					GameDisplay();

					return 0;
				}
			case ID_RENDER_MATERIALCOLORS:
				{
					// Check this item in the menu:
					CheckMenuItem(hMenu, ID_RENDER_MATERIALCOLORS, MF_CHECKED);

					// And un-check everything else:
					CheckMenuItem(hMenu, ID_RENDER_WIREFRAME, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_VERTCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_TESTMODE, MF_UNCHECKED);

					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_MATCOLORS);
					GameDisplay();

					return 0;
				}
			case ID_RENDER_COMBINED:
				{
					// Check this item in the menu:
					CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_CHECKED);

					// And un-check everything else:
					CheckMenuItem(hMenu, ID_RENDER_WIREFRAME, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_VERTCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_MATERIALCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_TESTMODE, MF_UNCHECKED);

					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_COMBINED);
					GameDisplay();

					return 0;
				}
			case ID_RENDER_TESTMODE:
				{
					// Check this item in the menu:
					CheckMenuItem(hMenu, ID_RENDER_TESTMODE, MF_CHECKED);

					// And un-check everything else:
					CheckMenuItem(hMenu, ID_RENDER_WIREFRAME, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_VERTCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_MATERIALCOLORS, MF_UNCHECKED);
					CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_UNCHECKED);

					// Set the display mode:
					g_renderer->SetRenderMode(EIN_RENDER_TESTMODE);
					GameDisplay();
					
					return 0;
				}
			case ID_RENDER_RENDERINGPREFERENCES:
				{
					CreateRenderingPrefsWindow();

					return 0;
				}
			}
			return 0;
		}
	case WM_DISPLAYCHANGE:		// Called whenever the user changes the desktop resolution and/or color depth.
		{
			return 0;
		}

	case WM_SETFOCUS:			// Called whenever the application gains the keyboard focus.
		{
			return 0;
		}

	case WM_ACTIVATE:			// Called whenever the application is being activated or deactivated.
		{
			if (g_isAppFullScreen == true)
			{
				SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_FULLSCREEN, NULL);
			}

			return 0;
		}

	case WM_PAINT:				// Called whenever the window needs to be redrawn.
		{
			// Tell Windows to assume I've updated whatever needs updating.
			ValidateRect(hWnd, NULL);

			return 0;
		}
	case WM_SIZE:				// The window has been resized.
		{
			// Tell the Status Bar to update itself.			
			SendMessage(g_hWndStatusBar, uMessage, wParam, lParam);
			
			// Figure out the divisions for the status bar.
			int boxWidths[3];
			RECT parentRect;

			GetClientRect(g_hWndMain, &parentRect);

			boxWidths[0] = (parentRect.right - parentRect.left) / 2;
			boxWidths[1] = (parentRect.right - parentRect.left) - 78;
			boxWidths[2] = (parentRect.right - parentRect.left) - 18;

			// Feed the division information to the status bar.
			SendMessage(g_hWndStatusBar, SB_SETPARTS, 3, (LPARAM) boxWidths);

			// Figure out the new size for the render window.
			RECT statusBarRect;

			GetWindowRect(g_hWndStatusBar, &statusBarRect);

			UINT newWidth  = LOWORD(lParam);
			UINT newHeight = HIWORD(lParam) - (statusBarRect.bottom - statusBarRect.top);

			// Update the Render Window's size.
			MoveWindow(g_hWndRender, 0, 0, newWidth, newHeight, true);

			// And if the graphics system is initialized, we tell it to update it's size and then render the scene.
			if ((g_graphicsInitComplete == true) && (g_playerMesh != NULL) && (g_suspendResize == false))
			{
				// Call the game's resize function:
				GameResize(newWidth, newHeight, g_appWinBPPColor, g_appWinBPPDepth);
				
				// Render the scene:
				GameDisplay();
			}

			return 0;
		}
	case WM_MOVE:
		{
			// If we're in a windowed mode then we'll update our position globals.
			if ((g_isAppFullScreen == false) && (g_suspendResize == false))
			{
				// Get the app window's rect.
				RECT winRect;
				GetWindowRect(g_hWndMain, &winRect);

				// Update the app position globals.
				g_windowedPosition.x = winRect.left;
				g_windowedPosition.y = winRect.top;
			}

			// Tell the render window to update itself.
			SendMessage(g_hWndRender, WM_MOVE, wParam, lParam);

			return 0;
		}
	case WM_CLOSE:				// The window is about to be closed.
		{
			// Write out our preferences file.
			WritePreferencesFile();
			
			// Tell Windows to put a WM_QUIT message in our message queue
			PostQuitMessage(0);

			return 0;
		}
	default:					// Some other message.
		{
			// Let Windows handle the message.
			return (long) DefWindowProc(hWnd, uMessage, wParam, lParam);
		}
	}
}

//======================================================================
// CreateMainWindow() - Function to create a render window.
//======================================================================
int CreateMainWindow()
{
	// Instantiate a Window Class.
	WNDCLASSEX winClassMain;

	// Now we fill in the information for the main application's window class.
	winClassMain.cbSize			= sizeof(WNDCLASSEX);
	winClassMain.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_DBLCLKS ;
	winClassMain.cbClsExtra		= 0;
	winClassMain.cbWndExtra		= 0;
	winClassMain.lpfnWndProc	= WndProc_Main;
	winClassMain.hInstance		= g_hInstance;
	winClassMain.hbrBackground  = (HBRUSH) GetStockObject(BLACK_BRUSH);
	winClassMain.hIcon			= LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_APP_ICON));
	winClassMain.hIconSm		= LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_APP_ICON));
	winClassMain.hCursor		= LoadCursor(NULL, IDC_ARROW);
	winClassMain.lpszMenuName   = MAKEINTRESOURCE(IDR_MAIN_MENU);
	winClassMain.lpszClassName  = APP_NAME;

	// Now we register the window class.
	RegisterClassEx(&winClassMain);

	HWND hDesktopWnd = GetDesktopWindow();
	HDC  hDesktopDC  = GetDC(hDesktopWnd);
	
	g_desktopSize.x = GetDeviceCaps(hDesktopDC, HORZRES);
	g_desktopSize.y = GetDeviceCaps(hDesktopDC, VERTRES);

	// Read our application preferences from the external preferences file.
	if (g_graphicsInitComplete == false){ReadPreferencesFile();}		

	// Figure out the proper position for centering the window.
	UINT mainPosX = (g_desktopSize.x  / 2) - (g_appWinWidth  / 2);
	UINT mainPosY = (g_desktopSize.y / 2)  - (g_appWinHeight / 2);

	// And we create the window.
	g_hWndMain = CreateWindowEx(NULL,														// Extended Windows Style
							  APP_NAME,														// Class Name
							  APP_NAME,														// App Name
							  WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,						// Window Style
							  mainPosX, mainPosY,											// X and Y position.
							  g_appWinWidth, g_appWinHeight,							// Width and Height.
							  NULL,															// Parent window handle.
							  NULL,															// Menu
							  NULL,															// Obsolete in 2000/XP.
							  NULL);														// For MDI apps.

	return 0;
}








