//////////////////////////////////////////////////////////////
// Implementation file for the GameDisplay function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInDisplay.h"
#include "eInStaticMesh.h"
#include "uiFunctions.h"

extern eDISPLAY_OBJECT* g_renderer;
extern eSTATIC_MESH*	g_playerMesh;
extern eINPUTDEVICE*    g_input;
extern UINT			    g_frameCount;
extern bool				g_resetView;
extern Ce1nPlayer		player;
//extern bool			g_stereoWiggleOn;
extern UINT				g_curStereoMethod;

// Constants:
#define GAMEDISPLAY_XROT_BIAS 2.0f


// Function definition.
int GameDisplay()
{    
	// Static variables for joystick viewing transformations.
	static eVECT3 playerPos   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerAccel = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerVel   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerRot   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerLat   = eVECT3(0.0f, 0.0f, 0.0f);

	// Clear the screen and the depth buffer.
	g_renderer->ClearDrawBuffer(0.0f, 0.0f, 0.0f, 0.0f);

	glLoadIdentity();		// Reset the matrix.

	// Lighting
	GLfloat lightDir[] = {-250.0, 250.0, 250.0, 1.0};
	GLfloat white[] = {1.0, 1.0, 1.0, 1.0};
	glLightfv(GL_LIGHT0, GL_POSITION, lightDir);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white);
	glEnable(GL_LIGHT0);


	//------------------------------------------------------------
	// Application of Transformations:
	//------------------------------------------------------------
	
	// First we compute our forward/back translation based upon our rotation.
	player.vel.z =   (cos(PI / 180.0f * player.rot.y)) * player.accel.z;
	player.vel.x = -((sin(PI / 180.0f * player.rot.y)) * player.accel.z);

	// Then we compute our lateral translation based upon our rotation.
	player.lat.z =   (cos(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x;
	player.lat.x = -((sin(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x);

	player.pos.z += (player.vel.z + player.lat.z);
	player.pos.x += (player.vel.x + player.lat.x);

	player.pos.y += player.accel.y;

	// Reset the y acceleration. So we don't drift.
	player.accel.y = 0.0f;

	// Curve the x rotation between 0.0f and the Maximum.
	float xRotAmt;

	// Rotation transformations
	glRotatef(player.rot.x, 1.0f, 0.0f, 0.0f);
	glRotatef(player.rot.y, 0.0f, 1.0f, 0.0f);		

	// Translation transformation
	glTranslatef(player.pos.x, player.pos.y, player.pos.z);

	// Display calls to render the current mesh.
	g_renderer->RenderMesh(*g_playerMesh);

	g_renderer->SwapDeviceBuffers();

	return true;
}

//------------------------------------------------------------------------------

int GameDisplayStereo()
{    
	// Static variables for joystick viewing transformations.
	static eVECT3 playerPos   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerAccel = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerVel   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerRot   = eVECT3(0.0f, 0.0f, 0.0f);
	static eVECT3 playerLat   = eVECT3(0.0f, 0.0f, 0.0f);
		   eVECT3 stereoSep;

	// Clear the screen and the depth buffer.
	g_renderer->ClearDrawBuffer(0.0f, 0.0f, 0.0f, 0.0f);

	glLoadIdentity();		// Reset the matrix.

	// Lighting
	GLfloat lightDir[] = {-250.0, 250.0, 250.0, 1.0};
	GLfloat white[] = {1.0, 1.0, 1.0, 1.0};
	glLightfv(GL_LIGHT0, GL_POSITION, lightDir);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white);
	glEnable(GL_LIGHT0);

	//------------------------------------------------------------
	// Left Eye
	//------------------------------------------------------------

	// Set up the left eye's view frustrum:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Figure out the proper frustum settings for our display's aspect ratio:
	float frustWidth;
	
	if (g_renderer->inFullScreenMode == true){frustWidth = 1.0 / g_renderer->fullScreenAspect;}
	else									{frustWidth = 1.0 / g_renderer->windowedAspect;}

	// Calculate the eye offset.
	float eyeOffset = frustWidth * g_stereoAsymmetry;
	
	if (g_isSwapEyesOn == false)		// Eyes not swapped...
	{
		glFrustum(-frustWidth + eyeOffset, frustWidth + eyeOffset, -1.0f, 1.0f, 2, 9999);
		glMatrixMode(GL_MODELVIEW);

		// If our stereo mode is OpenGL...
		if (g_curStereoMethod == STEREOMETHOD_OPENGL)
		{
			glDrawBuffer(GL_BACK_LEFT);
		}
	}
	else								// Eyes swapped...
	{
		glFrustum(-frustWidth - eyeOffset, frustWidth - eyeOffset, -1.0f, 1.0f, 2, 9999);
		glMatrixMode(GL_MODELVIEW);

		// If our stereo mode is OpenGL...
		if (g_curStereoMethod == STEREOMETHOD_OPENGL)
		{
			glDrawBuffer(GL_BACK_RIGHT);
		}
	}

	// If our stereo mode is Anaglyph...
	if (g_curStereoMethod == STEREOMETHOD_ANAGLYPH)	
	{
		glColorMask(true, false, false, true);		// Filter the left eye to Red.
	}

	glLoadIdentity();

	//------------------------------------------------------------
	// Application of Transformations:
	//------------------------------------------------------------
	
	// First we compute our forward/back translation based upon our rotation.
	player.vel.z =   (cos(PI / 180.0f * player.rot.y)) * player.accel.z;
	player.vel.x = -((sin(PI / 180.0f * player.rot.y)) * player.accel.z);

	// Then we compute our lateral translation based upon our rotation.
	player.lat.z =   (cos(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x;
	player.lat.x = -((sin(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x);

	player.pos.z += (player.vel.z + player.lat.z);
	player.pos.x += (player.vel.x + player.lat.x);

	player.pos.y += player.accel.y;

	// Reset the y acceleration. So we don't drift.
	player.accel.y = 0.0f;

	// Rotation transformations
	glRotatef(player.rot.x, 1.0f, 0.0f, 0.0f);
	glRotatef(player.rot.y, 0.0f, 1.0f, 0.0f);		

	// Compute the stereo seperation:
	stereoSep.z =   (cos(PI / 180.0f * (player.rot.y - 90.0f))) * g_stereoSeparation;
	stereoSep.x = -((sin(PI / 180.0f * (player.rot.y - 90.0f))) * g_stereoSeparation);
	stereoSep.y = 0.0f;

	// Translate the scene (including an eye offset):
	if (g_isSwapEyesOn == false)
	{
		glTranslatef(player.pos.x + stereoSep.x, player.pos.y, player.pos.z + stereoSep.z);
	}
	else
	{
		glTranslatef(player.pos.x - stereoSep.x, player.pos.y, player.pos.z - stereoSep.z);
	}

	// Render the mesh:
	g_renderer->RenderMesh(*g_playerMesh);

	//------------------------------------------------------------
	// Right Eye
	//------------------------------------------------------------
	// Clear the depth buffer.
	glClear(GL_DEPTH_BUFFER_BIT);

	// Set up the right eye's view frustrum:
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (g_isSwapEyesOn == false)		// Eyes not swapped...
	{
		glFrustum(-frustWidth - eyeOffset, frustWidth - eyeOffset, -1.0f, 1.0f, 2, 9999);
		glMatrixMode(GL_MODELVIEW);

		// If our stereo mode is OpenGL...
		if (g_curStereoMethod == STEREOMETHOD_OPENGL)
		{
			glDrawBuffer(GL_BACK_RIGHT);
		}
	}
	else								// Eyes swapped...
	{
		glFrustum(-frustWidth + eyeOffset, frustWidth + eyeOffset, -1.0f, 1.0f, 2, 9999);
		glMatrixMode(GL_MODELVIEW);

		// If our stereo mode is OpenGL...
		if (g_curStereoMethod == STEREOMETHOD_OPENGL)
		{
			glDrawBuffer(GL_BACK_LEFT);
		}
	}
	
	// If our stereo mode is Anaglyph...
	if (g_curStereoMethod == STEREOMETHOD_ANAGLYPH)	
	{
		glColorMask(false, true, true, true);		// Filter the right eye to Cyan
	}

	glLoadIdentity();

	//------------------------------------------------------------
	// Application of Transformations:
	//------------------------------------------------------------
	
	// First we compute our forward/back translation based upon our rotation.
	player.vel.z =   (cos(PI / 180.0f * player.rot.y)) * player.accel.z;
	player.vel.x = -((sin(PI / 180.0f * player.rot.y)) * player.accel.z);

	// Then we compute our lateral translation based upon our rotation.
	player.lat.z =   (cos(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x;
	player.lat.x = -((sin(PI / 180.0f * (player.rot.y - 90.0f))) * player.accel.x);

	player.pos.z += (player.vel.z + player.lat.z);
	player.pos.x += (player.vel.x + player.lat.x);

	player.pos.y += player.accel.y;

	// Reset the y acceleration. So we don't drift.
	player.accel.y = 0.0f;

	// Rotation transformations
	glRotatef(player.rot.x, 1.0f, 0.0f, 0.0f);
	glRotatef(player.rot.y, 0.0f, 1.0f, 0.0f);		

	// Compute the stereo seperation:
	stereoSep.z =   (cos(PI / 180.0f * (player.rot.y - 90.0f))) * g_stereoSeparation;
	stereoSep.x = -((sin(PI / 180.0f * (player.rot.y - 90.0f))) * g_stereoSeparation);
	stereoSep.y = 0.0f;

	// Translate the scene (including an eye offset):
	if (g_isSwapEyesOn == false)
	{
		glTranslatef(player.pos.x - stereoSep.x, player.pos.y, player.pos.z - stereoSep.z);
	}
	else
	{
		glTranslatef(player.pos.x + stereoSep.x, player.pos.y, player.pos.z + stereoSep.z);
	}

	// Render the mesh:
	g_renderer->RenderMesh(*g_playerMesh);

	// We're done rendering. Swap the buffers to the screen.
	g_renderer->SwapDeviceBuffers();
	
	// If our stereo mode is Anaglyph, return the color mask to normal so we don't
	// streak old red pixels everywhere.
	if (g_curStereoMethod == STEREOMETHOD_ANAGLYPH)	
	{
		glColorMask(true, true, true, true);
	}

	return true;
}