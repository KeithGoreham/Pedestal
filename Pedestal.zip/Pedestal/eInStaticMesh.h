#pragma once

// Includes:
#include "stdafx.h"			// Precompiled headers.

#include "MiscFunctions.h"
#include "eInBasicMaterial.h"

// New data types:

// This structure provides an easy way to store a uv coordinate for a 3D vertex.
typedef struct CUVInformation
{
public:
	float u;
	float v;
} UVINFO;

using namespace std;

// Class definition:
typedef class CeInStaticMesh
{
public:
	
	// Header information.
	UINT		numVerts;			// Number of vertices in the model.
	UINT		numEdges;			// Number of visible edges in the model.
	UINT		numFaces;			// Number of faces in the model.
	UINT		numTVerts;			// Number of UV texture coordinates in the model.
	UINT		numNVerts;			// Number of vertex normals in the model.
	UINT		numCPVColors;		// Number of different CPV colors in the model.
	UINT		numMaterials;		// Number of different materials in the object.
	eRGBf		wireColor;			// Wireframe color.
	bool		meshGood;			// Variable to store whether our model successfully loaded or not.

	// 3D Data Array pointers.
	eVECT3*		verts;				// Pointer to an array of vertices.
	ePOINT2U*   edges;				// Pointer to an array of edge definitions.		
	ePOINT3U*	faces;				// Pointer to an array of face definitions.
	eVECT2*		tVerts;				// Pointer to an array of texture vertices.
	ePOINT3U*	tFaces;				// Pointer to an array of texture face definitions.
	eVECT3*		nVerts;				// Pointer to an array of vertex normals.
	ePOINT3U*	nFaces;				// Pointer to an array of vertex normal face definitions.
	ePOINT3U*	CPVFaces;			// Pointer to an array of CPV face definitions.
	eRGBf*		CPVColors;			// Pointer to an array of vertex colors.
	eBASIC_MAT*	materials;			// Pointer to an array of materials.
	ePOINT2U*   textureSizes;		// The x and y sizes of each material texture.
	UCHAR*		textureData;		// Pointer to an array of texture data.	

	// Plain arrays for OGL functions:
	float*	vertArray;				// Pointer to a straight array of all the verts in the model by triangle.
	float*	cpvArray;			// Pointer to a straight array of all the vertex colors in the model.
	float*	tVertArray;			// Pointer to a straight array of all the texture verts in the model.

	//------------------------------------------------------------
	// Constructors:
	//------------------------------------------------------------

	CeInStaticMesh(void){};

	//------------------------------------------------------------
	// Destructor:
	//------------------------------------------------------------
	~CeInStaticMesh()
	{
		if (verts      != NULL){delete[] verts;}
		if (edges	   != NULL){delete[] edges;}
		if (faces	   != NULL){delete[] faces;}
		if (nFaces	   != NULL){delete[] nFaces;}
		if (CPVFaces   != NULL){delete[] CPVFaces;}
		if (tFaces	   != NULL){delete[] tFaces;}
		if (nVerts	   != NULL){delete[] nVerts;}
		if (CPVColors  != NULL){delete[] CPVColors;}
		if (materials  != NULL){delete[] materials;}
		if (tVerts	   != NULL){delete[] tVerts;}
		if (vertArray  != NULL){delete[] vertArray;}
		if (cpvArray   != NULL){delete[] cpvArray;}
		if (tVertArray != NULL){delete[] tVertArray;}		
	}

	//------------------------------------------------------------
	// This function reads the data for a mesh from an .ESSM file.
	//------------------------------------------------------------
	bool loadESSM(const char* fileName)
	{
		char buffer[512];

		// Declare a filestream object for loading.
		ifstream inFile;
		
		// Open that filestream in the input mode.
		inFile.open(fileName, ios::binary);

		if (!inFile.is_open())
		{
			// Closing the file:
			inFile.close();
			return false;
		}

		meshGood = true;

		// Reading file header information:
		inFile.read((char*) &numVerts,	   sizeof(numVerts));
		inFile.read((char*) &numEdges,	   sizeof(numEdges));
		inFile.read((char*) &numFaces,     sizeof(numFaces));
		inFile.read((char*) &numTVerts,	   sizeof(numTVerts));
		inFile.read((char*) &numNVerts,    sizeof(numNVerts));
		inFile.read((char*) &numCPVColors, sizeof(numCPVColors));
		inFile.read((char*) &numMaterials, sizeof(numMaterials));
		
		sprintf(buffer, "%d verticies read\n", numVerts);
		OutputDebugString(buffer);

		sprintf(buffer, "%d edges read\n", numEdges);
		OutputDebugString(buffer);

		sprintf(buffer, "%d faces read\n", numFaces);
		OutputDebugString(buffer);

		sprintf(buffer, "%d texture verticies read\n", numTVerts);
		OutputDebugString(buffer);

        sprintf(buffer, "%d normal verticies read\n", numNVerts);
		OutputDebugString(buffer);

		sprintf(buffer, "%d CPV verticies read\n", numCPVColors);
		OutputDebugString(buffer);

		sprintf(buffer, "%d materials read\n", numMaterials);
		OutputDebugString(buffer);

		// Reading the wireframe color:
		inFile.read((char*) &wireColor, sizeof(wireColor));

		OutputDebugString("Wireframe Read, Allocating Memory.\n");

		// Allocating Memory for the Mesh Data:
		verts		 = new eVECT3[numVerts];
		edges		 = new ePOINT2U[numEdges];
		faces		 = new ePOINT3U[numFaces];
		tVerts		 = new eVECT2[numTVerts];
		tFaces       = new ePOINT3U[numFaces];
		nVerts       = new eVECT3[numNVerts];
		nFaces		 = new ePOINT3U[numFaces];
		CPVFaces	 = new ePOINT3U[numFaces];
		CPVColors	 = new eRGBf[numCPVColors];
		materials    = new eBASIC_MAT[numMaterials];

		OutputDebugString("Memory Allocated, Reading Mesh Data.\n");

		//-------------------------------------------------------
		// Reading the mesh data:
		//-------------------------------------------------------
	
		inFile.read((char*) verts,       sizeof(eVECT3)  * numVerts);			// First the vertices.
		inFile.read((char*) edges,       sizeof(ePOINT2U) * numEdges);			// Then the edges.
		inFile.read((char*) faces,       sizeof(ePOINT3U) * numFaces);			// Now the face definitions.
		inFile.read((char*) tVerts,      sizeof(eVECT2)  * numTVerts);			// The Texture Vertices.
		inFile.read((char*) tFaces,      sizeof(ePOINT3U) * numFaces);			// The Texture Face Definitions.
		inFile.read((char*) nVerts,		 sizeof(eVECT3)  * numNVerts);			// The vertex normals.
		inFile.read((char*) nFaces,		 sizeof(ePOINT3U) * numFaces);			// The normal face definitions.
		inFile.read((char*) CPVFaces,    sizeof(ePOINT3U) * numFaces);			// Then the CPV Faces.
		inFile.read((char*) CPVColors,   sizeof(eRGBf)   * numCPVColors);		// And now for the CPV colors.

		OutputDebugString("Reading Material Data.\n");

		// And lastly comes the material definitions themselves:
		for (UINT i = 0; i < numMaterials; i++)
		{
			OutputDebugString("Reading Ambient - Emissive Data.\n");

			// First we read the material colors:
			inFile.read((char*) &materials[i].ambient,   sizeof(materials[i].ambient));			// Ambient color
			inFile.read((char*) &materials[i].diffuse,   sizeof(materials[i].diffuse));			// Diffuse color
			inFile.read((char*) &materials[i].specular,  sizeof(materials[i].specular));		// Specular color
			inFile.read((char*) &materials[i].shininess, sizeof(materials[i].shininess));		// Shininess scalar
			inFile.read((char*) &materials[i].emissive,  sizeof(materials[i].emissive));		// Emmissive color

			OutputDebugString("Reading Material Face Data.\n");

			// Read the number of faces which use this material:
			inFile.read((char*) &materials[i].numMatFaces, sizeof(materials[i].numMatFaces));

			// Read the index of the first face which uses this material:
			inFile.read((char*) &materials[i].firstMatFace, sizeof(materials[i].firstMatFace));

			// Read the index of the last face which uses this material:
			inFile.read((char*) &materials[i].lastMatFace, sizeof(materials[i].lastMatFace));

			OutputDebugString("Reading DiffuseMap Size.\n");

			// Read the size of this material's diffusemap:
			inFile.read((char*) &materials[i].diffuseMapSize.x, sizeof(materials[i].diffuseMapSize.x));
			inFile.read((char*) &materials[i].diffuseMapSize.y, sizeof(materials[i].diffuseMapSize.y));
			
			sprintf(buffer, "DiffuseMap Size is %d x %d\n", materials[i].diffuseMapSize.x, materials[i].diffuseMapSize.y);
			OutputDebugString(buffer);

			OutputDebugString("Allocating DiffuseMap Memory.\n");

			// Figure out how much memory we'll need to allocate.
			UINT diffuseMemSize = (materials[i].diffuseMapSize.x * materials[i].diffuseMapSize.y) * 4;

			

			// Now we allocate memory for the texture:
			materials[i].diffuseMapData = new UCHAR[diffuseMemSize];
			
			OutputDebugString("Reading DiffuseMap Data.\n");

			//// And now we read the data:
			inFile.read((char*) materials[i].diffuseMapData, diffuseMemSize);
		}

		OutputDebugString("Closing File.\n");

		// Closing the file:
		inFile.close();

		// Now we convert the data we already have into the straight arrays appropriate for the OGL functions.
		vertArray		= new float[numFaces * 9];			
		cpvArray		= new float[numFaces * 9];
		tVertArray		= new float[numFaces * 6];

//		nVertArray		= new float[numFaces * 9];
//		vertEdgeArray	= new bool[numFaces * 3];

		// Write out the vertex array.
		for (i = 0; i < numFaces; i++)		// Step through each face.
		{
			// First Vertex for this triangle.
			vertArray[(i * 9) + 0] = verts[faces[i].x].x;
			vertArray[(i * 9) + 1] = verts[faces[i].x].y;
			vertArray[(i * 9) + 2] = verts[faces[i].x].z;

			cpvArray[(i * 9) + 0] = CPVColors[CPVFaces[i].x].r;
			cpvArray[(i * 9) + 1] = CPVColors[CPVFaces[i].x].g;
			cpvArray[(i * 9) + 2] = CPVColors[CPVFaces[i].x].b;

			tVertArray[(i * 6) + 0] = tVerts[tFaces[i].x].x;
			tVertArray[(i * 6) + 1] = tVerts[tFaces[i].x].y;

			// Second Vertex for this triangle.
			vertArray[(i * 9) + 3] = verts[faces[i].y].x;
			vertArray[(i * 9) + 4] = verts[faces[i].y].y;
			vertArray[(i * 9) + 5] = verts[faces[i].y].z;

			cpvArray[(i * 9) + 3] = CPVColors[CPVFaces[i].y].r;
			cpvArray[(i * 9) + 4] = CPVColors[CPVFaces[i].y].g;
			cpvArray[(i * 9) + 5] = CPVColors[CPVFaces[i].y].b;

			tVertArray[(i * 6) + 2] = tVerts[tFaces[i].y].x;
			tVertArray[(i * 6) + 3] = tVerts[tFaces[i].y].y;

			// Third Vertex for this triangle.
			vertArray[(i * 9) + 6] = verts[faces[i].z].x;
			vertArray[(i * 9) + 7] = verts[faces[i].z].y;
			vertArray[(i * 9) + 8] = verts[faces[i].z].z;

			cpvArray[(i * 9) + 6] = CPVColors[CPVFaces[i].z].r;
			cpvArray[(i * 9) + 7] = CPVColors[CPVFaces[i].z].g;
			cpvArray[(i * 9) + 8] = CPVColors[CPVFaces[i].z].b;

			tVertArray[(i * 6) + 4] = tVerts[tFaces[i].z].x;
			tVertArray[(i * 6) + 5] = tVerts[tFaces[i].z].y;
		}
		OutputDebugString("Model Loaded\n");

		return true;
	}

} eSTATIC_MESH;
