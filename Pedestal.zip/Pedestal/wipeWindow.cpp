//////////////////////////////////////////////////////////////
// Implementation file for the Main UI Wipe 
// Window. This window will be used to cover over things we 
// don't want to see during resolution mode changes, etc.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//=========================================================================
// WndProc_WipeWindow() - Our Windows event handler for the splash screen.
//=========================================================================
long CALLBACK WndProc_WipeWindow(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	// Now we run a switch on the message to decide what to do.
	switch (uMessage)
	{
	case WM_CREATE:				// Called when the window is created.
		{
			int deskWidth;
			int deskHeight;
            
			int splashPosX;
			int splashPosY;

			HWND hDesktopWnd = GetDesktopWindow();
			HDC  hDesktopDC  = GetDC(hDesktopWnd);

			// Retrieve the width and height of the display.
			deskWidth  = GetDeviceCaps(hDesktopDC, HORZRES);
			deskHeight = GetDeviceCaps(hDesktopDC, VERTRES);

			// And set the position.
			SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, deskWidth, deskHeight, NULL); 
	
			return 0;
		}
	default:					// Some other message.
		{
			// Let Windows handle the message.
			return (long) DefWindowProc(hWnd, uMessage, wParam, lParam);
		}
	}
}

//======================================================================
// CreateWipeWindow() - Function to create the Splash Screen window.
//======================================================================
int CreateWipeWindow(void)
{
	// Instantiate a Window Class.
	WNDCLASSEX winClassFSBlackWin;

	// Now we modify the winClass information for our Splash Window.
	winClassFSBlackWin.cbSize		  = sizeof(WNDCLASSEX);
	winClassFSBlackWin.style		  = CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_SAVEBITS;
	winClassFSBlackWin.cbClsExtra	  = 0;
	winClassFSBlackWin.cbWndExtra	  = 0;
	winClassFSBlackWin.lpfnWndProc	  = WndProc_WipeWindow;
	winClassFSBlackWin.hInstance	  = g_hInstance;
	winClassFSBlackWin.hbrBackground  = (HBRUSH) GetStockObject(BLACK_BRUSH);
	winClassFSBlackWin.hIcon		  = NULL;
	winClassFSBlackWin.hIconSm		  = NULL;
	winClassFSBlackWin.hCursor		  = NULL;
	winClassFSBlackWin.lpszMenuName   = NULL;
	winClassFSBlackWin.lpszClassName  = WIPE_WINDOW_NAME;

	// Now we register the window classes.
	RegisterClassEx(&winClassFSBlackWin);

	// And we create the window.
	g_hWndWipeWindow = CreateWindowEx(NULL,											// Extended Windows Style
									  WIPE_WINDOW_NAME,								// Class Name
									  APP_NAME,										// App Name
									  WS_POPUP,										// Window Style
									  0, 0,											// X and Y position.
									  SPLASH_WINDOW_WIDTH, SPLASH_WINDOW_HEIGHT,	// Width and Height.
									  NULL,
									  NULL,											// Menu
									  NULL,											// Obsolete in 2000/XP.
									  NULL);										// For MDI apps.

	return 0;
}