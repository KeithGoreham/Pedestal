//////////////////////////////////////////////////////////////
// Implementation file for the GameShutdown function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInDisplay.h"
#include "eInStaticMesh.h"

// Preprocessor directives:
#pragma once

// Externally defined global pointers:
extern eDISPLAY_OBJECT* g_renderer;				// Pointer to our display class that draws stuff on the screen.
extern eSTATIC_MESH*	g_playerMesh;			// Pointer to the player's mesh object.
extern float*		 	g_pureHueVals;			// Pointer to a lookup table of pure hue values.

// Function definition.
int GameShutdown()
{   
	// Deleting globally defined heap data.
	if (g_renderer    != NULL){delete g_renderer;}
	if (g_playerMesh != NULL){delete g_playerMesh;}

    return 0;
}