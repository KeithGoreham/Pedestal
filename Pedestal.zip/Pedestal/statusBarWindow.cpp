//////////////////////////////////////////////////////////////
// Implementation file for the Main UI window's status bar.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//======================================================================
// CreateStatusBarWindow() - Function to create a render window.
//======================================================================
int CreateStatusBarWindow(void)
{
	// Let's give the main window a status bar.
	g_hWndStatusBar = CreateStatusWindow(WS_CHILD | WS_VISIBLE | WS_BORDER | SBARS_SIZEGRIP,
										 " Ready",
										 g_hWndMain,
										 1);
	
	int boxRight[3];
	RECT parentRect;

	GetClientRect(g_hWndMain, &parentRect);

	boxRight[0] = (parentRect.right - parentRect.left) / 2;
	boxRight[1] = (parentRect.right - parentRect.left) - 78;
	boxRight[2] = (parentRect.right - parentRect.left) - 18;

	SendMessage(g_hWndStatusBar, SB_SETPARTS, 3, (LPARAM) boxRight);

	return 0;
}