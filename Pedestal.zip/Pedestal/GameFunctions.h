//////////////////////////////////////////////////////////////
// Interface file for all Game functions.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Function declarations.
int GameInit(HWND hWndTest, HWND hWndAppMain);
int GameLoop();
int GameShutdown();
int GameDisplay();
int GameDisplayStereo();
int GameSound();
int GameInput();
int GameAI();
int GamePhysics();
int GameResize(UINT &newWidth, UINT &newHeight, UINT &newBPPColor, UINT &newBPPDepth);