//////////////////////////////////////////////////////////////
// Interface file for the structs and classes used to store 
// various Pedestal Application Settings.
//
// �2007 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Precompiled header files.
#include "stdafx.h"

// Monitor Structs
struct SPedDisplaySettings
{
	ePOINT2 fullScreenRes;
	ePOINT2 desktopSize;
	RECT	desktopRect;
	UINT	fullScreenBPPColor;
	UINT	fullScreenBPPDepth;
	UINT	fullScreenRefresh;
	float	fullScreenAspect;
};

struct SPedAppSettings
{
	RECT	desktopVirScreenRect;
	ePOINT2 appWinSize;
	bool	graphicsInitComplete;
	bool	suspendResize;
	char	defaultModelFile[256];
	UINT	frameCount;
	bool	resetView;
	bool	appIsMaximized;
	bool	appIsFullScreen;
	bool	stereoIsOn;
	UINT	stereoMethod;
	bool	antialiasingIsOn;
	bool	swapEyesIsOn;
	float	stereoSeparation;
	float	stereoAsymmetry;
	ePOINT2 appWinPos;
};