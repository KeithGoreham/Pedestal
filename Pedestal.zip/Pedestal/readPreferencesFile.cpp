//////////////////////////////////////////////////////////////
// Implementation file for the function used to read in 
// the Pedestal application preferences from an external file.
//
// �2007 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//======================================================================
// ReadPreferencesFile() - Function used to read preferences from an
// external .xml file.
//======================================================================
int ReadPreferencesFile(void)
{
	using namespace std;

	// The XML parser has no way of checking for the existence of a file. So
	// we'll try to open the file using a standard file stream just to see if
	// the file exists.
	ifstream inFile;
	inFile.open(APP_PREFERENCES_FILE, ios::in);

	// Test to see if the file opened using the stream.
	if(inFile.good())
	{
		// And if so we close the stream before using the XML parser methods.
		inFile.close();

		// Open and parse the preferences file:
		XMLNode xMainNode = XMLNode::openFileHelper(APP_PREFERENCES_FILE, "pedestalApplicationPreferences");

		// Get the nodes for each of the major preferences categories:
		XMLNode xDisplayPrefs    = xMainNode.getChildNode("displayPreferences");
		XMLNode xFullScreenPrefs = xMainNode.getChildNode("fullScreenPreferences");
		XMLNode xStereoPrefs     = xMainNode.getChildNode("stereoPreferences");

		// Get the nodes for the display preferences:
		if (!xDisplayPrefs.isEmpty())
		{
			// Grab node information:
			XMLNode xAppWinWidth     = xDisplayPrefs.getChildNode("appWinWidth");
			XMLNode xAppWinHeight    = xDisplayPrefs.getChildNode("appWinHeight");
			XMLNode xAppIsMaximized  = xDisplayPrefs.getChildNode("appIsMaximized");
			XMLNode xAppWinBPPColor  = xDisplayPrefs.getChildNode("appWinBPPColor");
			XMLNode xAppWinBPPDepth  = xDisplayPrefs.getChildNode("appWinBPPDepth");
			XMLNode xAppWinBPPAlpha  = xDisplayPrefs.getChildNode("appWinBPPAlpha");
			XMLNode xAppWinBPPAccum  = xDisplayPrefs.getChildNode("appWinBPPAccum");

			// Use nodes to set global variables:
			if (!xAppWinWidth.isEmpty())   {g_appWinWidth	 = atoi(xAppWinWidth.getText());}
			if (!xAppWinHeight.isEmpty())  {g_appWinHeight   = atoi(xAppWinHeight.getText());}
			if (!xAppIsMaximized.isEmpty()){g_isAppMaximized = atoi(xAppIsMaximized.getText());}
			if (!xAppWinBPPColor.isEmpty()){g_appWinBPPColor = atoi(xAppWinBPPColor.getText());}
			if (!xAppWinBPPDepth.isEmpty()){g_appWinBPPDepth = atoi(xAppWinBPPDepth.getText());}
			if (!xAppWinBPPAlpha.isEmpty()){g_appWinBPPAlpha = atoi(xAppWinBPPAlpha.getText());}
			if (!xAppWinBPPAccum.isEmpty()){g_appWinBPPAccum = atoi(xAppWinBPPAccum.getText());}

			// Bounds check on global variables:
			if (g_appWinWidth  <  640){g_appWinWidth  = 640;}
			if (g_appWinHeight <  480){g_appWinHeight = 480;}
			if (g_appWinWidth  > g_desktopSize.x){g_appWinWidth  = g_desktopSize.x - 60;}
			if (g_appWinHeight > g_desktopSize.y){g_appWinHeight = g_desktopSize.y - 60;}
			if (g_appWinBPPColor != 32) {g_appWinBPPColor = 32;}
			if (g_appWinBPPDepth != 16) {g_appWinBPPDepth = 16;}
			if (g_appWinBPPAlpha != 8)  {g_appWinBPPAlpha = 8;}
			if (g_appWinBPPAccum != 24) {g_appWinBPPAccum = 24;}
		}

		// Get the nodes for the full screen preferences:
		if (!xFullScreenPrefs.isEmpty())
		{
			// Grab the individual monitor nodes:
			XMLNode xFSNMonitor1 = xFullScreenPrefs.getChildNode("fsnMonitor1");
			XMLNode xFSNMonitor2 = xFullScreenPrefs.getChildNode("fsnMonitor2");
			XMLNode xFSNMonitor3 = xFullScreenPrefs.getChildNode("fsnMonitor3");
			XMLNode xFSNMonitor4 = xFullScreenPrefs.getChildNode("fsnMonitor4");

			// Grab the sub-nodes for monitor 1:
			XMLNode xFSNWidth  = xFSNMonitor1.getChildNode("fsnWidth");
			XMLNode xFSNHeight = xFSNMonitor1.getChildNode("fsnHeight");

			// Use monitor 1 nodes to set global variables:
			if (!xFSNWidth.isEmpty()) {g_fullScreenResolutions[0].x = atoi(xFSNWidth.getText());}
			if (!xFSNHeight.isEmpty()){g_fullScreenResolutions[0].y = atoi(xFSNHeight.getText());}

			// Bounds check on global variables:
			if (g_fullScreenResolutions[0].x  <  640){g_fullScreenResolutions[0].x  = 640;}
			if (g_fullScreenResolutions[0].y  <  480){g_fullScreenResolutions[0].y  = 480;}

			// Grab the sub-nodes for monitor 2:
			xFSNWidth  = xFSNMonitor2.getChildNode("fsnWidth");
			xFSNHeight = xFSNMonitor2.getChildNode("fsnHeight");

			// Use monitor 2 nodes to set global variables:
			if (!xFSNWidth.isEmpty()) {g_fullScreenResolutions[1].x = atoi(xFSNWidth.getText());}
			if (!xFSNHeight.isEmpty()){g_fullScreenResolutions[1].y = atoi(xFSNHeight.getText());}

			// Bounds check on global variables:
			if (g_fullScreenResolutions[1].x  <  640){g_fullScreenResolutions[1].x  = 640;}
			if (g_fullScreenResolutions[1].y  <  480){g_fullScreenResolutions[1].y  = 480;}

			// Grab the sub-nodes for monitor 3:
			xFSNWidth  = xFSNMonitor3.getChildNode("fsnWidth");
			xFSNHeight = xFSNMonitor3.getChildNode("fsnHeight");

			// Use monitor 3 nodes to set global variables:
			if (!xFSNWidth.isEmpty()) {g_fullScreenResolutions[2].x = atoi(xFSNWidth.getText());}
			if (!xFSNHeight.isEmpty()){g_fullScreenResolutions[2].y = atoi(xFSNHeight.getText());}

			// Bounds check on global variables:
			if (g_fullScreenResolutions[2].x  <  640){g_fullScreenResolutions[2].x  = 640;}
			if (g_fullScreenResolutions[2].y  <  480){g_fullScreenResolutions[2].y  = 480;}

			// Grab the sub-nodes for monitor 4:
			xFSNWidth  = xFSNMonitor4.getChildNode("fsnWidth");
			xFSNHeight = xFSNMonitor4.getChildNode("fsnHeight");

			// Use monitor 4 nodes to set global variables:
			if (!xFSNWidth.isEmpty()) {g_fullScreenResolutions[3].x = atoi(xFSNWidth.getText());}
			if (!xFSNHeight.isEmpty()){g_fullScreenResolutions[3].y = atoi(xFSNHeight.getText());}

			// Bounds check on global variables:
			if (g_fullScreenResolutions[3].x  <  640){g_fullScreenResolutions[3].x  = 640;}
			if (g_fullScreenResolutions[3].y  <  480){g_fullScreenResolutions[3].y  = 480;}
		}

		// Get the nodes for the stereo rendering preferences:
		if (!xStereoPrefs.isEmpty())
		{
			// Grab node information:
			XMLNode xSTORenderingMethod = xStereoPrefs.getChildNode("stoRenderingMethod");
			XMLNode xSTOSeparation		= xStereoPrefs.getChildNode("stoSeparation");
			XMLNode xSTOAsymmetry		= xStereoPrefs.getChildNode("stoAsymmetry");
			XMLNode xSTOSwapEyes		= xStereoPrefs.getChildNode("stoSwapEyes");

			// Use nodes to set global variables:
			if (!xSTORenderingMethod.isEmpty()){g_curStereoMethod  = atoi(xSTORenderingMethod.getText());}
			if (!xSTOSeparation.isEmpty())	   {g_stereoSeparation = atof(xSTOSeparation.getText());}
			if (!xSTOAsymmetry.isEmpty())	   {g_stereoAsymmetry  = atof(xSTOAsymmetry.getText());}
			if (!xSTOSwapEyes.isEmpty())	   {g_isSwapEyesOn     = atoi(xSTOSwapEyes.getText());}

			// Bounds check on global variables:
			if ((g_curStereoMethod < 0)     || (g_curStereoMethod  > 1))   {g_curStereoMethod  = STEREOMETHOD_DEFAULT;}
			if ((g_stereoSeparation < 0.0f) || (g_stereoSeparation > 3.2f)){g_stereoSeparation = STEREO_DEFAULTSEPERATION;}
			if ((g_stereoAsymmetry  < 0.0f) || (g_stereoAsymmetry  > 0.2f)){g_stereoAsymmetry  = STEREO_DEFAULTASYMMETRY;}
		}
	}

	


	
	return 0;
}