#pragma once

class MiscGameFunctions
{
public:
	MiscGameFunctions(void);
	~MiscGameFunctions(void);
};
