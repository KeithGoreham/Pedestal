//////////////////////////////////////////////////////////
// TestDisplayFeatures.cpp - Implementation file. Part of
// the eIngine game engine.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// includes:
#include "eInDisplay.h"
#include "stdafx.h"

//------------------------------------------------------------
// This function tests the display's capabilities for features
// such as full screen anti-aliasing.
//------------------------------------------------------------
bool CeInDisplay::TestDisplayFeatures()
{
	char buffer[256];

	// Grab the BPP for the color and depth buffers.
	bppColor = 24;
	bppDepth = 16;

	// Setup Pixel Format
	FSAA0Format = ChoosePixelFormat(testDC, &pfd);
	if (FSAA0Format == 0) {OutputDebugString("ChoosePixelFormat FSAA0 Failed\n");}
	else				  
	{
		sprintf(buffer, "ChoosePixelFormat FSAA0 Succeeded: format %d\n", FSAA0Format);
		OutputDebugString(buffer);
	}
	SetPixelFormat(testDC, FSAA0Format, &pfd);

	// Create an OpenGl rendering context.
	testRC = wglCreateContext(testDC);				
	
	// Make rendering context current.
	bool foo = wglMakeCurrent(testDC, testRC);					
	if (foo == false) {OutputDebugString("wglMakeCurrent Failed\n");}
	else			  {OutputDebugString("wglMakeCurrent Succeeded\n");}

	// Try and Get Our Pixel Format Function Pointer.
	PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");	

	// If that didn't work...
	if (!wglChoosePixelFormatARB) 
	{
		OutputDebugString("wglChoosePixelFormatARB failed.\n");

		FSAAEnabled	  = false;
		FSAASupported = false;

		FSAA8Format = 0;
		FSAA4Format = 0;
		FSAA2Format = 0;

		return false;
	} 
	else {OutputDebugString("wglChoosePixelFormatARB succeeded.\n");}

	//------------------------------------------------------------
	// Test for Multisampling.
	//------------------------------------------------------------

	// Other variables:
	int		pixelFormat;				// Integer for the returned pixel format.
	int		valid = 0;					// Holds whether or not the wglChoosePixelFormatARB pixel format query was successful.
	UINT	numFormats;					// Number of pixel formats returned by wglChoosePixelFormatARB.
	float	fAttributes[] = {0,0};		// Array to hold the attributes we want in a pixel format.

	// Get the list of supported extensions
	char* extensionList = (char*) glGetString(GL_EXTENSIONS);

	// Define the string we want to search for.
	char extensionName[] = "GL_ARB_multisample";

	foo = CheckExtension("GL_ARB_multisample");
	if (foo == false) {OutputDebugString("CheckExtension Failed\n");}
	else			  {OutputDebugString("CheckExtension Succeeded\n");}

	// Now we set the attributes we want in a pixel format, including multisampling and stereo rendering
	// support. The important fields here for multisampling are WGL_SAMPLE_BUFFERS_ARB and WGL_SAMPLES_ARB.
	// WGL_STEREO_ARB denotes whether stereo rendering is available.
	int iAttributesStereo[] =
	{
		WGL_DRAW_TO_WINDOW_ARB, GL_TRUE,
		WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
		WGL_ACCELERATION_ARB,   WGL_FULL_ACCELERATION_ARB,
		WGL_COLOR_BITS_ARB,		24,
		WGL_ALPHA_BITS_ARB,		8,
		WGL_DEPTH_BITS_ARB,		16,
		WGL_STENCIL_BITS_ARB,	0,
		WGL_DOUBLE_BUFFER_ARB,	GL_TRUE,
		WGL_SAMPLE_BUFFERS_ARB, GL_TRUE,					// FSAA or not to FSAA?
		WGL_SAMPLES_ARB,		16,							// Number of Samples for Anti-Aliasing
		WGL_STEREO_ARB,			GL_TRUE,					// Stereo Rendering?
		0,0
	};


	// First we'll check for stereo support with 16 samples:
	valid = wglChoosePixelFormatARB(testDC,iAttributesStereo,fAttributes,1,&pixelFormat,&numFormats);
	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		stereoSupported		= true;
		StereoFSAA16Format	= pixelFormat;	

		sprintf(buffer, "16 Multisample Stereo Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// Now we'll check for stereo support with 8 samples:
	iAttributesStereo[19] = 8;
	valid = wglChoosePixelFormatARB(testDC,iAttributesStereo,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		stereoSupported = true;
		StereoFSAA8Format	= pixelFormat;

		sprintf(buffer, "8 Multisample Stereo Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// And then 4 samples:
	iAttributesStereo[19] = 4;
	valid = wglChoosePixelFormatARB(testDC,iAttributesStereo,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		stereoSupported = true;
		StereoFSAA4Format	= pixelFormat;

		sprintf(buffer, "4 Multisample Stereo Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// And then 2 samples:
	iAttributesStereo[19] = 2;
	valid = wglChoosePixelFormatARB(testDC,iAttributesStereo,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		stereoSupported = true;
		StereoFSAA2Format	= pixelFormat;

		sprintf(buffer, "2 Multisample Stereo Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// Then finally no samples at all.
	iAttributesStereo[17] = GL_FALSE;		// No multisampling please.
	iAttributesStereo[19] = 0;				// No samples.
	valid = wglChoosePixelFormatARB(testDC,iAttributesStereo,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		stereoSupported = true;
		StereoFSAA0Format	= pixelFormat;

		sprintf(buffer, "0 Multisample Stereo Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	int iAttributesMono[] =
	{
		WGL_DRAW_TO_WINDOW_ARB, GL_TRUE,
		WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
		WGL_ACCELERATION_ARB,   WGL_FULL_ACCELERATION_ARB,
		WGL_COLOR_BITS_ARB,		24,
		WGL_ALPHA_BITS_ARB,		8,
		WGL_DEPTH_BITS_ARB,		16,
		WGL_STENCIL_BITS_ARB,	0,
		WGL_DOUBLE_BUFFER_ARB,	GL_TRUE,
		WGL_SAMPLE_BUFFERS_ARB, GL_TRUE,					// FSAA or not to FSAA?
		WGL_SAMPLES_ARB,		16,							// Number of Samples for Anti-Aliasing
		0,0
	};

	valid = wglChoosePixelFormatARB(testDC,iAttributesMono,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		FSAA8Format = pixelFormat;	

		sprintf(buffer, "16 Multisample Mono Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// Now we check to see if we can get 8 samples.
	iAttributesMono[19] = 8;			// Set the number of desired samples to 4.

	valid = wglChoosePixelFormatARB(testDC,iAttributesMono,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		FSAA8Format = pixelFormat;	

		sprintf(buffer, "8 Multisample Mono Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// Then we check to see if we can get 4 samples.
	iAttributesMono[19] = 4;		// Set the number of desired samples to 4.

	valid = wglChoosePixelFormatARB(testDC,iAttributesMono,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		FSAA4Format = pixelFormat;

		sprintf(buffer, "4 Multisample Mono Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// And finally we check to see if we can get 2 samples.
	iAttributesMono[19] = 2;		// Set the number of desired samples to 2.

	valid = wglChoosePixelFormatARB(testDC,iAttributesMono,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAASupported = true;
		FSAA2Format = pixelFormat;

		sprintf(buffer, "2 Multisample Mono Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// And last but not least, can we get mono rendering with no multisampling?
	iAttributesMono[17] = GL_FALSE;	// No multisampling please.
	iAttributesMono[19] = 0;		// Set the number of desired samples to 0.

	valid = wglChoosePixelFormatARB(testDC,iAttributesMono,fAttributes,1,&pixelFormat,&numFormats);

	if (valid && numFormats >= 1)
	{
		FSAA0Format = pixelFormat;

		sprintf(buffer, "0 Multisample Mono Rendering Supported: Format %d\n", pixelFormat);
		OutputDebugString(buffer);
	}

	// Now that we're done, select and delete the current DC.
	wglMakeCurrent(testDC, NULL);
	wglDeleteContext(testRC);
	ReleaseDC(mainWnd, testDC);

	return true;
}