//////////////////////////////////////////////////////////////
// Implementation file for the Stereo Preferences Panel Window
// and it's associated functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"


INT_PTR CALLBACK DlgProc_StereoPrefs(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HWND hWndCboMethod;			// Handle to the Stereo Method combo box.
	static HWND hWndBtnOK;				// Handle to the OK Button.
	static HWND hWndSldSeperation;		// Handle to the Seperation trackbar control.
	static HWND hWndSldAsymmetry;		// Handle to the asymmetry trackbar control.
	static HWND hWndTxtSeperation;		// Handle to the Seperation text box.
	static HWND hWndTxtAsymmetry;		// Handle to the Asymmetry text box.
	static HWND hWndChkSwapEyes;		// Handle to the Swap Eyes check box.

	static bool  wasStereoOn;			// Stores whether stereo was enabled when the panel was opened.
	static UINT  oldStereoMethod;
	static float oldStereoSeperation;
	static float oldStereoAsymmetry;
	static bool  wereEyesSwapped;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		{
			hWndCboMethod	  = GetDlgItem(hWnd, cboStereoMethods);
			hWndBtnOK		  = GetDlgItem(hWnd, IDOK);
			hWndSldSeperation = GetDlgItem(hWnd, sldSeperation);
			hWndSldAsymmetry  = GetDlgItem(hWnd, sldAsymmetry);
			hWndTxtSeperation = GetDlgItem(hWnd, txtSeperation);
			hWndTxtAsymmetry  = GetDlgItem(hWnd, txtAsymmetry);
			hWndChkSwapEyes   = GetDlgItem(hWnd, chkSwapEyes);

			wasStereoOn			= g_isStereoOn;
			oldStereoMethod     = g_curStereoMethod;
			oldStereoSeperation = g_stereoSeparation;
			oldStereoAsymmetry  = g_stereoAsymmetry;
			wereEyesSwapped		= g_isSwapEyesOn;

			// First off, we'll populate the combo box that selects the stereo rendering method.
			SendMessage(hWndCboMethod, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Anaglyph");
			SendMessage(hWndCboMethod, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "OpenGL Stereo");
			
			// Then we select our default rendering method.
			SendMessage(hWndCboMethod, CB_SETCURSEL, (WPARAM) g_curStereoMethod, (LPARAM) 0);

			// Turn Stereo On if it's not on already.
			if (wasStereoOn == false)
			{
				g_isStereoOn = false;
				SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_3DSTEREO, NULL);
			}
            
			// Next, set up the Seperation and Asymmetry Sliders:
			SendMessage(hWndSldSeperation, TBM_SETRANGE, false, (LPARAM) MAKELONG(0, 32000));
			SendMessage(hWndSldSeperation, TBM_SETPOS,   true,  (LPARAM) (g_stereoSeparation * 10000.0f));

			SendMessage(hWndSldAsymmetry, TBM_SETRANGE, false, (LPARAM) MAKELONG(0, 2000));
			SendMessage(hWndSldAsymmetry, TBM_SETPOS,   true,  (LPARAM) (g_stereoAsymmetry * 10000.0f));

			// Fill in the text of the Seperation and Asymmetry edit controls:
			float sepRaw  = ((float)(SendMessage(hWndSldSeperation, TBM_GETPOS, 0, 0)) / 10000.0f);
			float asymRaw = ((float)(SendMessage(hWndSldAsymmetry,  TBM_GETPOS, 0, 0)) / 10000.0f);

			int sepWhole = (int) sepRaw;
			int sepFract = (sepRaw - sepWhole) * 1000;

			int asymWhole = (int) asymRaw;
			int asymFract = (asymRaw - asymWhole) * 1000;

			char sepText[10];
			char asymText[10];

			if		(sepFract < 10)  {sprintf(sepText, "%d.00%d\0",  sepWhole,  sepFract);}
			else if (sepFract < 100) {sprintf(sepText, "%d.0%d\0",   sepWhole,  sepFract);}
			else					 {sprintf(sepText, "%d.%d\0",	 sepWhole,  sepFract);}

			if		(asymFract < 10) {sprintf(asymText, "%d.00%d\0", asymWhole, asymFract);}
			else if (asymFract < 100){sprintf(asymText, "%d.0%d\0",  asymWhole, asymFract);}
			else					 {sprintf(asymText, "%d.%d\0",	 asymWhole, asymFract);}

			SendMessage(hWndTxtSeperation, WM_SETTEXT, 0, (LPARAM) sepText);
			SendMessage(hWndTxtAsymmetry,  WM_SETTEXT, 0, (LPARAM) asymText);

			// And last but not least we set up the state of the swap eyes checkbox.
			if (g_isSwapEyesOn == true)
			{
				SendMessage(hWndChkSwapEyes, BM_SETCHECK, 1, 0);
			}

			return true;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDOK:
				{
					EndDialog(hWnd, 0);

					// Turn Stereo Off if it wasn't on when the panel was opened.
					if (wasStereoOn == false)
					{
						SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_3DSTEREO, NULL);
					}

					return true;
				}
			case IDCANCEL:
				{
					EndDialog(hWnd, 0);

					// Turn Stereo Off if it wasn't on when the panel was opened.
					if (wasStereoOn == false)
					{
						SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_3DSTEREO, NULL);
					}

					// Return the stereo method, seperation, asymmetry, and eye swap to their previous values.
					g_curStereoMethod  = oldStereoMethod;
					g_stereoSeparation = oldStereoSeperation;
					g_stereoAsymmetry  = oldStereoAsymmetry;
					g_isSwapEyesOn	   = wereEyesSwapped;

					return true;
				}
			case cboStereoMethods:
				{
					switch (HIWORD(wParam))
					{
					case CBN_SELCHANGE:
						{
							// Get the current combo box selection.
							g_curStereoMethod = SendMessage(hWndCboMethod, CB_GETCURSEL, NULL, NULL);

							g_isStereoOn = false;
							SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_3DSTEREO, NULL);
							
							break;
						}
					}

					return true;
				}
			case chkSwapEyes:
				{
					bool checked = SendMessage(hWndChkSwapEyes, BM_GETCHECK, 0, 0);

					if (checked == true)
					{
						g_isSwapEyesOn = true;
					}
					else
					{
						g_isSwapEyesOn = false;
					}
					return 0;
				}
			}
			break;
		}
	case WM_HSCROLL:
		{
			// Update the game's seperation and asymmetry states:
			float sepRaw  = ((float)(SendMessage(hWndSldSeperation, TBM_GETPOS, 0, 0)) / 10000.0f);
			float asymRaw = ((float)(SendMessage(hWndSldAsymmetry,  TBM_GETPOS, 0, 0)) / 10000.0f);

			g_stereoSeparation = sepRaw;
			g_stereoAsymmetry  = asymRaw;

			int sepWhole = (int) sepRaw;
			int sepFract = (sepRaw - sepWhole) * 1000;

			int asymWhole = (int) asymRaw;
			int asymFract = (asymRaw - asymWhole) * 1000;

			char sepText[10];
			char asymText[10];

			if		(sepFract < 10)  {sprintf(sepText, "%d.00%d\0",  sepWhole,  sepFract);}
			else if (sepFract < 100) {sprintf(sepText, "%d.0%d\0",   sepWhole,  sepFract);}
			else					 {sprintf(sepText, "%d.%d\0",	 sepWhole,  sepFract);}

			if		(asymFract < 10) {sprintf(asymText, "%d.00%d\0", asymWhole, asymFract);}
			else if (asymFract < 100){sprintf(asymText, "%d.0%d\0",  asymWhole, asymFract);}
			else					 {sprintf(asymText, "%d.%d\0",	 asymWhole, asymFract);}

			SendMessage(hWndTxtSeperation, WM_SETTEXT, 0, (LPARAM) sepText);
			SendMessage(hWndTxtAsymmetry,  WM_SETTEXT, 0, (LPARAM) asymText);
		}

	}
	return 0;
}

//======================================================================
// CreateStereoPrefsWindow() - Creates our stereo preferences panel.
//======================================================================
int CreateStereoPrefsWindow()
{
	CreateDialog(g_hInstance, MAKEINTRESOURCE(dlgStereoPrefs), g_hWndMain, DlgProc_StereoPrefs);

	return 0;
}