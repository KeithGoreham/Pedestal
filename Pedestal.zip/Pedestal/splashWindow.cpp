//////////////////////////////////////////////////////////////
// Implementation file for the Main UI Splash Window functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//======================================================================
// WndProc_Splash() - Our Windows event handler for the splash screen.
//======================================================================
long CALLBACK WndProc_Splash(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	// Now we run a switch on the message to decide what to do.
	switch (uMessage)
	{
	case WM_CREATE:				// Called when the window is created.
		{
			int deskWidth;
			int deskHeight;
            
			int splashPosX;
			int splashPosY;

			HWND hDesktopWnd = GetDesktopWindow();
			HDC  hDesktopDC  = GetDC(hDesktopWnd);

			// Retrieve the width and height of the display.
			deskWidth  = GetDeviceCaps(hDesktopDC, HORZRES);
			deskHeight = GetDeviceCaps(hDesktopDC, VERTRES);

			// Figure out the proper position for centering the window.
			splashPosX = (deskWidth  / 2) - (SPLASH_WINDOW_WIDTH  / 2);
			splashPosY = (deskHeight / 2) - (SPLASH_WINDOW_HEIGHT / 2);

			// And set the position.
			SetWindowPos(hWnd, HWND_TOP, splashPosX, splashPosY, NULL, NULL, SWP_NOSIZE); 
	
			return 0;
		}
	case WM_PAINT:				// Called whenever the window needs to be redrawn.
		{
			// Image handle for the splash graphic.
			HANDLE hImage;

			// Bitmap data structure for the splash graphic.
			BITMAP bitmap;

			// Load in the splash graphic from our app's resources.
			hImage = LoadImage(g_hInstance,
							   MAKEINTRESOURCE(IDB_BITMAP_SPLASHSCREEN), 
							   IMAGE_BITMAP, 
							   0, 
							   0, 
							   LR_DEFAULTCOLOR);

			// Grab a handle to the window's drawing context.
			HDC hDC = GetDC(hWnd);

			// Create the drawing context for the image and grab a handle to it.
			HDC hImageDC = CreateCompatibleDC(hDC);

			// Get the info from the bitmap graphic and store that info in the
			// bitmap structure we declared earlier.
			GetObject(hImage, sizeof(BITMAP), &bitmap);

			// Select/put the object into the drawing context.
			SelectObject(hImageDC, hImage);

			// Copy the bits.
			BitBlt(hDC, 0, 0, bitmap.bmWidth, bitmap.bmHeight, hImageDC, 0, 0, SRCCOPY);

			// Cleanup.
			DeleteDC(hImageDC);
			ReleaseDC(hWnd, hDC);
			DeleteObject(hImage);

			return 0;
		}
	default:					// Some other message.
		{
			// Let Windows handle the message.
			return (long) DefWindowProc(hWnd, uMessage, wParam, lParam);
		}
	}
}

//======================================================================
// CreateSplashWindow() - Function to create the Splash Screen window.
//======================================================================
int CreateSplashWindow(void)
{
	// Instantiate a Window Class.
	WNDCLASSEX winClassSplash;

	// Now we modify the winClass information for our Splash Window.
	winClassSplash.cbSize		  = sizeof(WNDCLASSEX);
	winClassSplash.style		  = CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_SAVEBITS;
	winClassSplash.cbClsExtra	  = 0;
	winClassSplash.cbWndExtra	  = 0;
	winClassSplash.lpfnWndProc	  = WndProc_Splash;
	winClassSplash.hInstance	  = g_hInstance;
	winClassSplash.hbrBackground  = NULL;
	winClassSplash.hIcon		  = NULL;
	winClassSplash.hIconSm		  = NULL;
	winClassSplash.hCursor		  = NULL;
	winClassSplash.lpszMenuName   = NULL;
	winClassSplash.lpszClassName  = SPLASH_NAME;

	// Now we register the window classes.
	RegisterClassEx(&winClassSplash);

	// And we create the window.
	g_hWndSplash = CreateWindowEx(NULL,											// Extended Windows Style
								  SPLASH_NAME,									// Class Name
								  APP_NAME,										// App Name
								  WS_POPUP,										// Window Style
								  100, 100,										// X and Y position.
								  SPLASH_WINDOW_WIDTH, SPLASH_WINDOW_HEIGHT,	// Width and Height.
								  g_hWndMain,									// Parent window handle.
								  NULL,											// Menu
								  NULL,											// Obsolete in 2000/XP.
								  NULL);										// For MDI apps.

	return 0;
}