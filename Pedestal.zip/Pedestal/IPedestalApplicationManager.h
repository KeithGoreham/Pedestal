//////////////////////////////////////////////////////////
// IPedestalApplicationManager.h - Interface file for the
// Pedestal Application Manager
//
// This class is used for dealing with all of the internal
// details of the Pedestal Application.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////




class IPedestalApplicationManager
{
	HINSTANCE hInstance;			// Pointer to the current application instance.
	bool	  resetView;			// Stores whether the rendering view needs to be reset.


	class IPedestalApplicationManagerHWND
	{
		HWND main;					// Handle to the main application window.
		HWND render;				// Handle to the application's render window.
		HWND splash;				// Handle to the application's splash screen.
		HWND stereoPrefs;			// Handle to the stereo preferences panel.
		HWND fullScreenPrefs;		// Handle to the full screen preferences panel.
		HWND renderingPrefs;		// Handle to the rendering preferences panel.
	};

	class IPedestalApplicationManagerDisplay
	{
		UINT curStereoMethod;		// Stores which stereo method we're currently using.

		ePOINT2U desktopRes;		// Stores the resolution of the Windows desktop.

		UINT	 bppColor;			// Stores how many bits to use for the rendering color buffer.
		UINT	 bppDepth;			// Stores how many bits to use for the rendering depth buffer.

	};

	class IPedestalApplicationManagerRenderer
	{

	};

	class IPedestalApplicationManagerPlayer
	{

	};

};