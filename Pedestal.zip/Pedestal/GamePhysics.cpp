//////////////////////////////////////////////////////////////
// Implementation file for the GamePhysics function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInStaticMesh.h"

extern eSTATIC_MESH* g_playerMesh;


// Function definition.
int GamePhysics()
{    
	//UINT arraySize = g_playerMesh->numVerts;

	//UINT* SortedXVerts = new UINT[arraySize];
	//UINT* SortedYVerts = new UINT[arraySize];
	//UINT* SortedZVerts = new UINT[arraySize];

	//for (UINT i = 0; i < g_playerMesh->numVerts; i++)
	//{
	//	//
	//}


    return 0;
}