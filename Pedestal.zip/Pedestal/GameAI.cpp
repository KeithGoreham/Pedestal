//////////////////////////////////////////////////////////////
// Implementation file for the GameAI function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInStaticMesh.h"

// Preprocessor directives:
#pragma once

// Function definition.
int GameAI()
{    
	
    return 0;
}