//////////////////////////////////////////////////////////////
// Implementation file for the GameInit function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInStaticMesh.h"			// Custom 3D mesh class.
#include "eInDisplay.h"				// Custom 3D renderer class.
#include "uiFunctions.h"
#include "eInStaticMesh.h"
#include "e1nInputDI8.h"


// External global declarations:
extern HWND				g_hWndMain;
extern HWND				g_hWndSplash;
extern HWND				g_hWndStatusBar;
extern HWND				g_hWndRender;
extern HDC				g_hDC;
extern eDISPLAY_OBJECT* g_renderer;
extern eINPUTDEVICE*    g_input;
extern HINSTANCE		g_hInstance;
extern UINT				g_appWinWidth;
extern UINT				g_appWinHeight;
extern UINT				g_appWinBPPColor;
extern UINT				g_appWinBPPDepth;
extern UINT				g_curStereoMethod;
extern float			g_fullScreenCustomAspect;

extern eSTATIC_MESH* g_playerMesh;
extern float*	     g_pureHueVals;
extern Ce1nPlayer	 player;

extern char g_defaultModelFile[256];

// Function definition.
int GameInit(HWND hWndTest, HWND hWndAppMain)
{
	RECT renderWindowRect;

	GetClientRect(g_hWndRender, &renderWindowRect);

	// Initialize the eIn renderer.
	g_renderer = new eDISPLAY_OBJECT(g_hWndRender,					// Handle to the main window.
									g_hWndSplash,					// Handle to the splash screen (for testing).
									renderWindowRect.right,			// Window width for windowed application.
									renderWindowRect.bottom,		// Window height for windowed application.
									g_desktopSize.x,				// Width in pixels of Desktop (For calculating Full-Screen Aspect)
									g_desktopSize.y,				// Height in pixels of Desktop (For calculating Full-Screen Aspect)
									g_appWinBPPColor,				// Bits per pixel to use for color.
									g_appWinBPPDepth);				// Bits per pixel to use for the depth buffer.	
								
	g_renderer->SetRenderMode(EIN_RENDER_COMBINED);
	
	// Initialize the e1nInput object.
	g_input = new Ce1nInputDI8(g_hInstance, g_hWndMain, false);

	// Read a mesh from disk.
	g_playerMesh = new eSTATIC_MESH;
	bool fileGood = g_playerMesh->loadESSM(g_defaultModelFile);

	// If the file load didn't work, delete the mesh object to prevent rendering.
	if (fileGood == false){delete g_playerMesh; g_playerMesh = 0;}

	if (g_playerMesh != NULL)
	{
		g_renderer->BindObjectTextures(*g_playerMesh);
		g_renderer->RenderMesh(*g_playerMesh);
	}

	return 0;
}