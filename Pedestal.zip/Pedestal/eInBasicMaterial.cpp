//////////////////////////////////////////////////////////
// eInBasicMaterial.h - Implementation file for the 
// sInBasicMaterial class. Part of the eIngine game
// engine.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

#include "eInBasicMaterial.h"

// Default constructor.
CeInBasicMaterial::CeInBasicMaterial()
{
	ambient   = eRGBf(0.0f, 0.0f, 0.0f);
	diffuse   = eRGBf(0.0f, 0.0f, 0.0f);
	specular  = eRGBf(0.0f, 0.0f, 0.0f);
	shininess = (char) 64;
	ambient   = eRGBf(0.0f, 0.0f, 0.0f);

	numMatFaces  = 0;	
	firstMatFace = 0;
	lastMatFace  = 0;		
}

// Initialization constructor.
CeInBasicMaterial::CeInBasicMaterial(const eRGBf &someAmbient,
									 const eRGBf &someDiffuse,
									 const eRGBf &someSpecular,
									 const char &someShininess,
									 const eRGBf &someEmissive) : ambient (someAmbient),
																  diffuse (someDiffuse),
																  specular(someSpecular),
																  shininess(someShininess),
																  emissive(someEmissive) 
{
	numMatFaces  = 0;	
	firstMatFace = 0;
	lastMatFace  = 0;
}

