//////////////////////////////////////////////////////////////
// Implementation file for the GameLoop function.
//
// There should be a minimum of code defined in this function.
// It's purpose is to call the other main game functions where
// the real work is done.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInStaticMesh.h"
#include "uiFunctions.h"

extern eSTATIC_MESH* g_playerMesh;
extern HWND			 g_hWndStatusBar;
extern bool			 g_isStereoOn;
extern UINT			 g_curStereoMethod;

//Function definition.
int GameLoop()
{
	// Make sure a model was successfully loaded.
	if (g_playerMesh != NULL)
	{
		static float totalFrameRate = 1.0f;
		static int	 numFrames;
		float		 frameRate;

		// Grab the System Time.
		DWORD startTime = GetTickCount();

		// Call main game functions:
		GameInput();
		GameAI();
		GamePhysics();

		// Stereo or not?
		if (g_isStereoOn == true) 
		{
			GameDisplayStereo();	
		}
		else
		{
			GameDisplay();
		}

		
		GameSound();

		if (numFrames > 100) 
		{
			char buffer[50];

			// Figure out the framerate.
			frameRate = 1000.0f / (float) (GetTickCount() - startTime);

			totalFrameRate += frameRate;
			frameRate = totalFrameRate / 100.0f;
			
			int wholeNum = (int) frameRate;
			int fractNum = (int) ((frameRate - (float) wholeNum) * 10);
			
			// This if statement is a bug fix. It keeps garbage values from being updated to the status bar.
			if (wholeNum > 0)
			{
				sprintf(buffer, " %d.%d FPS", wholeNum, fractNum);

				SendMessage(g_hWndStatusBar, SB_SETTEXT, 2, (WPARAM) buffer);
			}

			numFrames = 0;
			totalFrameRate = 0.0f;
		}
		else
		{
			// Figure out the framerate.
			frameRate = 1000.0f / (float) (GetTickCount() - startTime);
			totalFrameRate += frameRate;

			numFrames += 1;
		} 
	}

	return 0;
}
