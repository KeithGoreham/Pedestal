//////////////////////////////////////////////////////////////
// Interface file for all Main UI Functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Precompiled header files.
#include "stdafx.h"

// Custom classes and libraries:
#include "Gamefunctions.h"			// Main game function definitions.
#include "eInStaticMesh.h"			// Custom mesh class.
#include "eInDisplay.h"				// Custom display class.
#include "eInBasicMaterial.h"		// Custom material class.
#include "e1nInputDI8.h"
#include "resource.h"				// Application menu definition.


#define APP_STARTUP_FILE			"meshes\\startup.ESSM"
#define APP_PREFERENCES_FILE		"preferences.xml"

// Preprocessor Constants:
#define APP_NAME					"ArtLogic Pedestal 0.9"			// Our app's name (for the windows title bar).
#define APP_WINDOW_WIDTH			1024								// Width of application window.
#define APP_WINDOW_HEIGHT			768									// Height of application window.

#define APP_BPP_COLOR				32									// Color depth of our game window.
#define APP_BPP_DEPTH				16									// Number of bits to use for the OGL depth buffer.
#define APP_BPP_ALPHA				8									// Number of bits to use for the OGL destination alpha.
#define APP_BPP_ACCUM				24									// Number of bits to use for the OGL accumulation buffer.
#define APP_FULLSCREEN				false								// Whether or not we'll be rendering full-screen.

#define RENDER_NAME					"Pedestal Render Window"			// The name of our render window.

#define SPLASH_NAME					"Pedestal Splash Screen"			// The name of our splash screen.
#define SPLASH_WINDOW_WIDTH			500									// Width of the splash screen.
#define SPLASH_WINDOW_HEIGHT		309									// Height of the splash screen.

#define WIPE_WINDOW_NAME			"Wipe Window"						// The name of the window we'll use for hiding the screen during res changes.

#define STEREO_PREFS_NAME			"Stereo Rendering Preferences"
#define STEREO_PREFS_WINDOW_WIDTH	350
#define STEREO_PREFS_WINDOW_HEIGHT	216

#define STEREOMETHOD_DEFAULT		0
#define STEREOMETHOD_ANAGLYPH		0
#define STEREOMETHOD_OPENGL			1

#define STEREO_DEFAULTSEPERATION	0.504f
#define STEREO_DEFAULTASYMMETRY		0.025f

#define PEDESTAL_MONITORDEFAULT		0
#define PEDESTAL_MONITOR1			1
#define PEDESTAL_MONITOR2			2
#define PEDESTAL_MONITOR3			3
#define PEDESTAL_MONITOR4			4
#define PEDESTAL_MONITOR5			5
#define PEDESTAL_MONITOR6			6
#define PEDESTAL_MONITOR7			7
#define PEDESTAL_MONITOR8			8
#define PEDESTAL_MONITOR9			9

// Monitor Aspect Ratios:
#define PEDESTAL_ASPECT_4by3		0
#define PEDESTAL_ASPECT_16by9		1
#define PEDESTAL_ASPECT_16by10		2

// Monitor Resolution Selection Enumerations for 4:3 displays:
#define PEDESTAL_RESSEL_640x480		0
#define PEDESTAL_RESSEL_720x576		1
#define PEDESTAL_RESSEL_800x600		2
#define PEDESTAL_RESSEL_1024x768	3
#define PEDESTAL_RESSEL_1152x864	4
#define PEDESTAL_RESSEL_1280x960	5
#define PEDESTAL_RESSEL_1280x1024	6

// Monitor Resolution Selection Enumerations for 16:9 displays:
#define PEDESTAL_RESSEL_848x480		10
#define PEDESTAL_RESSEL_1088x612	11
#define PEDESTAL_RESSEL_1280x720	12
#define PEDESTAL_RESSEL_1360x768	13
#define PEDESTAL_RESSEL_1600x900	14

// Monitor Resolution Selection Enumerations for 16:10 displays:
#define PEDESTAL_RESSEL_720x480		20
#define PEDESTAL_RESSEL_960x600		21
#define PEDESTAL_RESSEL_1280x768	22
#define PEDESTAL_RESSEL_1280x800	23
#define PEDESTAL_RESSEL_1600x1024	24
#define PEDESTAL_RESSEL_1680x1050	25
#define PEDESTAL_RESSEL_1920x1200	26

// External Variables:
extern eDISPLAY_OBJECT* g_renderer;				// Pointer to our display class that draws stuff on the screen.
extern eINPUTDEVICE*    g_input;				// Pointer to our input class that gets keyboard, mouse, and joystick input.
extern eSTATIC_MESH*	g_playerMesh;			// Pointer to the player's mesh object.
extern UINT				g_appWinWidth;
extern UINT				g_appWinHeight;
extern UINT				g_appWinBPPColor;
extern UINT				g_appWinBPPDepth;
extern UINT				g_appWinBPPAlpha;
extern UINT				g_appWinBPPAccum;
extern float			g_fullScreenCustomAspect;
extern float			g_stereoSeparation;
extern float			g_stereoAsymmetry;
extern bool				g_isSwapEyesOn;

// Global Variables:


extern HWND			g_hWndMain;					// Global handle to the main window.
extern HWND			g_hWndRender;				// Global handle to the main rendering window.
extern HWND			g_hWndSplash;				// Global handle to the startup splash window.
extern HWND			g_hWndStereoPrefs;			// Global handle to the stereo preferences panel.
extern HWND			g_hWndStatusBar;
extern HWND			g_hWndWipeWindow;		// Global handle to the full screen black window.

extern UINT			g_curStereoMethod;

extern HINSTANCE	g_hInstance;				// Global pointer to the current instance of our application.

extern ePOINT2U		g_desktopSize;				// Variable to hold the size of the windows desktop in pixels.
extern bool			g_isAppMaximized;

extern UINT			g_appWinBPPColor;
extern UINT			g_appWinBPPDepth;

extern Ce1nPlayer	player;

extern bool			g_resetView;
extern bool			g_isAppFullScreen;
extern bool			g_graphicsInitComplete;		// Stores whether we're done interogating the video card.
extern bool			g_isStereoOn;
extern bool			g_isAntiAliasingOn;
extern bool			g_isSwapEyesOn;
extern float		g_stereoAsymmetry;
extern float		g_stereoSeparation;
extern ePOINT2		g_fullScreenResolutions[4];

extern WNDCLASSEX winClass;
extern WNDCLASSEX winClassFS;

// Application Initialization Functions:
int ReadPreferencesFile(void);
int WritePreferencesFile(void);

// Render Window Function Declarations:
long CALLBACK WndProc_Render(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int  CreateRenderWindow(void);
int  CreateFullScreenRenderWindow(UINT &whichMonitor);

// Splash Window Function Declarations:
long CALLBACK WndProc_Splash(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int	 CreateSplashWindow(void);

// Main Window Function Declarations:
long CALLBACK WndProc_Main(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int  CreateMainWindow();

// Full Screen Black Window Declarations:
long CALLBACK WndProc_WipeWindow(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int	 CreateWipeWindow();

// Status Bar Function Declarations:
int  CreateStatusBarWindow(void);

// Stereo Preferences Panel Function Declarations:
long CALLBACK WndProc_StereoPrefs(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int	 CreateStereoPrefsWindow(void);

// Full Screen Preferences Panel Function Declarations:
long CALLBACK WndProc_FullScreenPrefs(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int	 CreateFullScreenPrefsWindow(void);

// Rendering Preferences Panel Function Declarations:
long CALLBACK WndProc_RenderingPrefs(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
int	 CreateRenderingPrefsWindow(void);
