//////////////////////////////////////////////////////////////
// Big Bad Rocks: A 3D Accelerated Asteroids Clone
//
// BigBadRocks.cpp - Our game's entry point. The guts of the
// game are in GameLoop.cpp. This file is here to handle inits
// and the overhead of dealing with Windows.
//
// �2006 by Keith M. Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Precompiled header files.
#include "stdafx.h"

// Custom classes and libraries:
#include "MiscFunctions.h"			// Various minor application functions.
#include "Gamefunctions.h"			// Main game function definitions.
#include "eInStaticMesh.h"			// Custom mesh class.
#include "eInDisplay.h"				// Custom display class.
#include "eInBasicMaterial.h"		// Custom material class.
#include "e1nInputDI8.h"
#include "resource.h"				// Application menu definition.
#include "uiFunctions.h"			// Main UI function definitions.
#include "pedestalSettings.h"		// Structs to better hold our app's settings.


// Global Variables: Handles
HWND		g_hWndMain;				// Global handle to the main window.
HWND		g_hWndSplash;			// Global handle to the splash screen window.
HWND		g_hWndStatusBar;		// Global handle to the status bar.
HWND		g_hWndRender;			// Global handle to the main rendering window.
HWND		g_hWndStereoPrefs;		// Global handle to the stereo preferences panel.
HWND		g_hWndWipeWindow;	    // Global handle to the full screen black window.

HDC			g_hDC;					// Global device context.
HGLRC		g_hRC;					// Global handle to an OpenGL rendering context.
HINSTANCE	g_hInstance;			// Global pointer to the current instance of our application.
MSG			mainMsg;				// Handle for messages sent by Windows to the main window.
MSG			splashMsg;				// Handle for messages sent by Windows to the splash screen window.
ePOINT2U	g_desktopSize;			// Variable to hold the size of the windows desktop in pixels.


UINT g_appWinWidth	  = APP_WINDOW_WIDTH;
UINT g_appWinHeight   = APP_WINDOW_HEIGHT;
UINT g_appWinBPPColor = APP_BPP_COLOR;
UINT g_appWinBPPDepth = APP_BPP_DEPTH;
UINT g_appWinBPPAlpha = APP_BPP_ALPHA;
UINT g_appWinBPPAccum = APP_BPP_ACCUM;

UINT		g_frameCount		= 0;
bool		g_resetView			= false;
bool		g_isAppMaximized	= false;		// Variable to hold whether our application is maximized or not.
bool		g_isAppFullScreen	= false;
bool		g_isStereoOn		= false;
UINT		g_curStereoMethod   = STEREOMETHOD_DEFAULT;
bool		g_isAntiAliasingOn	= false;
bool		g_isSwapEyesOn		= false;

float		g_stereoAsymmetry	= STEREO_DEFAULTASYMMETRY;
float		g_stereoSeparation	= STEREO_DEFAULTSEPERATION;

ePOINT2     g_windowedPosition		   = ePOINT2(0, 0);
float		g_fullScreenCustomAspect   = 0.0f;
ePOINT2		g_fullScreenResolutions[4] = {ePOINT2(1024, 768),		// Monitor 1 Default 
										  ePOINT2(1024, 768),		// Monitor 2 Default
										  ePOINT2(1024, 768),		// Monitor 3 Default
										  ePOINT2(1024, 768)};		// Monitor 4 Default

Ce1nPlayer	player;								// Global variable for storing viewing transforms. Will be replaced later with something more robust.

bool		g_graphicsInitComplete = false;				// Stores whether we're done interogating the video card.
bool		g_suspendResize		   = false;


char g_defaultModelFile[256] = APP_STARTUP_FILE;

// Global pointers to game data.
eDISPLAY_OBJECT* g_renderer	   = NULL;				// Pointer to our display class that draws stuff on the screen.
eINPUTDEVICE*    g_input       = NULL;				// Pointer to our input class that gets keyboard, mouse, and joystick input.
eSTATIC_MESH*	 g_playerMesh  = NULL;				// Pointer to the player's mesh object.

WNDCLASSEX winClass;
WNDCLASSEX winClassFS;


//============================================================
// WinMain() - Our entry point.
//============================================================
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR pstrCmdLine, int iCmdShow)
{
	g_hInstance = hInstance;	// Assign the address of our application's instance to our global pointer.

	MSG  winMsgMain;			// The message that windows is sending to the main window.
	MSG  winMsgSplash;			// The message that windows is sending to the splash window.

	CreateMainWindow();			// Create the main window.

	// And finally we display the main window.
	if (g_isAppMaximized == true){ShowWindow(g_hWndMain, SW_MAXIMIZE);}
	else						 {ShowWindow(g_hWndMain, iCmdShow);}

	// And draw the contents for the first time.
	UpdateWindow(g_hWndMain);

	// Create the various UI windows:
	CreateSplashWindow();
	CreateStatusBarWindow();
	CreateRenderWindow();
	
	// Show the render screen.
	ShowWindow(g_hWndRender, SW_SHOW);

	// Show the splash screen and force it to paint.
	ShowWindow(g_hWndSplash, SW_SHOW);
	UpdateWindow(g_hWndSplash);

	// Don't init again.
	g_graphicsInitComplete = true;

	// Start tracking our time.
	DWORD startTime = GetTickCount();

	// Now we'll check the command line for a possible file name to load instead of the usual default.
	if (strlen(pstrCmdLine) != 0)
	{
		// When our files are double-clicked, Windows will send a filename string to the app. But this
		// string will include quotes. We need to remove those quotes before we pass on the file string.
		
		// All this is much easier with a true string.
		string tmpName = pstrCmdLine;

		if(tmpName.find("\"", 0) == 0)				// If we detect a leading quote...
		{
			tmpName.erase(0,1);						// Removed the leading quote.
			tmpName.erase(tmpName.length() - 1, 1);		// Remove the trailing quote.

			strcpy(g_defaultModelFile, tmpName.c_str());	// Copy back to the C-Style string.
		}
		else
		{
			strcpy(g_defaultModelFile, pstrCmdLine);
		}
	}

	// Graphics System Initialization
	GameInit(g_hWndSplash, g_hWndMain);

	// Update the screen
	if (g_playerMesh != NULL){GameDisplay();}

	// Make sure the intialization has taken at least 2 seconds.
	while((GetTickCount() - startTime) < 2000);

	// Hide the splash window, we're done with it.
	ShowWindow(g_hWndSplash, SW_HIDE);
	DestroyWindow(g_hWndSplash);

	// Grab a handle to the main window's menu bar.
	HMENU hMenu = GetMenu(g_hWndMain);

	// Place a check mark beside the default rendering mode.
	CheckMenuItem(hMenu, ID_RENDER_COMBINED, MF_CHECKED);

	if (g_playerMesh == NULL)
	{
		MessageBox(g_hWndMain, "Startup Mesh File Not Found", "Pedestal File Error", MB_OK);
	}

	//Then we start the message loop.
	while(TRUE)
	{
		if (PeekMessage(&winMsgMain, NULL, 0, 0, PM_REMOVE))
		{
			if (winMsgMain.message == WM_QUIT)
			{
				// Exit the loop.
				break;
			}
			else
			{
				// Convert virtual key messages into character messages.
				TranslateMessage(&winMsgMain);

				// Send the message to the event handler.
				DispatchMessage(&winMsgMain);
			}
		}
		else
		{
			// Run the game loop.
			GameLoop();
		}
	}

	// Perform any game shutdown tasks.
	GameShutdown();

	// Return control to Windows with the exit code.
	return (int) winMsgMain.wParam;
}