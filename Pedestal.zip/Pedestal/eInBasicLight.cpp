//////////////////////////////////////////////////////////
// eInBasicLight.h - Implementation file for the
// CeInBasicLight class.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

#include ".\einbasiclight.h"

CeInBasicLight::CeInBasicLight(void)
{
}

CeInBasicLight::~CeInBasicLight(void)
{
}
