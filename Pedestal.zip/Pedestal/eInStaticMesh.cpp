#include "eInStaticMesh.h"

/*
CeInMesh::CeInStaticMesh(void)
{
}

CeInMesh::~CeInStaticMesh(void)
{
}
*/