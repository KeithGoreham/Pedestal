//////////////////////////////////////////////////////////////
// Implementation file for the Rendering Preferences window.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

INT_PTR CALLBACK DlgProc_RenderingPrefs(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HWND hWndCboAntiAliasing;
	static HWND hWndCboTextureFiltering;
	static HWND hWndCboWaitForVerticalSync;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		{
			hWndCboAntiAliasing		   = GetDlgItem(hWnd, cboAntiAliasing);
			hWndCboTextureFiltering	   = GetDlgItem(hWnd, cboTextureFiltering);
			hWndCboWaitForVerticalSync = GetDlgItem(hWnd, cboWaitForVerticalSync);
			
			// Set up the Anti-Aliasing Combobox:
			SendMessage(hWndCboAntiAliasing, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "None");
			SendMessage(hWndCboAntiAliasing, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Low    (2x)");
			SendMessage(hWndCboAntiAliasing, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Medium (4x)");
			SendMessage(hWndCboAntiAliasing, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "High   (8x)");
			SendMessage(hWndCboAntiAliasing, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "High  (16x)");

			SendMessage(hWndCboAntiAliasing, CB_SETCURSEL, (WPARAM) 2, (LPARAM) 0);

			// Set up the Texture Filtering Combobox:
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "None");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Bilinear");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Trilinear");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Anisotropic  2x");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Anisotropic  4x");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Anisotropic  8x");
			SendMessage(hWndCboTextureFiltering, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Anisotropic 16x");

			SendMessage(hWndCboTextureFiltering, CB_SETCURSEL, (WPARAM) 2, (LPARAM) 0);

			// Set up the Wait for Vertical Sync Combobox:
			SendMessage(hWndCboWaitForVerticalSync, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "On");
			SendMessage(hWndCboWaitForVerticalSync, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "Off");

			SendMessage(hWndCboWaitForVerticalSync, CB_SETCURSEL, (WPARAM) 1, (LPARAM) 0);

			return true;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDOK:
				{
					EndDialog(hWnd, 0);

					return true;
				}
			case IDCANCEL:
				{
					EndDialog(hWnd, 0);

					return true;
				}
			

			}
			break;
		}
	}
	return 0;
}

//======================================================================
// CreateFullScreenPrefsWindow() - Creates our Full-Screen preferences
// panel.
//======================================================================
int CreateRenderingPrefsWindow()
{
	CreateDialog(g_hInstance, MAKEINTRESOURCE(dlgRenderingPrefs), g_hWndMain, DlgProc_RenderingPrefs);

	return 0;
}