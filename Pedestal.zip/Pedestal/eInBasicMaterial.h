//////////////////////////////////////////////////////////
// eInBasicMaterial.h - Interface file for the 
// sInBasicMaterial class. Part of the eIngine game
// engine.
//
// This class is used to store the properties for a basic 
// (non-shader) 3D graphics material. 
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Preprocessor Directives:
#pragma once

// Includes:
#include "stdAfx.h"

typedef class CeInBasicMaterial
{
public:
	eRGBf ambient;			// Ambient color.
	eRGBf diffuse;			// Diffuse color.
	eRGBf specular;			// Specular color.
	char  shininess;		// Specular exponent.
	eRGBf emissive;			// Emissive (Self-Illuminated) color;
	
	UINT numMatFaces;		// Stores the number of faces which use this material.
	UINT firstMatFace;		// Stores the first mesh face index used by this material.
	UINT lastMatFace;		// Stores the last mesh face index used by this material.

	UINT     diffuseMapType;		// The number of channels in the diffusemap.
	ePOINT2U diffuseMapSize;		// The dimensions of the diffusemap.
	UCHAR*   diffuseMapData;		// Pointer to an array of texture data.
	
	// Default constructor.
	CeInBasicMaterial();

	// Initialization constructor.
	CeInBasicMaterial(const eRGBf &someAmbient,
					  const eRGBf &someDiffuse,
					  const eRGBf &somespecular,
					  const char &someShininess,
					  const eRGBf &someEmissive);

	// Destructor.
	~CeInBasicMaterial(void)
	{
		if (diffuseMapData != NULL){delete diffuseMapData;}
	}

}eBASIC_MAT;