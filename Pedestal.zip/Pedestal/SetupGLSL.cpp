//////////////////////////////////////////////////////////
// SetupGLSL.cpp - Implementation file. Part of
// the eIngine game engine.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// includes:
#include "eInDisplay.h"
#include "stdafx.h"

// GLSL Function Pointers:
PFNGLCREATEPROGRAMOBJECTARBPROC			glCreateProgramObjectARB		= NULL;
PFNGLCREATESHADEROBJECTARBPROC			glCreateShaderObjectARB			= NULL;
PFNGLLINKPROGRAMARBPROC					glLinkProgramARB				= NULL;
PFNGLCOMPILESHADERARBPROC				glCompileShaderARB				= NULL;
PFNGLGETINFOLOGARBPROC					glGetInfoLogARB					= NULL;
PFNGLDELETEOBJECTARBPROC				glDeleteObjectARB				= NULL;
PFNGLUSEPROGRAMOBJECTARBPROC			glUseProgramObjectARB			= NULL;
PFNGLSHADERSOURCEARBPROC				glShaderSourceARB				= NULL;
PFNGLATTACHOBJECTARBPROC				glAttachObjectARB				= NULL;
PFNGLGETOBJECTPARAMETERIVARBPROC		glGetObjectParameterivARB		= NULL;
PFNGLGETUNIFORMLOCATIONARBPROC			glGetUniformLocationARB			= NULL;
PFNGLDISABLEVERTEXATTRIBARRAYARBPROC	glDisableVertexAttribArrayARB	= NULL;
PFNGLENABLEVERTEXATTRIBARRAYARBPROC		glEnableVertexAttribArrayARB	= NULL;
PFNGLUNIFORM4FARBPROC					glUniform4fARB					= NULL;
PFNGLUNIFORM2FARBPROC					glUniform2fARB					= NULL;
PFNGLUNIFORM1FARBPROC					glUniform1fARB					= NULL;
PFNGLUNIFORM1IARBPROC					glUniform1iARB					= NULL;

// GLSL Objects:
GLhandleARB glslContext;
GLhandleARB glslVertexShader;
GLhandleARB glslPixelShader;

//------------------------------------------------------------
// This function is used to setup the GLSL functions.
//------------------------------------------------------------
bool CeInDisplay::SetupGLSL()
{
	// Grab the list of supported GL extensions:
	char* glExtensions = (char*)glGetString(GL_EXTENSIONS);

	// Check for the GLSL extensions:
	if(strstr(glExtensions, "GL_ARB_shading_language_100") == NULL){return false;}
	if(strstr(glExtensions, "GL_ARB_shader_objects")       == NULL){return false;}

	// If the previous test didn't knock us out of the function, retrieve the GLSL functions.
	glCreateProgramObjectARB	= (PFNGLCREATEPROGRAMOBJECTARBPROC)	wglGetProcAddress("glCreateProgramObjectARB");
	glCreateShaderObjectARB		= (PFNGLCREATESHADEROBJECTARBPROC)	wglGetProcAddress("glCreateShaderObjectARB");
	glCompileShaderARB			= (PFNGLCOMPILESHADERARBPROC)		wglGetProcAddress("glCompileShaderARB");
	glLinkProgramARB			= (PFNGLLINKPROGRAMARBPROC)			wglGetProcAddress("glLinkProgramARB");
	glGetInfoLogARB				= (PFNGLGETINFOLOGARBPROC)			wglGetProcAddress("glGetInfoLogARB");
	glDeleteObjectARB			= (PFNGLDELETEOBJECTARBPROC)		wglGetProcAddress("glDeleteObjectARB");
	glUseProgramObjectARB		= (PFNGLUSEPROGRAMOBJECTARBPROC)	wglGetProcAddress("glUseProgramObjectARB");
	glShaderSourceARB			= (PFNGLSHADERSOURCEARBPROC)		wglGetProcAddress("glShaderSourceARB");
	glAttachObjectARB			= (PFNGLATTACHOBJECTARBPROC)		wglGetProcAddress("glAttachObjectARB");
	glGetObjectParameterivARB	= (PFNGLGETOBJECTPARAMETERIVARBPROC)wglGetProcAddress("glGetObjectParameterivARB");
	glGetUniformLocationARB		= (PFNGLGETUNIFORMLOCATIONARBPROC)	wglGetProcAddress("glGetUniformLocationARB");
	glUniform4fARB				= (PFNGLUNIFORM4FARBPROC)			wglGetProcAddress("glUniform4fARB");
	glUniform2fARB				= (PFNGLUNIFORM2FARBPROC)			wglGetProcAddress("glUniform2fARB");
	glUniform1fARB				= (PFNGLUNIFORM1FARBPROC)			wglGetProcAddress("glUniform1fARB");
	glUniform1iARB				= (PFNGLUNIFORM1IARBPROC)			wglGetProcAddress("glUniform1iARB");

	// Check to make sure all those function pointers are working.
	if (!glCreateProgramObjectARB  ||
		!glCreateShaderObjectARB   ||
		!glCompileShaderARB	     ||
		!glLinkProgramARB			 ||
		!glGetInfoLogARB			 ||
		!glDeleteObjectARB		 ||
		!glUseProgramObjectARB	 ||
		!glShaderSourceARB		 ||
		!glAttachObjectARB		 ||
		!glGetObjectParameterivARB ||
		!glGetUniformLocationARB	 ||
		!glUniform4fARB			 ||
		!glUniform2fARB			 ||
		!glUniform1fARB			 ||
		!glUniform1iARB) 
	{
		return false;
	}

	// Create GLSL program object.
	glslContext = glCreateProgramObjectARB();

	// Define some simple shaders for testing.
	char* simpleVertexShader = new char[128];
	char* simplePixelShader  = new char[128];

	simpleVertexShader = "void main(void){gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;}\0";
	simplePixelShader  = "void main(void){gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);}\0";

	// Load Vertex Shader.
	glslVertexShader = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);

	glShaderSourceARB(glslVertexShader, 1, (const char**)&simpleVertexShader, NULL);
	glCompileShaderARB(glslVertexShader);

	int result;
	glGetObjectParameterivARB(glslVertexShader, GL_OBJECT_COMPILE_STATUS_ARB, &result);
	if (!result){OutputDebugString("Error compiling vertex shader\n");}
	else		{OutputDebugString("Vertex Shader Compiled\n");}

	glAttachObjectARB(glslContext, glslVertexShader);
	
	// Load Pixel Shader.
	glslPixelShader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

	glShaderSourceARB(glslPixelShader, 1, (const char**)&simplePixelShader, NULL);
	glCompileShaderARB(glslPixelShader);

	glGetObjectParameterivARB(glslPixelShader, GL_OBJECT_COMPILE_STATUS_ARB, &result);
	if (!result){OutputDebugString("Error compiling pixel shader\n");}
	else		{OutputDebugString("Pixel Shader Compiled\n");}

	glAttachObjectARB(glslContext, glslPixelShader);

	// Link shaders into context.
	glLinkProgramARB(glslContext);
	
	glGetObjectParameterivARB(glslContext, GL_OBJECT_LINK_STATUS_ARB, &result);
	if (!result)
	{
		OutputDebugString("Error linking shaders\n");

	}
	else		{OutputDebugString("Shaders linked\n");}

	return true;
}