#include ".\miscgamefunctions.h"

MiscGameFunctions::MiscGameFunctions(void)
{
}

MiscGameFunctions::~MiscGameFunctions(void)
{
}
