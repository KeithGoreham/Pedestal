//////////////////////////////////////////////////////////////
// Misc Functions - Implementation File
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Includes:
#include "MiscFunctions.h"

// Precompiled header files.
#include "stdafx.h"	

// Other preprocessor directives:
#pragma once

//============================================================
// This function pauses the program execution for a set period
// of time.
//============================================================
inline void Pause(int &milliSecs)
{
	// Get the current time.
	int time = GetTickCount();

	// Wait until the specified time has elapsed.
	while ((UINT)GetTickCount() - (UINT) time < (UINT) milliSecs){}
}

//============================================================
// This function outputs text to Visual Studio's debug window.
//============================================================
inline void DebugOut(char* someString)
{
	OutputDebugString(someString);
	OutputDebugString("\n");
}

//========================================================
// This function finds the absolute value of a floating
// point number. Since abs only returns integers.
//========================================================
inline float absF(float someFloat)
{
	return (float) sqrt(pow(someFloat, (float) 2.0));
}

//========================================================
// This function produces a random integer within a  
// specified range.
//========================================================
inline int randRanged(int loBound, int hiBound)
{
	int answer;

	answer = rand();

	answer = answer % (hiBound - loBound);
	answer = answer + loBound;

	return answer;
}


//========================================================
// This function populates an array with the precomputed
// values of a range of pure hues. We'll use this as a
// lookup table for our various HSV <--> RGB functions.
//========================================================
float* MakePureHueValueTable()
{
	float* valArray;				// A pointer to an array of hue values.
	valArray = new float[361];		// Making the array.

	int	  hueRange;					// Stores which of 7 possible hue ranges we're in. Each requires different processing.
	float hueOffset;				// Stores our position within a particular range.
	float rVal, gVal, bVal;			// Variables for the values of the red, green, and blue components of a hue.
	float pureHueVal;				// Stores the value of a particular hue at full saturation.

	for (int hue = 0; hue < 361; hue++)
	{
		// Figuring out our current hue range. As well as our offset within that range.
		hueOffset = hue / 60.0f;
		hueRange = (int) (floor(hueOffset));
		hueOffset = hueOffset - hueRange;

		// Based upon the hue range, we'll use the offset to determine the exact values of our
		// red, green, and blue components.
		switch (hueRange)
		{
		case 0:		// Red to Yellow:
			{
				rVal = 1.0f;
				gVal = hueOffset;
				bVal = 0.0f;

				break;
			}
		case 1:		// Yellow to Green:
			{
				rVal = 1.0f - hueOffset;
				gVal = 1.0f;
				bVal = 0.0f;

				break;
			}
		case 2:		// Green to Cyan:
			{
				rVal = 0.0f;
				gVal = 1.0f;
				bVal = hueOffset;

				break;
			}
		case 3:		// Cyan to Blue:
			{
				rVal = 0.0f;
				gVal = 1.0f - hueOffset;
				bVal = 1.0;

				break;
			}
		case 4:		// Blue to Magenta:
			{
				rVal = hueOffset;
				gVal = 0.0f;
				bVal = 1.0f;

				break;
			}
		case 5:		// Magenta to Red:
			{
				rVal = 1.0f;
				gVal = 0.0f;
				bVal = 1.0f - hueOffset;

				break;
			}
		case 6:		// Pure Red (A hue of 360 is equivalent to a hue of zero.)
			{
				rVal = 1.0f;
				gVal = 0.0f;
				bVal = 0.0f;

				break;
			}
		}

		// Now that we know our component values, we can calculate the value(brightness).
		pureHueVal = (float) ((0.227 * pow((double) rVal, (double) 2.2)) + 
							  (0.715 * pow((double) gVal, (double) 2.2)) + 
							  (0.058 * pow((double) bVal, (double) 2.2)));

		pureHueVal = (float) (pow((double) pureHueVal, (double) 0.454545));

		// And then we store the value in our lookup table.
		valArray[hue] = pureHueVal;
	}

	return valArray;
}


