//////////////////////////////////////////////////////////
// eInDisplay.h - Interface file for the eInDisplay class.
// Part of the eIngine game engine.
//
// This class is used for all 3D graphics rendering calls
// used with the eIngine game engine. No OpenGL or
// Direct3D calls will be made outside of this class. The
// game itself will not know what graphics API it's using.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Pragma directives:
#pragma once

// Includes:
#include "StdAfx.h"						// Precompiled headers.
#include "eInStaticMesh.h"				// eIngine static mesh class.
#include "eInBasicMaterial.h"			// eIngine basic material class.
#include "eInBasicLight.h"				// eIngine basic light class.

// Typedefs:
typedef unsigned int EINenum;

//------------------------------------------------------------
// #define constants. These will be used for setting various
// options in the renderer's state machine.
//------------------------------------------------------------

// General constants:
#define EIN_OFF     (EINenum) 1000
#define EIN_ON      (EINenum) 1001

// Face color mode constants:
#define EIN_RENDER_WIREFRAME	(EINenum) 1200
#define EIN_RENDER_VERTCOLORS	(EINenum) 1201
#define EIN_RENDER_MATCOLORS	(EINenum) 1202
#define EIN_RENDER_COMBINED		(EINenum) 1203
#define EIN_RENDER_TESTMODE		(EINenum) 1299

// Projection mode constants:
#define EIN_PERSPECTIVE  (EINenum) 1600
#define EIN_ORTHOGRAPHIC (EINenum) 1601

// Class Definition:
typedef class CeInDisplay
{
public:
	//------------------------------------------------------------
	// Member variables:
	//------------------------------------------------------------

	UINT xRes;						// Main Render window width in pixels.
	UINT yRes;						// Main Render window height in pixels.

	float windowedAspect;			// Aspect ratio used for normal windowed rendering. 
	float fullScreenAspect;			// Aspect ratio used for full-screen rendering.

	UINT bppColor;					// Number of bits per pixel for color information.
	UINT bppDepth;					// Number of bits for the display's depth buffer.

	HWND  mainWnd;					// Handle to the window that contains the main app.
	HWND  testWnd;					// Handle to a throw away window for testing display capabilities.
	HDC   mainDC;					// Handle to main window's device context.
	HDC	  testDC;					// Handle to test window's device context.
	HGLRC mainRC;					// Handle to main window's OGL rendering context.
	HGLRC testRC;					// Handle to test window's OGL rendering context.

	PIXELFORMATDESCRIPTOR pfd;		// Structure to hold the details of our pixel format.

	EINenum curRenderMode;			// Stores the current rendering mode for all geometry in the scene.
	
	eRGBf clearColor;				// Variable to hold the background color that will be the first thing drawn.

	bool FSAAEnabled;				// Boolean to store whether Full-Screen Anti-Aliasing is enabled by the user.
	bool FSAASupported;				// Boolean to store whether Full-Screen Anti-Aliasing is supported.
	bool stereoSupported;
	bool stereoEnabled;
	bool inFullScreenMode;

	int curPixelFormat;				// Stores the pixel format currently being used.
	
	int StereoFSAA16Format;			// Stereo Rendering format for 16x Anti-Aliasing.
	int StereoFSAA8Format;			// Stereo Rendering format for 8x Anti-Aliasing.
	int	StereoFSAA4Format;			// Stereo Rendering format for 4x Anti-Aliasing.
	int	StereoFSAA2Format;			// Stereo Rendering format for 2x Anti-Aliasing.
	int StereoFSAA0Format;			// Stereo Rendering format for no Anti-Aliasing.

	int FSAA16Format;				// Rendering format for 16x Anti-Aliasing.
	int FSAA8Format;				// Rendering format for 8x Anti-Aliasing.
	int	FSAA4Format;				// Rendering format for 4x Anti-Aliasing.
	int	FSAA2Format;				// Rendering format for 2x Anti-Aliasing.
	int FSAA0Format;				// Rendering format for no Anti-Aliasing.

//	int stereoFormat;				// Rendering format for stereo viewing.

	UINT* boundTextures;			// Pointer to an array of identifiers for textures loaded into card memory.
	

	//------------------------------------------------------------
	// Constructors:
	//------------------------------------------------------------
	
	// Initialization list constructor.
	CeInDisplay(const HWND  &mainHWND,				// Handle to the main application window.
				const HWND  &testHWND,				// Handle to a throw-away window for testing display capabilities.
				const UINT  &someAppXRes,			// X Resolution of Application Display Window.
				const UINT  &someAppYRes,			// Y Resolution of Application Display Window.
				const UINT  &someDesktopXRes,		// X Resolution of Desktop (For Full-Screen Aspect Calculation.)
				const UINT	&someDesktopYRes,		// Y Resolution of Desktop (For Full-Screen Aspect Calculation.)
				const UINT  &someBPPColor,			// Number of Bits Per Pixel for Color Information.
				const UINT  &someBPPDepth);			// Number of Bits Per Pixel for the Depth Buffer.

	// Destructor.
	~CeInDisplay();

	//------------------------------------------------------------
	// Member Function Declarations:
	//------------------------------------------------------------

	// This function is used to shutdown an OpenGL rendering context.
	bool Shutdown();

	// This function is used to change the renderer's video mode.
	bool SetVideoMode(UINT &someWidth,
					  UINT &someHeight,
					  UINT &someBPPColor,
					  UINT &someBPPDepth,
					  bool &renderingFullScreen);

	// This function will test for features such as Full Screen Anti-aliasing.
	bool TestDisplayFeatures();

	// This function is used to setup the OpenGL pixel format.
	bool SetupPixelFormat();

	// This function is used to enable and disable stereo rendering.
	bool EnableStereo(bool stereoEnabledBool);

	// This function is used to enable and disable stereo rendering.
	bool EnableFSAA(bool FSAAEnabledBool);

	// This function is used to setup a viewport.
	bool SetupProjection();

	// This function is used to setup GLSL shader support.
	bool SetupGLSL();

	// This function is used to set the mesh rendering mode.
	bool SetRenderMode(const EINenum &someMode);
	EINenum GetRenderMode()
	{
		return curRenderMode;
	}

	// This function is used to render a mesh object.
	bool RenderMesh(eSTATIC_MESH &someMesh);

	// This function clears the drawing buffer.
	bool ClearDrawBuffer(float r, float g, float b, float a)
	{
		glDrawBuffer(GL_BACK);
		glColor4f(r, b, b, a);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		

		return true;
	}

	// This function is used whenever the buffers for the 3D display need to be swapped.
	bool SwapDeviceBuffers();

	// This function is used to update the fullscreen aspect ratio either directly or by passing
	// it a desktop resolution to compute the proper ratio from.
	bool setFullScreenAspect(const UINT &someDesktopXRes, const UINT &someDesktopYRes);
	bool setFullScreenAspect(const float someAspect);

	// Ok, these two functions take care of finding and initializing the OGL extensions we need.
	bool CheckExtension(char* extensionName);

	// Functions for binding textures:
	bool BindObjectTextures(eSTATIC_MESH &someMesh);
	bool DeleteBoundObjectTextures(eSTATIC_MESH &someMesh);

} eDISPLAY_OBJECT;

// Other Inline Function Definitions:
inline bool CeInDisplay::SwapDeviceBuffers()
{
	// Swap command for stereo viewing.
	// SwapBuffers(mainDC);

	wglSwapLayerBuffers(mainDC, WGL_SWAP_MAIN_PLANE);

	return true;
}

