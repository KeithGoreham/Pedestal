//////////////////////////////////////////////////////////////
// Implementation file for the GameInput function.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "eInStaticMesh.h"

extern eINPUTDEVICE*    g_input;
extern UINT			    g_frameCount;
extern Ce1nPlayer		player;
extern bool				g_isAppFullScreen;
extern HWND				g_hWndMain;

// Preprocessor directives:
#pragma once

// Constants:
#define GAME_JOYAXIS_ROTBIAS		3.0f
#define GAME_JOYAXIS_TRANSBIAS		3.0f
#define GAME_JOYAXIS_MAXROTATION	1.5f
#define GAME_JOYAXIS_MAXTRANSLATION 3.0f

#define GAME_MAX_ROTATION_UP		90.0f
#define GAME_MAX_ROTATION_DOWN	   -90.0f

// Function definition.
int GameInput()
{   
	// Zero out the player acceleration vectors:
	player.accel.x = 0.0f;
	player.accel.y = 0.0f;
	player.accel.z = 0.0f;

	// Read the current state of the keyboard:
	g_input->p_keyboard->Update();

	// Read the state of the joysticks:
	g_input->p_controllers->Update();

	//------------------------------------------------------------
	// Mouse input tests.
	//------------------------------------------------------------
	
	//// Right clicking exits the program.
	//if (g_input->p_mouse->ButtonWasDown(EI_MOUSEBUTTON_2))
	//{
	//	PostQuitMessage(0);
	//}

	//------------------------------------------------------------
	// Keyboard input tests. 
	//------------------------------------------------------------
	// Keyboard Application and Menu Shortcuts: 
	
	// Ctrl+O Opens a file
	if (g_input->p_keyboard->KeyIsDown(EIK_O) && 
	   (g_input->p_keyboard->KeyIsDown(EIK_LCONTROL) || g_input->p_keyboard->KeyIsDown(EIK_RCONTROL)))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_FILE_OPENMODEL, NULL);
	}

	// Ctrl+Q Exits the program
	if (g_input->p_keyboard->KeyIsDown(EIK_Q) && 
	   (g_input->p_keyboard->KeyIsDown(EIK_LCONTROL) || g_input->p_keyboard->KeyIsDown(EIK_RCONTROL)))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_FILE_EXIT, NULL);
	}

	// Ctrl+S toggles stereo viewing
	if (g_input->p_keyboard->KeyIsDown(EIK_S) && 
	   (g_input->p_keyboard->KeyIsDown(EIK_LCONTROL) || g_input->p_keyboard->KeyIsDown(EIK_RCONTROL)))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_3DSTEREO, NULL);
	}

	// The Escape key exits the full screen mode.
	if (g_input->p_keyboard->KeyWasUp(EIK_ESCAPE))
	{
		if (g_isAppFullScreen == true)
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_FULLSCREEN, NULL);
		}
	}

	// ALT + Enter toggles the full-screen mode.
	if ((g_input->p_keyboard->KeyIsDown(EIK_RETURN) || g_input->p_keyboard->KeyIsDown(EIK_NUMPADENTER)) && 
		(g_input->p_keyboard->KeyIsDown(EIK_LALT) || g_input->p_keyboard->KeyIsDown(EIK_RALT)))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_FULLSCREEN, NULL);
	}

	// F2 selects wireframe rendering
	if (g_input->p_keyboard->KeyWasDown(EIK_F2))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_WIREFRAME, NULL);
	}

	// F3 selects wireframe rendering
	if (g_input->p_keyboard->KeyWasDown(EIK_F3))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_VERTCOLORS, NULL);
	}

	// F4 selects wireframe rendering
	if (g_input->p_keyboard->KeyWasDown(EIK_F4))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_MATERIALCOLORS, NULL);
	}

	// F5 selects wireframe rendering
	if (g_input->p_keyboard->KeyWasDown(EIK_F5))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_COMBINED, NULL);
	}

	// F6 selects wireframe rendering
	if (g_input->p_keyboard->KeyWasDown(EIK_F6))
	{
		SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_TESTMODE, NULL);
	}

	//------------------------------------------------------------
	// Keyboard Movement Controls: 

	// Up Arrow - Move Forward
	if (g_input->p_keyboard->KeyIsDown(EIK_UPARROW))
	{
		player.accel.z = 1.0f;
	}

	// Down Arrow - Move Backward
	if (g_input->p_keyboard->KeyIsDown(EIK_DOWNARROW))
	{
		player.accel.z = -1.0f;
	}

	// Left Arrow - Turn Left
	if (g_input->p_keyboard->KeyIsDown(EIK_LEFTARROW))
	{
		player.rot.y += -1.0f;
	}	

	// Right Arrow - Turn Right
	if (g_input->p_keyboard->KeyIsDown(EIK_RIGHTARROW))
	{
		player.rot.y += 1.0f;
	}
	
	// W Key - Pan Up
	if (g_input->p_keyboard->KeyIsDown(EIK_W))
	{
		player.accel.y = -0.5f;
	}

	// S Key - Pan Down
	if (g_input->p_keyboard->KeyIsDown(EIK_S))
	{
		player.accel.y = 0.5f;
	}

	// A Key - Strafe Left
	if (g_input->p_keyboard->KeyIsDown(EIK_A))
	{
		player.accel.x = 0.5f;
	}

	// D Key - Strafe Left
	if (g_input->p_keyboard->KeyIsDown(EIK_D))
	{
		player.accel.x = -0.5f;
	}

	// Numpad 8 Key - Rotate Up
	if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD8))
	{
		player.rot.x += -1.0f;
	}

	// Numpad 2 Key - Rotate Down
	if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD2))
	{
		player.rot.x += 1.0f;
	}

	// Numpad 4 Key - Rotate Left
	if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD4))
	{
		player.rot.y += -1.0f;
	}	

	// Numpad 6 Key - Rotate Right
	if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD6))
	{
		player.rot.y += 1.0f;
	}

	// Numpad 5 Key - Fly Forward
	if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD5))
	{
		player.vel.z = cos(PI / 180.0f * player.rot.y) * 1.0f;
		player.vel.x = -((sin(PI / 180.0f * player.rot.y)) * 1.0f);
		player.vel.y = (sin(PI / 180.0f * player.rot.x) * 1.0f);

		player.pos.z += player.vel.z;
		player.pos.x += player.vel.x;
		player.pos.y += player.vel.y;
	}

	// Space Bar - Reset Position & Rotation
	if (g_input->p_keyboard->KeyIsDown(EIK_SPACE))
	{
			player.pos.x = 0.0f;
			player.pos.y = 0.0f;
			player.pos.z = 0.0f;

			player.rot.x = 0.0f;
			player.rot.y = 0.0f;
	}
	
	// Fly Backward (Keypad 0 Key)
	else if (g_input->p_keyboard->KeyIsDown(EIK_NUMPAD0))
	{
		player.vel.z = -(cos(PI / 180.0f * player.rot.y) * 2.0f);
		player.vel.x =  (sin(PI / 180.0f * player.rot.y)) * 2.0f;
		player.vel.y = -(sin(PI / 180.0f * player.rot.x) * 2.0f);
		
		player.pos.z += player.vel.z;
		player.pos.x += player.vel.x;
		player.pos.y += player.vel.y;
	}

	// Shift Key - Run
	if (g_input->p_keyboard->KeyIsDown(EIK_LSHIFT))
	{
		player.accel.x *= 3.0f;
		player.accel.y *= 3.0f;
		player.accel.z *= 3.0f;
	}

	//------------------------------------------------------------
	// JOYSTICK INPUT TESTS
	//------------------------------------------------------------
	if (g_input->p_controllers->GetNumAttachedJoysticks() > 0)
	{
		// Temp variable we'll use to retrieve all the joystick axis for processing.
		float axisVal; 

		//------------------------------------------------------------
		// Get the joytick axis rotation data.
		//------------------------------------------------------------

		// Up/Down rotation: 
		axisVal = -(g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_RY));

		if	 (axisVal < 0.0f) {axisVal = -(pow(fabs(axisVal), GAME_JOYAXIS_ROTBIAS));}
		else {axisVal = pow(axisVal, GAME_JOYAXIS_ROTBIAS);}

		player.rot.x += axisVal * GAME_JOYAXIS_MAXROTATION;

		if (player.rot.x > GAME_MAX_ROTATION_UP)  {player.rot.x = GAME_MAX_ROTATION_UP;}
		if (player.rot.x < GAME_MAX_ROTATION_DOWN){player.rot.x = GAME_MAX_ROTATION_DOWN;}

		// Left/Right rotation:
		axisVal = g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_RX);

		if	 (axisVal < 0.0f) {axisVal = -(pow(fabs(axisVal), GAME_JOYAXIS_ROTBIAS));}
		else {axisVal = pow(axisVal, GAME_JOYAXIS_ROTBIAS);} 

		player.rot.y += axisVal * GAME_JOYAXIS_MAXROTATION;

		if (player.rot.y > 360.0f){player.rot.y -= 360.0f;}
		if (player.rot.y < 0.0f)  {player.rot.y += 360.0f;}

		//------------------------------------------------------------
		// Get the joystick translation data.
		//------------------------------------------------------------

		// Up/Down Move (Into and out of the screen.)
		axisVal = g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_LY);

		if (axisVal != 0.0f)
		{
			float zMoveRatio;
			float xyMoveRatio;

			if (axisVal < 0.0f) {axisVal = -(pow(fabs(axisVal), GAME_JOYAXIS_TRANSBIAS));}
			else				{axisVal = pow(axisVal, GAME_JOYAXIS_TRANSBIAS);}

			xyMoveRatio  =   sin(PI / 180.0f * player.rot.x);
			zMoveRatio   = -(cos(PI / 180.0f * player.rot.x));
		
			player.vel.z =   (cos(PI / 180.0f * player.rot.y)  * (axisVal * GAME_JOYAXIS_MAXTRANSLATION)) * xyMoveRatio;
			player.vel.x = (-(sin(PI / 180.0f * player.rot.y)) * (axisVal * GAME_JOYAXIS_MAXTRANSLATION)) * xyMoveRatio;
			player.vel.y = zMoveRatio * (axisVal * GAME_JOYAXIS_MAXTRANSLATION);		// Up

			player.pos.z += player.vel.z;		
			player.pos.x += player.vel.x;
			player.pos.y += player.vel.y;		// Up
		}

		// X-Axis Move (Left and Right Strafe)

		axisVal = -(g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_LX));

		if (axisVal < 0.0f) {axisVal = -(pow(fabs(axisVal), GAME_JOYAXIS_TRANSBIAS));}
		else				{axisVal = pow(axisVal, GAME_JOYAXIS_TRANSBIAS);}

		player.accel.x += axisVal * GAME_JOYAXIS_MAXTRANSLATION;
		
		//------------------------------------------------------------
		// Other joystick data.
		//------------------------------------------------------------

		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_RTRIGGER))		// Fly Forward
		{
			float zMoveRatio;
			float xyMoveRatio;

			axisVal = g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_RTRIGGER);
			axisVal = pow(axisVal, GAME_JOYAXIS_TRANSBIAS);
			axisVal *= GAME_JOYAXIS_MAXTRANSLATION;

			zMoveRatio  = sin(PI / 180.0f * player.rot.x);
			xyMoveRatio = cos(PI / 180.0f * player.rot.x);
		
			player.vel.z =   (cos(PI / 180.0f * player.rot.y)  * axisVal) * xyMoveRatio;
			player.vel.x = (-(sin(PI / 180.0f * player.rot.y)) * axisVal) * xyMoveRatio;
			player.vel.y = zMoveRatio * axisVal;		// Up

			player.pos.z += player.vel.z;		
			player.pos.x += player.vel.x;
			player.pos.y += player.vel.y;		// Up
		}
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_LTRIGGER))		// Fly Backward
		{
			float zMoveRatio;
			float xyMoveRatio;

			axisVal = g_input->p_controllers->GetAxisValue(EI_JOY1, EI_JOYAXIS_LTRIGGER);
			axisVal = pow(axisVal, GAME_JOYAXIS_TRANSBIAS);
			axisVal *= GAME_JOYAXIS_MAXTRANSLATION;

			zMoveRatio  = sin(PI / 180.0f * player.rot.x);
			xyMoveRatio = cos(PI / 180.0f * player.rot.x);
		
			player.vel.z = (-(cos(PI / 180.0f * player.rot.y)  * axisVal)) * xyMoveRatio;
			player.vel.x =  ((sin(PI / 180.0f * player.rot.y)) * axisVal)  * xyMoveRatio;
			player.vel.y = -(zMoveRatio * axisVal);		// Up
			
			player.pos.z += player.vel.z;
			player.pos.x += player.vel.x;
			player.pos.y += player.vel.y;		// Up
		}


		// Reset player to start position on button 10 (Start)
		if (g_input->p_controllers->ButtonWasDown(EI_JOY1, EI_JOYBUTTON_START) &&
			!g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK))
		{
			player.pos.x = 0.0f;
			player.pos.y = 0.0f;
			player.pos.z = 0.0f;

			player.rot.x = 0.0f;
			player.rot.y = 0.0f;
			player.rot.z = 0.0f;
		}

		// Reset viewport rotation on right thumb button.
		if (g_input->p_controllers->ButtonWasDown(EI_JOY1, EI_JOYBUTTON_RTHUMB))
		{
			player.rot.x = 0.0f;
			player.rot.y = 0.0f;
			player.rot.z = 0.0f;
		}

		// Reset viewport translation on left thumb button.
		if (g_input->p_controllers->ButtonWasDown(EI_JOY1, EI_JOYBUTTON_LTHUMB))
		{
			player.pos.x = 0.0f;
			player.pos.y = 0.0f;
			player.pos.z = 0.0f;
		}

		// POV Up - Move Forward
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_UP) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_UPRIGHT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_UPLEFT))
		{
			player.accel.z = 1.0f;
		}

		// POV Down - Move Backward
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_DOWN) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_DOWNRIGHT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_DOWNLEFT))
		{
			player.accel.z = -1.0f;
		}

		// POV Left - Turn Left
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_LEFT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_UPLEFT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_DOWNLEFT))
		{
			player.rot.y += -1.0f;
		}	

		// POV Right - Turn Right
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_RIGHT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_UPRIGHT) ||
			g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYPOV_DOWNRIGHT))
		{
			player.rot.y += 1.0f;
		}

		// Back Button + Y - Wireframe Mode
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasUp(EI_JOY1, EI_JOYBUTTON_Y))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_WIREFRAME, NULL);
		}

		// Back Button + B - Vertex Color Mode
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasUp(EI_JOY1, EI_JOYBUTTON_B))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_VERTCOLORS, NULL);
		}

		// Back Button + A - Material Color Mode
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasUp(EI_JOY1, EI_JOYBUTTON_A))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_MATERIALCOLORS, NULL);
		}

		// Back Button + X - Combined Render Mode
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasUp(EI_JOY1, EI_JOYBUTTON_X))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_COMBINED, NULL);
		}

		// Back Button + RB - Combined Render Mode
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasUp(EI_JOY1, EI_JOYBUTTON_RB))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_RENDER_TESTMODE, NULL);
		}

		// Back Button + Start Button - FullScreen Toggle
		if (g_input->p_controllers->ButtonIsDown(EI_JOY1, EI_JOYBUTTON_BACK) &&
			g_input->p_controllers->ButtonWasDown(EI_JOY1, EI_JOYBUTTON_START))
		{
			SendMessage(g_hWndMain, WM_COMMAND, ID_VIEW_FULLSCREEN, NULL);
		}

	}	
	
    return 0;
}