//////////////////////////////////////////////////////////////
// Implementation file for the Main UI Render Window functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "uiFunctions.h"

//======================================================================
// WndProc_Render() - Our Windows event handler for the splash screen.
//======================================================================
long CALLBACK WndProc_Render(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	// Now we run a switch on the message to decide what to do.
	switch (uMessage)
	{
	//case WM_CREATE:				// Called when the window is created.
	//	{
	//		int deskWidth;
	//		int deskHeight;
 //           
	//		int splashPosX;
	//		int splashPosY;

	//		HWND hDesktopWnd = GetDesktopWindow();
	//		HDC  hDesktopDC  = GetDC(hDesktopWnd);

	//		// Retrieve the width and height of the display.
	//		deskWidth  = GetDeviceCaps(hDesktopDC, HORZRES);
	//		deskHeight = GetDeviceCaps(hDesktopDC, VERTRES);

	//		// And set the position.
	//		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, g_fullScreenResolution.x, g_fullScreenResolution.y, NULL);

	//		return 0;
	//	}
	case WM_PAINT:				// Called whenever the window needs to be redrawn.
		{
			// Tell Windows to assume I've updated whatever needs updating.
			ValidateRect(hWnd, NULL);

			return 0;
		}
	default:					// Some other message.
		{
			// Let Windows handle the message.
			return (long) DefWindowProc(hWnd, uMessage, wParam, lParam);
		}
	}
}

//======================================================================
// CreateRenderWindow() - Function to create a render window.
//======================================================================
int CreateRenderWindow(void)
{
	// Instantiate a Window Class.
	WNDCLASSEX winClassRender;

	// Now we modify the winClass information for our Splash Window.
	winClassRender.cbSize		 = sizeof(WNDCLASSEX);
	winClassRender.style		 = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	winClassRender.cbClsExtra	 = 0;
	winClassRender.cbWndExtra	 = 0;
	winClassRender.lpfnWndProc	 = WndProc_Render;
	winClassRender.hInstance	 = g_hInstance;
	winClassRender.hbrBackground = NULL;
	winClassRender.hIcon		 = NULL;
	winClassRender.hIconSm		 = NULL;
	winClassRender.hCursor		 = NULL;
	winClassRender.lpszMenuName	 = NULL;
	winClassRender.lpszClassName = RENDER_NAME;
	
	// Now we register the window classes.
	RegisterClassEx(&winClassRender);

	// Now we figure out the size and position of the render window.
	// Rects for the dimensions of our various windows:
	RECT mainWindowRect;
	RECT mainClientRect;
	RECT statusRect;
	
	GetWindowRect(g_hWndMain, &mainWindowRect);
	GetClientRect(g_hWndMain, &mainClientRect);
	GetWindowRect(g_hWndStatusBar, &statusRect);
	
	// Figure out our window's width, height, and position.
	UINT statusBarHeight = statusRect.bottom - statusRect.top;
	UINT winWidth		 = mainClientRect.right;
	UINT winHeight		 = mainClientRect.bottom - statusBarHeight;
	UINT xBorder		 = ((mainWindowRect.right - mainWindowRect.left) - mainClientRect.right) / 2;

	// And we create the window.
	g_hWndRender = CreateWindowEx(WS_EX_CLIENTEDGE,											// Extended Windows Style
								  RENDER_NAME,									// Class Name
								  APP_NAME,										// App Name
								  WS_CHILD | WS_VISIBLE,						// Window Style
								  0, 0,											// X and Y position.
								  winWidth, winHeight,							// Width and Height.
								  g_hWndMain,									// Parent window handle.
								  (HMENU) 1,									// Menu
								  NULL,											// Obsolete in 2000/XP.
								  NULL);										// For MDI apps.

	return 0;
}

int CreateFullScreenRenderWindow(UINT &whichMonitor)
{
	// Instantiate a Window Class.
	WNDCLASSEX winClassRenderFS;

	// Now we modify the winClass information for our Full Screen Render Window.
	winClassRenderFS.cbSize			= sizeof(WNDCLASSEX);
	winClassRenderFS.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	winClassRenderFS.cbClsExtra		= 0;
	winClassRenderFS.cbWndExtra		= 0;
	winClassRenderFS.lpfnWndProc	= WndProc_Main;
	winClassRenderFS.hInstance		= g_hInstance;
	winClassRenderFS.hbrBackground	= NULL;
	winClassRenderFS.hIcon			= NULL;
	winClassRenderFS.hIconSm		= NULL;
	winClassRenderFS.hCursor		= NULL;
	winClassRenderFS.lpszMenuName	= NULL;
	winClassRenderFS.lpszClassName	= APP_NAME;
	
	// Now we register the window classes.
	RegisterClassEx(&winClassRenderFS);

	// And we create the window.
	g_hWndMain = CreateWindowEx(NULL,													// Extended Windows Style
								APP_NAME,												// Class Name
								APP_NAME,												// App Name
								WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,			// Window Style
								0, 0,													// X and Y position.
								g_fullScreenResolutions[whichMonitor].x,					// Width
								g_fullScreenResolutions[whichMonitor].y,					// Height
								NULL,													// Parent window handle.
								NULL,													// Menu
								NULL,													// Obsolete in 2000/XP.
								NULL);													// For MDI apps.

	return 0;
}