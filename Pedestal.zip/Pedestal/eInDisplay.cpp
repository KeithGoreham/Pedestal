//////////////////////////////////////////////////////////
// eInDisplay.cpp - Implementation file for the eInDisplay
// class. Part of the eIngine game engine.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// includes:
#include "eInDisplay.h"
#include "stdafx.h"


//========================================================
// Constructors
//========================================================

// Initialization list constructor.
CeInDisplay::CeInDisplay(const HWND  &mainHWND,				// Handle to the main application window.
						 const HWND  &testHWND,
						 const UINT  &someAppXRes,
						 const UINT  &someAppYRes,
						 const UINT  &someDesktopXRes,
						 const UINT  &someDesktopYRes,
						 const UINT  &someBPPColor,			
						 const UINT  &someBPPDepth) : mainWnd(mainHWND),
													  testWnd(testHWND),	
			   										  xRes(someAppXRes),
													  yRes(someAppYRes),
													  bppColor(someBPPColor),
													  bppDepth(someBPPDepth)
{
	FSAASupported = false;
	FSAAEnabled	  = true;

	FSAA16Format  = 0;
	FSAA8Format   = 0;
	FSAA4Format   = 0;
	FSAA2Format   = 0;
	FSAA0Format   = 0;

	StereoFSAA16Format = 0;			
	StereoFSAA8Format  = 0;			
	StereoFSAA4Format  = 0;			
	StereoFSAA2Format  = 0;			
	StereoFSAA0Format  = 0;	

	// Work out the aspect ratios for windowed and full-screen rendering.
	windowedAspect   = (float) yRes / (float) xRes;
	fullScreenAspect = (float) someDesktopYRes / (float) someDesktopXRes;

	inFullScreenMode = false;
	
	// Get a device context for our rendering windows:
	testDC = GetDC(testHWND);
	mainDC = GetDC(mainHWND);

	// Test the multisampling modes using the test window.
	TestDisplayFeatures();
	
	if ((FSAASupported == true) && (FSAA8Format > 0))
	{
		curPixelFormat = FSAA8Format;
	}
	if ((FSAASupported == true) && (FSAA4Format > 0))
	{	
		curPixelFormat = FSAA4Format;
	}
	else if	((FSAASupported == true) && (FSAA2Format > 0))
	{
		curPixelFormat = FSAA2Format;
	}
	else
	{
		curPixelFormat = FSAA0Format;
	}

	bool tmpFalse = false;

	// Set the video mode for the main display.
	SetVideoMode(xRes, yRes, bppColor, bppDepth, tmpFalse);

	// Setup the GLSL functions.
	if (!SetupGLSL()){OutputDebugString("GLSL Initialization has failed\n");}
	else			 {OutputDebugString("GLSL Initialization succeded\n");}

	// Zero out the bound textures pointer.
	boundTextures = NULL;
}

// Destructor
CeInDisplay::~CeInDisplay(void)
{
	// Do Nothing.
}

//------------------------------------------------------------
// This function is used to shutdown an OpenGL rendering
// context.
//------------------------------------------------------------
bool CeInDisplay::Shutdown()
{
	wglMakeCurrent(mainDC, NULL);				// Deselect OpenGL rendering context.
	wglDeleteContext(mainRC);					// Delete OpenGL rendering context.

	return true;
}

//--------------------------------------------------------------
// This function is used to change the main window's video mode.
//--------------------------------------------------------------
bool CeInDisplay::SetVideoMode(UINT &someWidth,
							   UINT &someHeight,
							   UINT &someBPPColor,
							   UINT &someBPPDepth,
							   bool &renderingFullScreen)
{
	// Grab the dimensions of our new window.
	xRes = someWidth;
	yRes = someHeight;

	// Re-calculate the windowed Aspect Ratio.
	windowedAspect = (float) yRes / (float) xRes; 

	// Just say no to divide by zero.
	if (yRes == 0){yRes = 1;}					

	// Update the full-screen state.
	inFullScreenMode = renderingFullScreen;

	// Grab the BPP for the color and depth buffers.
	bppColor = someBPPColor;
	bppDepth = someBPPDepth;

	// Select and then delete the old OGL rendering context.
	wglMakeCurrent(mainDC, NULL);
	wglDeleteContext(mainRC);

	// Setup the pixel format:
	SetupPixelFormat();	

	// Create a new OpenGl rendering context.
	mainRC = wglCreateContext(mainDC);

	// Make rendering context current.
	wglMakeCurrent(mainDC, mainRC);	

	// Set up the projection matrix.
	SetupProjection();

	return true;
}

// This function is used to update the fullscreen aspect ratio either directly or by passing
	// it a desktop resolution to compute the proper ratio from.
bool CeInDisplay::setFullScreenAspect(const UINT &someDesktopXRes, const UINT &someDesktopYRes)
{
	fullScreenAspect = (float) someDesktopYRes / (float) someDesktopXRes;

	SetupProjection();

	return true;
}

bool CeInDisplay::setFullScreenAspect(const float someAspect)
{
	fullScreenAspect = someAspect;

	SetupProjection();

	return true;
}

//------------------------------------------------------------
// This function is used to setup the OpenGL pixel format.
//------------------------------------------------------------
bool CeInDisplay::SetupPixelFormat()
{
	// Zero out the memory for the Pixel Format structure. We'll fill in just the parts we need.
	memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));	

	// Now we fill in the details of the pixel format:
	pfd.nSize		= sizeof(pfd);														// Size of this structure.
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;		// Pixel Buffer Properties.
	pfd.nVersion	= 1;																// Version of this structure (always 1).
	pfd.iPixelType	= PFD_TYPE_RGBA;													// Type of Pixel Data (RGBA or Color Index).
	pfd.cColorBits	= bppColor;															// Number of color bit planes in color buffer.
	pfd.cDepthBits  = bppDepth;															// Number of bits for the depth buffer.
	pfd.iLayerType  = PFD_MAIN_PLANE;													// Obsolete - Ignored.		

	SetPixelFormat(mainDC, curPixelFormat, &pfd);

	int curFormat = GetPixelFormat(mainDC);

	return true;
}

//------------------------------------------------------------
// This function is used to setup a viewport.
//------------------------------------------------------------
bool CeInDisplay::SetupProjection()
{
	// Reset the viewport to our new dimensions.
	glViewport(0, 0, xRes, yRes);

	glMatrixMode(GL_PROJECTION);				// Sets the type of our current matrix.
	glLoadIdentity();							// Resets the matrix.

	float frustWidth;

	if (inFullScreenMode == true){frustWidth = 1.0 / fullScreenAspect;}
	else						 {frustWidth = 1.0 / windowedAspect;}

	// Setup our stereo perspective view using glFrustum.
	glFrustum(-frustWidth, frustWidth, -1.0f, 1.0f, 2, 9999);

	glMatrixMode(GL_MODELVIEW);				// Loads the matrix used for drawing models.
	glLoadIdentity();						// And resets that matrix.
	
	return true;
}

//------------------------------------------------------------
// This function is used to set the rendering mode for a scene.
//------------------------------------------------------------
bool CeInDisplay::SetRenderMode(const EINenum &someMode)
{
	curRenderMode = someMode;

	return true;
}

//------------------------------------------------------------
// This function is used to check for specific OGL extensions.
//------------------------------------------------------------
bool CeInDisplay::CheckExtension(char* extensionName)
{
	// get the list of supported extensions
   char* extensionList = (char*) glGetString(GL_EXTENSIONS);
   
   if (!extensionName || !extensionList)
      return false;
   
   while (extensionList)
   {
      // find the length of the first extension substring
      unsigned int firstExtensionLength = strcspn(extensionList, " ");
   
      if (strlen(extensionName) == firstExtensionLength &&
         strncmp(extensionName, extensionList, firstExtensionLength) == 0)
      {
      return true;
      }
   
      // move to the next substring
      extensionList += firstExtensionLength + 1;
   }

   return false;
}

//------------------------------------------------------------
// This function is used to load a mesh's textures into the
// video card's memory.
//------------------------------------------------------------
bool CeInDisplay::BindObjectTextures(eSTATIC_MESH &someMesh)
{
	eBASIC_MAT* curMat;

	if (boundTextures != NULL)
	{
		DeleteBoundObjectTextures(someMesh);
		boundTextures = NULL;
	}

	boundTextures = new UINT[someMesh.numMaterials];

	glGenTextures(someMesh.numMaterials, boundTextures);

	// Step through each of the object's materials.
	for (UINT i = 0; i < someMesh.numMaterials; i++)
	{
		// Grab a pointer to the current material:
		curMat = &someMesh.materials[i];

		// Bind the appropriate texture so we can make changes.
		glBindTexture(GL_TEXTURE_2D, boundTextures[i]);

		gluBuild2DMipmaps(GL_TEXTURE_2D,				// The type of OpenGL texture to make.
						  GL_RGBA,						// Internal Texture Format
				//		  GL_RGB,						// Internal Texture Format
						  curMat->diffuseMapSize.x,		// Texture Width
						  curMat->diffuseMapSize.y,		// Texture Height
						  GL_RGBA,						// Format of texture data.
						  GL_UNSIGNED_BYTE,				// Data format of each component.
						  curMat->diffuseMapData);		// Array containing the data for the texture.

		// And then we apply various parameters for this texture:
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0);

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	}

	return true;
}

//------------------------------------------------------------
// This function is used to delete a mesh's textures from the
// video card's memory.
//------------------------------------------------------------
bool CeInDisplay::DeleteBoundObjectTextures(eSTATIC_MESH &someMesh)
{
	glDeleteTextures(someMesh.numMaterials, boundTextures);

	return true;
}

// This function is used to enable and disable stereo rendering.
bool CeInDisplay::EnableStereo(bool stereoEnabledBool)
{
	stereoEnabled = stereoEnabledBool;

	if ((FSAAEnabled == false) && (stereoEnabled == false))
	{
		curPixelFormat = FSAA0Format;
	}
	else if ((FSAAEnabled == true) && (stereoEnabled == false))	
	{
		curPixelFormat = FSAA4Format;
	}
	else if ((FSAAEnabled == false) && (stereoEnabled == true))	
	{
		curPixelFormat = StereoFSAA4Format;
	}
	else if ((FSAAEnabled == true) && (stereoEnabled == true))	
	{
		curPixelFormat = StereoFSAA4Format;
	}

	return true;
}

	// This function is used to enable and disable stereo rendering.
bool CeInDisplay::EnableFSAA(bool FSAAEnabledBool)
{
	FSAAEnabled = FSAAEnabledBool;

	if ((FSAAEnabled == false) && (stereoEnabled == false))
	{
		curPixelFormat = FSAA0Format;
	}
	else if ((FSAAEnabled == true) && (stereoEnabled == false))	
	{
		curPixelFormat = FSAA4Format;
	}
	else if ((FSAAEnabled == false) && (stereoEnabled == true))	
	{
		curPixelFormat = StereoFSAA4Format;
	}
	else if ((FSAAEnabled == true) && (stereoEnabled == true))	
	{
		curPixelFormat = StereoFSAA4Format;
	}

	return true;
}
