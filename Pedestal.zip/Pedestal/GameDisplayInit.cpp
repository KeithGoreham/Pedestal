//////////////////////////////////////////////////////////////
// Implementation file for the GameDisplayInit function.
//
// This function takes care of setting up the renderer for a
// new display or display change.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"					// Precompiled headers.
#include "MiscFunctions.h"			// Various custom math and other functions.
#include "GameFunctions.h"			// Header file for all main game functions.
#include "Point2.h"					// Custom 2D integer vector class (For edge definitions).
#include "Point3.h"					// Custom 3D integer vector class (For face definitions).
#include "Vector2.h"				// Custom 2D floating point vector class (For 2D positions).
#include "Vector3.h"				// Custom 3D floating point vector class (For 3D positions).
#include "Array.h"					// Custom array class.
#include "eInStaticMesh.h"			// Custom 3D mesh class.
#include "eInDisplay.h"				// Custom 3D renderer class.

#include "eInDisplay.h"
#include "eInStaticMesh.h"

extern HWND g_hWndMain;
extern HDC g_hDC;
extern eDISPLAY_OBJECT* g_display;

extern UINT  g_appWinWidth;
extern UINT  g_appWinHeight;
extern UINT  g_appWinBPPColor;
extern UINT  g_appWinBPPDepth;

extern eSTATIC_MESH* g_playerMesh;

// Function definition.
int GameDisplayInit()
{
	
	return 0;
}