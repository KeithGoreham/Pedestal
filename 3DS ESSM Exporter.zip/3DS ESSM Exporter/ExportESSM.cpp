////////////////////////////////////////////////////////////////////////
// ExportESSM.h - Implementation file for the CExportESSM function that
// will handle the export of a mesh file from 3DS Max.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Include Files:
#include "StdAfx.h"
#include "ExportESSM.h"
#include "uiFunctions.h"

// iGame Object Type Enumerations:
#define IGAME_UNKNOWN	0
#define IGAME_LIGHT		1	
#define IGAME_MESH		2
#define IGAME_SPLINE	3	
#define IGAME_CAMERA	4
#define IGAME_HELPER	5
#define IGAME_BONE		6
#define IGAME_IKCHAIN	7

// iGame Property Enumerations:
#define IGAME_UNKNOWN_PROP	0
#define IGAME_FLOAT_PROP	1
#define IGAME_INT_PROP		2
#define IGAME_POINT3_PROP	3
#define IGAME_STRING_PROP	4
#define IGAME_POINT4_PROP	5


//======================================================================
// Constructor and Destructor:
//======================================================================
CExportESSM::CExportESSM(void)
{
	// Initialize the iGame interface and conversion manager:
	p_iGame   = GetIGameInterface();
	p_iGameCM = GetConversionManager();
}

CExportESSM::~CExportESSM(void)
{
	OutputDebugString("Releasing iGame...\n");
	p_iGame->ReleaseIGame();
	OutputDebugString("iGame Released.\n");

	//OutputDebugString("Deleting Conversion Mgr...\n");
	//if (p_iGameCM != 0){delete p_iGameCM;}
	//OutputDebugString("Conversion Mgr deleted.\n");
}

//======================================================================
// Custom export function implementations:
//======================================================================
bool CExportESSM::SetupIGameOptions(bool exportSelected)
{
	// Set the iGame coordinate system to match the e1ngine's OpenGL orientation.
	p_iGameCM->SetCoordSystem(p_iGameCM->IGAME_OGL);

	// Decide whether we're exporting only the selected objects (true) or all objects (false):
	OutputDebugString("About to Initialize iGame...\n");
	if (exportSelected == true)
	{
		p_iGame->InitialiseIGame(true);			
	}
	else
	{
		p_iGame->InitialiseIGame(false);		
	}
	OutputDebugString("iGame Initialized.\n");

	// Tell iGame we want to process our objects at animation frame 0.
	OutputDebugString("Setting Static Frame...\n");
	p_iGame->SetStaticFrame(0);
	OutputDebugString("Static Frame Set.\n");

	return true;
}

//======================================================================
// Begin standard Max export plugin function implementations:
//======================================================================

// The actual export of the file is performed here:
int	CExportESSM::DoExport(const TCHAR *someName,ExpInterface *someExportInterface,Interface *someInterface, BOOL suppressPrompts, DWORD options)
{
	// Buffer for debug text
	char buffer[256];

	// Setup our iGame options:
	SetupIGameOptions((options & SCENE_EXPORT_SELECTED));

	// Setup our export mesh:
	meshInfo exportMesh;

	//----------------------------------------------------------------------
	// Begin Geometry Export
	//----------------------------------------------------------------------
	OutputDebugString("Beginning Geometry Export...\n");

	// Get the number of nodes in the scene:
	UINT nodeCount = p_iGame->GetTopLevelNodeCount();

	// We'll then allocate an array of iGameMesh pointers. One for each node.
	UINT		numSceneMeshes = 0;
	IGameMesh** sceneMeshes    = new IGameMesh*[nodeCount];

	// Iterate through all the nodes:
	for (UINT i = 0; i < nodeCount; i++)
	{
		// Get the current node:
		IGameNode* curNode = p_iGame->GetTopLevelNode(i);

		// Use the node to grab the current object and retrieve it's type:
		IGameObject* curObject = curNode->GetIGameObject();
		IGameObject::ObjectTypes objType = curObject->GetIGameType();

		// If this node is a mesh, we'll find out how many faces and such it has.
		if (objType == IGAME_MESH)
		{
			numSceneMeshes += 1;								// Add one to the mesh count.
			sceneMeshes[i] = (IGameMesh*)curObject;				// Grab the mesh.
			sceneMeshes[i]->SetCreateOptimizedNormalList();		// Without this we can't access the mesh's normals.
			sceneMeshes[i]->InitializeData();					// Without this we can't access the mesh's faces.

			// Grab all the relevent topology info for the export mesh:
			exportMesh.numGVerts	+= sceneMeshes[i]->GetNumberOfVerts();
			exportMesh.numTVerts	+= sceneMeshes[i]->GetNumberOfTexVerts();
			exportMesh.numNVerts	+= sceneMeshes[i]->GetNumberOfNormals();
			exportMesh.numCPVColors += sceneMeshes[i]->GetNumberOfColorVerts();
			exportMesh.numGFaces	+= sceneMeshes[i]->GetNumberOfFaces();
			
			// Now we'll count up the number of visible edges:
			for (UINT j = 0; j < sceneMeshes[i]->GetNumberOfFaces(); j++)
			{
				FaceEx* curFace = sceneMeshes[i]->GetFace(j);

				if (curFace->edgeVis[0] == 1){exportMesh.numGEdges += 1;}
				if (curFace->edgeVis[1] == 1){exportMesh.numGEdges += 1;}
				if (curFace->edgeVis[2] == 1){exportMesh.numGEdges += 1;}
			}		
		}
	}
	
	// Debug
	sprintf(buffer, "Found %d gVerts.\n",   exportMesh.numGVerts);    OutputDebugString(buffer);
	sprintf(buffer, "Found %d tVerts.\n",   exportMesh.numTVerts);    OutputDebugString(buffer);
	sprintf(buffer, "Found %d nVerts.\n",   exportMesh.numNVerts);    OutputDebugString(buffer);
	sprintf(buffer, "Found %d cpvVerts.\n", exportMesh.numCPVColors); OutputDebugString(buffer);
	sprintf(buffer, "Found %d faces.\n",    exportMesh.numGFaces);    OutputDebugString(buffer);
	sprintf(buffer, "Found %d edges.\n",    exportMesh.numGEdges);    OutputDebugString(buffer);

	//----------------------------------------------------------------------
	// Allocate memory for mesh component arrays:
	//----------------------------------------------------------------------
	OutputDebugString("Allocating Memory for Mesh Component Arrays...\n");

	exportMesh.gVerts   = new float3[exportMesh.numGVerts];
	exportMesh.gEdges   = new point2[exportMesh.numGEdges];
	exportMesh.gFaces   = new point3[exportMesh.numGEdges];
	exportMesh.tVerts   = new float2[exportMesh.numTVerts];
	exportMesh.tFaces   = new point3[exportMesh.numGFaces];
	exportMesh.nVerts   = new float3[exportMesh.numNVerts];
	exportMesh.nFaces   = new point3[exportMesh.numGFaces];
	exportMesh.CPVFaces = new point3[exportMesh.numCPVColors];
	
	// Set the wirecolor of the export mesh to white:
	exportMesh.wireColor.r = 255;
	exportMesh.wireColor.g = 255;
	exportMesh.wireColor.b = 255;

	// Now we'll copy all the various verticies into the export mesh.

	UINT gVertsWritten = 0;


	// Step through each mesh in the scene...
	for (i = 0; i < numSceneMeshes; i++)
	{
		// Step through each gVert...
		for (UINT j = 0; j < sceneMeshes[i]->GetNumberOfVerts(); j++)
		{
			// Grab the current vertex.
			Point3 curGVert;
			sceneMeshes[i]->GetVertex(j, curGVert, false);

			// Find out if this vert exists already in the exportMesh.
			for (UINT k = 0; k < gVertsWritten; k++)
			{
				if ((curGVert.x == exportMesh.gVerts[k].x) &&
					(curGVert.y == exportMesh.gVerts[k].y) &&
					(curGVert.z == exportMesh.gVerts[k].z))
				{
					
				}
				   
			}
		}
	}


	//----------------------------------------------------------------------
	// Clean up allocated memory and exit:
	//----------------------------------------------------------------------
	OutputDebugString("Cleaning up allocated memory...\n");

	if (sceneMeshes != NULL){delete[] sceneMeshes;}		// Do I have to loop this?


	// return TRUE If the file is exported properly
	return TRUE;
}

// Returns the number of file name extensions supported by this plugin:
int CExportESSM::ExtCount()
{
	return ESSMEXP_FILEEXTENSIONCOUNT;
}

// Returns the 3 (or more) letter extension seen in the file browser (i.e. "3DS"):
const TCHAR* CExportESSM::Ext(int n)
{		
	return _T(ESSMEXP_FILEEXTENSION_ESSM);
}

// Returns a long description of the file type (i.e. "Targa 2.0 Image File"):
const TCHAR* CExportESSM::LongDesc()
{
	return _T(ESSMEXP_FILETYPE_ESSM_LONGDESCRIPTION);
}

// Returns a short description of the file type (i.e. "Targa"):
const TCHAR* CExportESSM::ShortDesc() 
{			
	return _T(ESSMEXP_FILETYPE_ESSM_SHORTDESCRIPTION);
}

// Returns the name of the plugin's author:
const TCHAR* CExportESSM::AuthorName()
{			
	return _T(ESSMEXP_PLUGIN_AUTHORNAME);
}

// Returns the plugin's copyright message:
const TCHAR* CExportESSM::CopyrightMessage() 
{	
	return _T(ESSMEXP_PLUGIN_COPYRIGHTMSG);
}

//Return Other message #1 if any:
const TCHAR* CExportESSM::OtherMessage1() 
{		
	return _T("");
}

//Return Other message #2 if any:
const TCHAR* CExportESSM::OtherMessage2() 
{		
	return _T("");
}

// Return version number * 100:
unsigned int CExportESSM::Version()
{				
	return ESSMEXP_PLUGIN_VERSION;
}

// Optional call to show an "About" box.
void CExportESSM::ShowAbout(HWND hWnd)
{			
	// nothing yet
}

// This function decides which 3DS "options" are supported. As yet, there
// is only one option. "SCENE_EXPORT_SELECTED". We'll get to that one in due time.
BOOL CExportESSM::SupportsOptions(int ext, DWORD options)
{
	return true;
}

