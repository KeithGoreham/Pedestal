////////////////////////////////////////////////////////////////////////
// ExportESSM.h - Implementation file for the CExportESSM function that
// will handle the export of a mesh file from 3DS Max.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Include Files:
#include "StdAfx.h"
#include "ExportESSM.h"
#include "uiFunctions.h"

// iGame Object Type Enumerations:
#define IGAME_UNKNOWN	0
#define IGAME_LIGHT		1	
#define IGAME_MESH		2
#define IGAME_SPLINE	3	
#define IGAME_CAMERA	4
#define IGAME_HELPER	5
#define IGAME_BONE		6
#define IGAME_IKCHAIN	7

// iGame Property Enumerations:
#define IGAME_UNKNOWN_PROP	0
#define IGAME_FLOAT_PROP	1
#define IGAME_INT_PROP		2
#define IGAME_POINT3_PROP	3
#define IGAME_STRING_PROP	4
#define IGAME_POINT4_PROP	5


//======================================================================
// Constructor and Destructor:
//======================================================================
CExportESSM::CExportESSM(void)
{
	// Initialize the iGame interface and conversion manager:
	p_iGame   = GetIGameInterface();
	p_iGameCM = GetConversionManager();
}

CExportESSM::~CExportESSM(void)
{
	OutputDebugString("Releasing iGame...\n");
	p_iGame->ReleaseIGame();
	OutputDebugString("iGame Released.\n");

	//OutputDebugString("Deleting Conversion Mgr...\n");
	//if (p_iGameCM != 0){delete p_iGameCM;}
	//OutputDebugString("Conversion Mgr deleted.\n");
}

//======================================================================
// Custom export function implementations:
//======================================================================
bool CExportESSM::SetupIGameOptions(bool exportSelected)
{
	// Set the iGame coordinate system to match the e1ngine's OpenGL orientation.
	p_iGameCM->SetCoordSystem(p_iGameCM->IGAME_OGL);

	// Decide whether we're exporting only the selected objects (true) or all objects (false):
	OutputDebugString("About to Initialize iGame...\n");
	if (exportSelected == true)
	{
		p_iGame->InitialiseIGame(true);			
	}
	else
	{
		p_iGame->InitialiseIGame(false);		
	}
	OutputDebugString("iGame Initialized.\n");

	// Tell iGame we want to process our objects at animation frame 0.
	OutputDebugString("Setting Static Frame...\n");
	p_iGame->SetStaticFrame(0);
	OutputDebugString("Static Frame Set.\n");

	return true;
}

//======================================================================
// Begin standard Max export plugin function implementations:
//======================================================================

// The actual export of the file is performed here:
int	CExportESSM::DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts, DWORD options)
{
	// Initialize  meshInfo structs to hold our model data.
	meshInfo exportMesh;		// Data to export.
	meshInfo tempMesh;			// Data for current model.
	
	// Setup our iGame options:
	SetupIGameOptions((options & SCENE_EXPORT_SELECTED));

	// Show the Export Options dialog box:
//	DialogBoxParam(g_hInstance, MAKEINTRESOURCE(dlgExportOptions), GetActiveWindow(), DlgProc_ExportOptions, (LPARAM)this);
	
	// Debug Buffer:
	char buffer[256];

	// Get the number of nodes in the scene:
	UINT nodeCount = p_iGame->GetTopLevelNodeCount();

	// Loop through each node in the scene:
	for (int index = 0; index < nodeCount; index++)
	{
		// Get the current node:
		IGameNode* curNode = p_iGame->GetTopLevelNode(index);

		// Get the node's type:
		IGameObject* curObject = curNode->GetIGameObject();
		IGameObject::ObjectTypes objType = curObject->GetIGameType();

		// Figure out what type this object is and, if it's a mesh, grab it's information and store it in the temp mesh:
		switch (objType)
		{
		case IGAME_MESH:
			{
				//--------------------------------------------------------------------------------
				// Initialization details for this mesh:
				//--------------------------------------------------------------------------------
				IGameMesh* curMesh = (IGameMesh*)curObject;

				curMesh->SetCreateOptimizedNormalList();		// Without this we can't access the mesh's normals.
				curMesh->InitializeData();						// Without this we can't access the mesh's faces.
				
				//--------------------------------------------------------------------------------
				// First we handle the verticies:
				//--------------------------------------------------------------------------------
				// Setup the tempMesh:
				tempMesh.numGVerts = curMesh->GetNumberOfVerts();
				tempMesh.gVerts    = new float3[tempMesh.numGVerts];

				// Copy the verticies:
				for (int idx = 0; idx < tempMesh.numGVerts; idx++)
				{
					Point3 curVert;

					curMesh->GetVertex(idx, curVert, false);

					tempMesh.gVerts[idx].x = curVert.x;
					tempMesh.gVerts[idx].y = curVert.y;
					tempMesh.gVerts[idx].z = curVert.z;
				}
				
				//--------------------------------------------------------------------------------
				// And the texture verticies:
				//--------------------------------------------------------------------------------
				// Setup the tempMesh:
				tempMesh.numTVerts = curMesh->GetNumberOfTexVerts();
				tempMesh.tVerts    = new float2[tempMesh.numTVerts];
				
				// Copy the tVerts:
				for (idx = 0; idx < tempMesh.numTVerts; idx++)
				{
					Point2 curTVert;

					curMesh->GetTexVertex(idx, curTVert);

					tempMesh.tVerts[idx].x = curTVert.x;
					tempMesh.tVerts[idx].y = curTVert.y;
				}

				//--------------------------------------------------------------------------------
				// And the normals:
				//--------------------------------------------------------------------------------
				// Setup the tempMesh:
				tempMesh.numNVerts = curMesh->GetNumberOfNormals();
				tempMesh.nVerts    = new float3[tempMesh.numNVerts];

				// Copy the normals:
				for (idx = 0; idx < tempMesh.numNVerts; idx++)
				{
					Point3 curNormal;

					curNormal = curMesh->GetNormal(idx);

					tempMesh.nVerts[idx].x = curNormal.x;
					tempMesh.nVerts[idx].y = curNormal.y;
					tempMesh.nVerts[idx].z = curNormal.z;
				}

				//--------------------------------------------------------------------------------
				// And the Vertex Colors:
				//--------------------------------------------------------------------------------
				// Setup the tempMesh:
				tempMesh.numCPVColors = curMesh->GetNumberOfColorVerts();
				tempMesh.CPVColors    = new rgbColor[tempMesh.numCPVColors];

				// Copy the colors:
				for (idx = 0; idx < tempMesh.numCPVColors; idx++)
				{
					Point3 curColor;

					curMesh->GetColorVertex(idx, curColor);

					tempMesh.CPVColors[idx].r = curColor.x;
					tempMesh.CPVColors[idx].g = curColor.y;
					tempMesh.CPVColors[idx].b = curColor.z;
				}

				//--------------------------------------------------------------------------------
				// Next comes the various face definitions:
				//--------------------------------------------------------------------------------
				// Setup the tempMesh:
				tempMesh.numGFaces = curMesh->GetNumberOfFaces();
				
				// Allocate memory for the tempMesh Arrays:
				tempMesh.gFaces   = new point3[tempMesh.numGFaces];
				tempMesh.tFaces	  = new point3[tempMesh.numGFaces];
				tempMesh.nFaces   = new point3[tempMesh.numGFaces];
				tempMesh.CPVFaces = new	point3[tempMesh.numGFaces];

				// Figure out how many visible edges there are in this object:
				for (idx = 0; idx < tempMesh.numGFaces; idx++)
				{
					// Get the current face:
					FaceEx* curFace = curMesh->GetFace(idx);

					// Check for visible edges:
					if (curFace->edgeVis[0] == 1){tempMesh.numGEdges += 1;}
					if (curFace->edgeVis[1] == 1){tempMesh.numGEdges += 1;}
					if (curFace->edgeVis[2] == 1){tempMesh.numGEdges += 1;}
				}

				// Allocate memory for the visible edge array:
				tempMesh.gEdges   = new point2[tempMesh.numGEdges];	

				// This variable will help us keep track of which visible edge we're on when we
				// actually get around to copying the data.
				int curEdge = 0;

				// Copy the face definitions:
				for (idx = 0; idx < tempMesh.numGFaces; idx++)
				{
					FaceEx* curFace = curMesh->GetFace(idx);

					// Geometry Faces
					tempMesh.gFaces[idx].x = curFace->vert[0];
					tempMesh.gFaces[idx].y = curFace->vert[1];
					tempMesh.gFaces[idx].z = curFace->vert[2];

					// Texture Faces
					tempMesh.tFaces[idx].x = curFace->texCoord[0];
					tempMesh.tFaces[idx].y = curFace->texCoord[1];
					tempMesh.tFaces[idx].z = curFace->texCoord[2];

					// Normal Faces
					tempMesh.nFaces[idx].x = curFace->norm[0];
					tempMesh.nFaces[idx].y = curFace->norm[1];
					tempMesh.nFaces[idx].z = curFace->norm[2];

					// Color Faces
					tempMesh.CPVFaces[idx].x = curFace->color[0];
					tempMesh.CPVFaces[idx].y = curFace->color[1];
					tempMesh.CPVFaces[idx].z = curFace->color[2];
	
					// Visible Edges
					if (curFace->edgeVis[0] == 1)
					{
						tempMesh.gEdges[curEdge].x = curFace->vert[0];
						tempMesh.gEdges[curEdge].y = curFace->vert[1];

						curEdge += 1;
					};
					if (curFace->edgeVis[1] == 1)
					{ 
						tempMesh.gEdges[curEdge].x = curFace->vert[1];
						tempMesh.gEdges[curEdge].y = curFace->vert[2];

						curEdge += 1;
					};
					if (curFace->edgeVis[2] == 1)
					{ 
						tempMesh.gEdges[curEdge].x = curFace->vert[2];
						tempMesh.gEdges[curEdge].y = curFace->vert[0];

						curEdge += 1;
					};
				}

				//--------------------------------------------------------------------------------
				// And now for the materials:
				//--------------------------------------------------------------------------------
				// First, we figure out how many different materials are used in this mesh.
				Tab<int> usedMatIDs = curMesh->GetActiveMatIDs();
				
				char buffer[256];
				sprintf(buffer, "There are %d used material IDs\n", usedMatIDs.Count());
				OutputDebugString(buffer);



				break;
			}
		default:
			{
				OutputDebugString("     This object type is not supported.\n");
				break;
			}
		}
	}

	// Now for the materials:
	int materialCount = p_iGame->GetRootMaterialCount();

	sprintf(buffer, "There are %d materials in the scene.\n", materialCount);
	OutputDebugString(buffer);

	for (index = 0; index < materialCount; index++)
	{
		IGameMaterial* curMat = p_iGame->GetRootMaterial(index);

		sprintf(buffer, "Material %d's name is: %s\n", index, curMat->GetMaterialName());
		OutputDebugString(buffer);

		
		if ((!curMat->IsMultiType()) && (!curMat->IsSubObjType()))
		{
			OutputDebugString("     This is a standard material.\n");
		}		
		else if (curMat->IsSubObjType())
		{
			OutputDebugString("     This is a multi/sub-object material.\n");

			int numSubMaterials = curMat->GetSubMaterialCount();
			sprintf(buffer, "          It has %d sub-materials.\n", numSubMaterials);
			OutputDebugString(buffer);

			for (int index2 = 0; index2 < numSubMaterials; index2++)
			{
				IGameMaterial* curSubMat = curMat->GetSubMaterial(index2);
				sprintf(buffer, "               Sub-Material %d's name is: %s\n", index2, curSubMat->GetMaterialName());
				OutputDebugString(buffer);

				Mtl* curMaxMat = curSubMat->GetMaxMaterial();

				// Ambient Color
				Color ambientColor = curMaxMat->GetAmbient();
				sprintf(buffer, "                    Ambient Color is RGB(%f, %f, %f)\n", ambientColor.r, ambientColor.g, ambientColor.b);
				OutputDebugString(buffer);

				// Diffuse Color
				Color diffuseColor = curMaxMat->GetDiffuse();
				sprintf(buffer, "                    Diffuse Color is RGB(%f, %f, %f)\n", diffuseColor.r, diffuseColor.g, diffuseColor.b);
				OutputDebugString(buffer);

				// Specular Color
				Color specularColor = curMaxMat->GetSpecular();
				sprintf(buffer, "                    Specular Color is RGB(%f, %f, %f)\n", specularColor.r, specularColor.g, specularColor.b);
				OutputDebugString(buffer);

				// Shininess
				float shininess = curMaxMat->GetShininess();
				sprintf(buffer, "                    Shininess is %f\n", shininess);
				OutputDebugString(buffer);

				// Self Illuminated Color
				Color selfIllumColor = curMaxMat->GetSelfIllumColor();
				sprintf(buffer, "                    Self Illuminated Color is RGB(%f, %f, %f)\n", selfIllumColor.r, selfIllumColor.g, selfIllumColor.b);
				OutputDebugString(buffer);

				// Number of Texture Maps
				int numTexMaps = curSubMat->GetNumberOfTextureMaps();

				sprintf(buffer, "                    This material uses %d texture maps.\n", numTexMaps);
				OutputDebugString(buffer);

				for (int index3 = 0; index3 < numTexMaps; index3++)
				{
					IGameTextureMap* curMap = curSubMat->GetIGameTextureMap(index3);
					
					sprintf(buffer, "                         Map %d's name is %s\n", index3, curMap->GetTextureName());
					OutputDebugString(buffer);

					sprintf(buffer, "                         Map %d's filename is %s\n", index3, curMap->GetBitmapFileName());
					OutputDebugString(buffer);
					
					int mapType = curMap->GetStdMapSlot();
					
					switch (mapType)
					{
					case ID_AM:
						{
							OutputDebugString("                         This is an Ambient Map.\n");
							break;
						}
					case ID_DI:
						{
							OutputDebugString("                         This is a Diffuse Map.\n");
							break;
						}
					case ID_SP:
						{
							OutputDebugString("                         This is a Specular Map.\n");
							break;
						}
					case ID_SH:
						{
							OutputDebugString("                         This is a Shininess Map.\n");
							break;
						}
					case ID_SS:
						{
							OutputDebugString("                         This is a Shininess Strength Map.\n");
							break;
						}
					case ID_SI:
						{
							OutputDebugString("                         This is a Self Illumination Map.\n");
							break;
						}
					case ID_OP:
						{
							OutputDebugString("                         This is an Opacity Map.\n");
							break;
						}
					case ID_BU:
						{
							OutputDebugString("                         This is a Bump Map.\n");
							break;
						}
					case ID_RL:
						{
							OutputDebugString("                         This is a Reflection Map.\n");
							break;
						}
					case ID_RR:
						{
							OutputDebugString("                         This is a Refraction Map.\n");
							break;
						}
					case ID_DP:
						{
							OutputDebugString("                         This is a Displacement Map.\n");
							break;
						}
					default:
						{
							OutputDebugString("                         This map type is not supported.\n");
							break;
						}
					}
					

					Bitmap*		curBitmap;				// Pointer to a Bitmap Object.
					BitmapInfo	curBitmapInfo;			// Object to hold our Bitmap Information.

					// Feed the filename to the info object.
					curBitmapInfo.SetName(curMap->GetBitmapFileName());

					// And read in the file.
					BMMRES status;
					curBitmap = TheManager->Load(&curBitmapInfo, &status);

					// Show the bitmap in Max.
					curBitmap->Display();	// yay! It works!

					if (curBitmap->HasAlpha() != 0)
					{
						OutputDebugString("                         This map has an alpha channel.\n");
					}
					
					sprintf(buffer, "                         This map is %d x %d pixels in size.\n", curBitmap->Width(), curBitmap->Height());
					OutputDebugString(buffer);

			//		curBitmap


					// We're done, close the bitmap.
					curBitmap->Close(&curBitmapInfo);
				}

				//		curSubMat->GetIGameTextureMap();
			}
		}
		else
		{
			OutputDebugString("     This material type is not supported.\n");
		}
		
		
	}

	//OutputDebugString("Releasing iGame...\n");
	//p_iGame->ReleaseIGame();
	//OutputDebugString("iGame Released.\n");

	// return TRUE If the file is exported properly
	return TRUE;
}

// Returns the number of file name extensions supported by this plugin:
int CExportESSM::ExtCount()
{
	return ESSMEXP_FILEEXTENSIONCOUNT;
}

// Returns the 3 (or more) letter extension seen in the file browser (i.e. "3DS"):
const TCHAR* CExportESSM::Ext(int n)
{		
	return _T(ESSMEXP_FILEEXTENSION_ESSM);
}

// Returns a long description of the file type (i.e. "Targa 2.0 Image File"):
const TCHAR* CExportESSM::LongDesc()
{
	return _T(ESSMEXP_FILETYPE_ESSM_LONGDESCRIPTION);
}

// Returns a short description of the file type (i.e. "Targa"):
const TCHAR* CExportESSM::ShortDesc() 
{			
	return _T(ESSMEXP_FILETYPE_ESSM_SHORTDESCRIPTION);
}

// Returns the name of the plugin's author:
const TCHAR* CExportESSM::AuthorName()
{			
	return _T(ESSMEXP_PLUGIN_AUTHORNAME);
}

// Returns the plugin's copyright message:
const TCHAR* CExportESSM::CopyrightMessage() 
{	
	return _T(ESSMEXP_PLUGIN_COPYRIGHTMSG);
}

//Return Other message #1 if any:
const TCHAR* CExportESSM::OtherMessage1() 
{		
	return _T("");
}

//Return Other message #2 if any:
const TCHAR* CExportESSM::OtherMessage2() 
{		
	return _T("");
}

// Return version number * 100:
unsigned int CExportESSM::Version()
{				
	return ESSMEXP_PLUGIN_VERSION;
}

// Optional call to show an "About" box.
void CExportESSM::ShowAbout(HWND hWnd)
{			
	// nothing yet
}

// This function decides which 3DS "options" are supported. As yet, there
// is only one option. "SCENE_EXPORT_SELECTED". We'll get to that one in due time.
BOOL CExportESSM::SupportsOptions(int ext, DWORD options)
{
	return true;
}

