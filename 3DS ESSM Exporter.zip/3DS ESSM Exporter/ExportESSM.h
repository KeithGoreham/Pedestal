////////////////////////////////////////////////////////////////////////
// ExportESSM.h - Interface file for the CExportESSM function that will
// handle the export of a mesh file from 3DS Max.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Include files:
#include "stdafx.h"
#include "meshInfoStructs.h"



// Preprocessor Constants:
#define ESSMEXP_FILEEXTENSIONCOUNT				1
#define ESSMEXP_FILEEXTENSION_ESSM				"ESSM"
#define ESSMEXP_FILETYPE_ESSM_LONGDESCRIPTION	"e1ngine Single Static Mesh"
#define ESSMEXP_FILETYPE_ESSM_SHORTDESCRIPTION	"e1ngine Mesh"
#define ESSMEXP_PLUGIN_AUTHORNAME				"Keith M. Goreham"
#define ESSMEXP_PLUGIN_COPYRIGHTMSG				"�2006 by Keith Goreham - www.goreham.com"
#define ESSMEXP_PLUGIN_VERSION					100

// External variables and global pointers:
extern IGameScene* g_iGame;


using namespace std;

//----------------------------------------------------------------------
// CExportESSM Class - This class takes care of all the work of 
// communicating with and exporting a file from 3DS Max.
//----------------------------------------------------------------------
class CExportESSM :public SceneExport
{
public:

	// iGame related member pointers:
	IGameScene*				p_iGame;			// Pointer to Max's iGame data conversion interface.
	IGameConversionManager* p_iGameCM;			// Pointer to the iGame conversion manager for formating scene data.
		
	//Constructor and Destructor
	CExportESSM();
	~CExportESSM();
	
	// Custom member functions:
	bool SetupIGameOptions(bool exportSelected);

	// Standard Max plugin member functions:
	int				ExtCount();					// Number of extensions supported
	const TCHAR *	Ext(int n);					// Extension #n (i.e. "3DS")
	const TCHAR *	LongDesc();					// Long ASCII description (i.e. "Autodesk 3D Studio File")
	const TCHAR *	ShortDesc();				// Short ASCII description (i.e. "3D Studio")
	const TCHAR *	AuthorName();				// ASCII Author name
	const TCHAR *	CopyrightMessage();			// ASCII Copyright message
	const TCHAR *	OtherMessage1();			// Other message #1
	const TCHAR *	OtherMessage2();			// Other message #2
	unsigned int	Version();					// Version number * 100 (i.e. v3.01 = 301)
	void			ShowAbout(HWND hWnd);		// Show DLL's "About..." box

	BOOL			SupportsOptions(int ext, DWORD options);
	int				DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts=FALSE, DWORD options=0);
};

