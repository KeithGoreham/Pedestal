/**********************************************************************
 *<
	FILE: hitdata.h
				  
	DESCRIPTION:  Defines the basic Hit Data class

	CREATED BY: Dan Silva

	HISTORY: created 9 September 1994

 *>	Copyright (c) 1994, All Rights Reserved.
 **********************************************************************/

#ifndef __HITDATA__

#define __HITDATA__

class HitData {
	public:
		virtual ~HitData() {}
	}; 

#endif __HITDATA__
