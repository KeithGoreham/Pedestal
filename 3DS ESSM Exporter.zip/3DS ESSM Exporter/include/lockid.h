

#ifndef __LOCKID_H__
#define __LOCKID_H__

extern unsigned int CoreExport HardwareLockID();
extern bool CoreExport IsTrialLicense();
extern bool CoreExport IsNetworkLicense();
extern bool CoreExport IsEmergencyLicense();


#endif
