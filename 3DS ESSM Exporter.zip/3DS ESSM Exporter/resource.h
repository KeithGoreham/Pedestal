//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 3DS ESSM Exporter.rc
//
#define dlgExportOptions                5
#define dlgExportWarnings               106
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_CHECK3                      1003
#define IDC_CHECK4                      1004
#define IDC_CHECK5                      1005
#define IDC_CHECK6                      1006
#define IDC_EDIT1                       1010
#define IDC_BUTTON1                     1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
