// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

// Preprocessor directives:
#pragma once

// Windows related settings:
#define WIN32_LEAN_AND_MEAN						// Exclude rarely-used stuff from Windows headers
#define WIN32_EXTRA_LEAN						// Leave out other Windows crap we don't need.

// Standard C++ non-system include files:
#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <fstream>

// Windows API headers:
#include <windows.h>
#include <Commdlg.h>							// Common Dialog Boxes.
#include <commctrl.h>							// Windows Common Controls.

// 3DSMax plugin headers.
#include "Max.h"
#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"
#include "impexp.h"
#include "bmmlib.h"
#include "bitmap.h"
#include "mesh.h"
#include "imtl.h"
#include "max_mem.h"	
#include "tab.h"
// Memory Wrapper to address VS7.0/7.1 plugin compatabilty.
//#include ".\include\max_memDirect.h"

// Not sure what these headers do.
#include "msxml2.h"
#include "decomp.h"

// Headers for the iGame Interface:
#include "IConversionManager.h"
#include "IGame.h"
#include "IGameControl.h"
#include "IGameError.h"
#include "IGameExport.h"
#include "IGameFX.h"
#include "IGameMaterial.h"
#include "IGameModifier.h"
#include "IGameObject.h"
#include "IGameProperty.h"
#include "IGameRenderedSurface.h"
#include "IGameStd.h"
#include "IGameType.h"




// iGame related defines:
#ifndef __IGAMEEXPORTER__H
#define __IGAMEEXPORTER__H
#endif


