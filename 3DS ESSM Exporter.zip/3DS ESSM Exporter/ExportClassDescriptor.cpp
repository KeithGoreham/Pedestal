////////////////////////////////////////////////////////////////////////
// ExportClassDescriptor.h - Implementation file for the class which 
// will tell 3DS Max all about our plugin.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Include Files:
#include "StdAfx.h"
#include "exportclassdescriptor.h"
#include "ExportESSM.h"

// Externally defined variables and objects:
extern CExportClassDescriptor	g_ExportDescription;

//----------------------------------------------------------------------
// Constructor and Destructor:
//----------------------------------------------------------------------
CExportClassDescriptor::CExportClassDescriptor(void)
{
}

CExportClassDescriptor::~CExportClassDescriptor(void)
{
}

//----------------------------------------------------------------------
// Member Function Implementations:
//----------------------------------------------------------------------

// Returns whether the class is public.
int CExportClassDescriptor::IsPublic()					
{
	return TRUE;
}							

// Creates an instance of the class.
void* CExportClassDescriptor::Create(BOOL loading = FALSE)
{
	return new CExportESSM();
}			

// Not sure, something to do with the dialog?
const TCHAR* CExportClassDescriptor::ClassName()
{
	return	_T("ESSMEXP_EXPORT_CLASS_DESCRIPTOR");
}

// Returns the parent class ID as defined in plugapi.h
SClass_ID CExportClassDescriptor::SuperClassID()
{
	return	SCENE_EXPORT_CLASS_ID;
}			

// Returns the unique class ID of our plugin.
Class_ID CExportClassDescriptor::ClassID()
{
	return ESSMEXP_CLASS_ID;
}		

// Not sure, something internal to Max I'd guess.
const TCHAR* CExportClassDescriptor::Category()
{
	return _T(ESSMEXP_CATEGORY);
}		

// returns fixed parsable name (scripter-visible name)
const TCHAR* CExportClassDescriptor::InternalName()
{
	return _T(ESSMEXP_INTERNALNAME);
}	

// returns owning module handle
HINSTANCE CExportClassDescriptor::HInstance()
{
	return g_hInstance;
}						

//----------------------------------------------------------------------
// Non-Member Functions:
//----------------------------------------------------------------------

// This function returns info about our plugin to Max.
ClassDesc2* GetExportDescription() 
{
	return &g_ExportDescription;
}