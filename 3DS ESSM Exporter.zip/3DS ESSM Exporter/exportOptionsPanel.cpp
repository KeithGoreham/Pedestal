//////////////////////////////////////////////////////////////
// Implementation file for the Export Dialog window.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Includes:
#include "stdafx.h"
#include "exportESSM.h"
#include "uiFunctions.h"

//======================================================================
// DlgProc_ExportOptions() - This is our export options window callback 
// function for handling all message passed to the window.
//======================================================================
BOOL CALLBACK DlgProc_ExportOptions(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//	static CExportESSM* p_exporter;

	switch (message)
	{
	case WM_INITDIALOG:
		{
	//		p_exporter = (CExportESSM*) lParam;
			CenterWindow(hWnd, GetParent(hWnd));
			return true;
		}
	case WM_DESTROY:
		{
			return false;
		}
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDOK:
				{
					EndDialog(hWnd, 1);
					return true;
				}
			case IDCANCEL:
				{
					EndDialog(hWnd, 0);
					return true;
				}
			}
		}
	}
	return false;
}