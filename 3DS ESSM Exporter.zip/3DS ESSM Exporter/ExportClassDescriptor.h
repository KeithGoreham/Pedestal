////////////////////////////////////////////////////////////////////////
// ExportClassDescriptor.h - Interface file for the class which will
// tell 3DS Max all about our plugin.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Include Files:
#include "stdafx.h"
#include ".\include\iparamb2.h"
#include "ExportESSM.h"

// Preprocessor constants for this plugin:
#define ESSMEXP_CLASS_ID				Class_ID(0x60e57db6, 0x6c025fd2)		// Our unique plugin ID:
#define ESSMEXP_NUM_PLUGIN_CLASSES		1
#define ESSMEXP_LIB_DESCRIPTION			"ESSM Exporter Beta"
#define ESSMEXP_EXPORT_CLASS_DESCRIPTOR	"ESSM Exporter"
#define ESSMEXP_CATEGORY				"Goreham"
#define ESSMEXP_INTERNALNAME			"ESSMEXPORT"

// External Globals:
extern HINSTANCE				g_hInstance;
extern HWND						g_hWnd;


//----------------------------------------------------------------------
// The Export Descriptor Class:
//----------------------------------------------------------------------
class CExportClassDescriptor : public ClassDesc2
{
public:

	// Constructors:
	CExportClassDescriptor(void);
	~CExportClassDescriptor(void);

	// Member function declarations:
	int 			IsPublic();							// Returns whether the class is public.
	void *			Create(BOOL loading);				// Creates an instance of the class.
	const TCHAR *	ClassName();						// Not sure, something to do with the dialog?
	SClass_ID		SuperClassID();						// Returns the parent class ID as defined in plugapi.h
	Class_ID		ClassID();							// Returns the unique class ID of our plugin.
	const TCHAR* 	Category();							// Not sure, something internal to Max I'd guess.
	const TCHAR*	InternalName();						// returns fixed parsable name (scripter-visible name)
	HINSTANCE		HInstance();						// returns owning module handle

};

//----------------------------------------------------------------------
// Non-Member Functions:
//----------------------------------------------------------------------

// This function returns info about our plugin to Max.
ClassDesc2* GetExportDescription(void);
