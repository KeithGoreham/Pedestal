////////////////////////////////////////////////////////////////////////
// ExportESSM.h - Implementation file for the CExportESSM function that
// will handle the export of a mesh file from 3DS Max.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Include Files:
#include "StdAfx.h"
#include "ExportESSM.h"
#include "uiFunctions.h"

// iGame Object Type Enumerations:
#define IGAME_UNKNOWN	0
#define IGAME_LIGHT		1	
#define IGAME_MESH		2
#define IGAME_SPLINE	3	
#define IGAME_CAMERA	4
#define IGAME_HELPER	5
#define IGAME_BONE		6
#define IGAME_IKCHAIN	7

// iGame Property Enumerations:
#define IGAME_UNKNOWN_PROP	0
#define IGAME_FLOAT_PROP	1
#define IGAME_INT_PROP		2
#define IGAME_POINT3_PROP	3
#define IGAME_STRING_PROP	4
#define IGAME_POINT4_PROP	5


//======================================================================
// Constructor and Destructor:
//======================================================================
CExportESSM::CExportESSM(void)
{
	// Initialize the iGame interface and conversion manager:
	p_iGame   = GetIGameInterface();
	p_iGameCM = GetConversionManager();
}

CExportESSM::~CExportESSM(void)
{
	OutputDebugString("Releasing iGame...\n");
	p_iGame->ReleaseIGame();
	OutputDebugString("iGame Released.\n");

	//OutputDebugString("Deleting Conversion Mgr...\n");
	//if (p_iGameCM != 0){delete p_iGameCM;}
	//OutputDebugString("Conversion Mgr deleted.\n");
}

//======================================================================
// Custom export function implementations:
//======================================================================
bool CExportESSM::SetupIGameOptions(bool exportSelected)
{
	// Set the iGame coordinate system to match the e1ngine's OpenGL orientation.
	p_iGameCM->SetCoordSystem(p_iGameCM->IGAME_OGL);

	// Decide whether we're exporting only the selected objects (true) or all objects (false):
	OutputDebugString("About to Initialize iGame...\n");
	if (exportSelected == true)
	{
		p_iGame->InitialiseIGame(true);			
	}
	else
	{
		p_iGame->InitialiseIGame(false);		
	}
	OutputDebugString("iGame Initialized.\n");

	// Tell iGame we want to process our objects at animation frame 0.
	OutputDebugString("Setting Static Frame...\n");
	p_iGame->SetStaticFrame(0);
	OutputDebugString("Static Frame Set.\n");

	return true;
}

//======================================================================
// Begin standard Max export plugin function implementations:
//======================================================================

// The actual export of the file is performed here:
int	CExportESSM::DoExport(const TCHAR *someName,ExpInterface *someExportInterface,Interface *someInterface, BOOL suppressPrompts, DWORD options)
{
	// Buffer for debug text
	char buffer[256];

	// Setup our iGame options:
	SetupIGameOptions((options & SCENE_EXPORT_SELECTED));

	//----------------------------------------------------------------------
	// Begin Geometry Export
	//----------------------------------------------------------------------

	OutputDebugString("Beginning Geometry Export\n");

	// Get the number of nodes in the scene:
	UINT nodeCount = p_iGame->GetTopLevelNodeCount();

	// Pointer array and counter to store the meshes found in the scene:
	UINT		numSceneMeshes		  = 0;
	IGameMesh**	sceneMeshes           = new IGameMesh*[nodeCount];
	int*        sceneMeshRootMatIndex = new int[nodeCount];
	int*		sceneMeshEdgeCounts   = new int[nodeCount];

	int*		sceneMeshGVertOffsets = new int[nodeCount];
	int*		sceneMeshTVertOffsets = new int[nodeCount];
	int*		sceneMeshNVertOffsets = new int[nodeCount];
	int*		sceneMeshCVertOffsets = new int[nodeCount];
	int*		sceneMeshEdgeOffsets  = new int[nodeCount];

	for (UINT i = 0; i < nodeCount ; i++)
	{
		// Get the current node:
		IGameNode* curNode = p_iGame->GetTopLevelNode(i);

		// Use the node to grab the current object and retrieve it's type:
		IGameObject* curObject = curNode->GetIGameObject();
		IGameObject::ObjectTypes objType = curObject->GetIGameType();

		// If this node is a mesh, we'll iterate our meshNodeCount variable.
		if (objType == IGAME_MESH)
		{
		//	IGameMesh* curMesh = (IGameMesh*)curObject;

		//	curMesh->SetCreateOptimizedNormalList();		// Without this we can't access the mesh's normals.
		//	curMesh->InitializeData();						// Without this we can't access the mesh's faces.
				


			sceneMeshes[i] = (IGameMesh*)curObject;				// Grab the mesh

			sceneMeshes[i]->SetCreateOptimizedNormalList();		// Without this we can't access the mesh's normals.
			sceneMeshes[i]->InitializeData();					// Without this we can't access the mesh's faces.

			sceneMeshRootMatIndex[i] = curNode->GetMaterialIndex();			// Grab the root material index
			numSceneMeshes			+= 1;									// Iterate the count of meshes.
			sceneMeshEdgeCounts[i]   = 0;									// Zero out the edge count.

			// Here we'll count up our visible edges.
			UINT numFaces = sceneMeshes[i]->GetNumberOfFaces();

			for (UINT j = 0; j < numFaces; j++)
			{
				FaceEx* curFace = sceneMeshes[i]->GetFace(j);

				if (curFace->edgeVis[0] == 1){sceneMeshEdgeCounts[i] += 1;}
				if (curFace->edgeVis[1] == 1){sceneMeshEdgeCounts[i] += 1;}
				if (curFace->edgeVis[2] == 1){sceneMeshEdgeCounts[i] += 1;}
			}
		}
	}

	// Determine our various geometry index offsets for all the meshes in the scene.
	int gVertTotal = 0;
	int tVertTotal = 0;
	int nVertTotal = 0;
	int cVertTotal = 0;
	int edgeTotal  = 0;

	for (i = 0; i < numSceneMeshes; i++)
	{
		sceneMeshGVertOffsets[i] = gVertTotal;
		sceneMeshTVertOffsets[i] = tVertTotal;
		sceneMeshNVertOffsets[i] = nVertTotal;
		sceneMeshCVertOffsets[i] = cVertTotal;
		sceneMeshEdgeOffsets[i]  = edgeTotal;

		gVertTotal += sceneMeshes[i]->GetNumberOfVerts();
		tVertTotal += sceneMeshes[i]->GetNumberOfTexVerts();
		nVertTotal += sceneMeshes[i]->GetNumberOfNormals();
		cVertTotal += sceneMeshes[i]->GetNumberOfColorVerts();	
		edgeTotal  += sceneMeshEdgeCounts[i];
	}

	// Declare our export mesh:
	meshInfo exportMesh;

	// Grab the counts for all the mesh data we need to allocate memory for.
	for (i = 0; i < numSceneMeshes; i++)
	{
		exportMesh.numGVerts    += sceneMeshes[i]->GetNumberOfVerts();
		exportMesh.numTVerts    += sceneMeshes[i]->GetNumberOfTexVerts();
		exportMesh.numNVerts    += sceneMeshes[i]->GetNumberOfNormals();
		exportMesh.numCPVColors += sceneMeshes[i]->GetNumberOfColorVerts();
		exportMesh.numGFaces    += sceneMeshes[i]->GetNumberOfFaces();
		exportMesh.numGEdges    += sceneMeshEdgeCounts[i];

		sprintf(buffer, "Just counted %d faces in this object\n", exportMesh.numGFaces); OutputDebugString(buffer);
	}

	// Allocate memory for the export mesh components:
	exportMesh.gVerts    = new float3[exportMesh.numGVerts];
	exportMesh.tVerts    = new float2[exportMesh.numTVerts];
	exportMesh.nVerts    = new float3[exportMesh.numNVerts];
	exportMesh.CPVColors = new rgbColor[exportMesh.numCPVColors];
	exportMesh.gFaces    = new point3[exportMesh.numGFaces];
	exportMesh.gEdges    = new point2[exportMesh.numGEdges];
	exportMesh.tFaces    = new point3[exportMesh.numGFaces];
	exportMesh.nFaces    = new point3[exportMesh.numGFaces];
	exportMesh.CPVFaces  = new point3[exportMesh.numGFaces];

	//----------------------------------------------------------------------
	// Copy the Vertex Data:
	//----------------------------------------------------------------------

	OutputDebugString("Copying the Vertex Data\n");

	// Offsets for vert indexes.
	UINT gVertListOffset = 0;
	UINT tVertListOffset = 0;
	UINT nVertListOffset = 0;
	UINT cVertListOffset = 0;

	for (i = 0; i < numSceneMeshes; i++)
	{
		// Grab the number of each vert type for this mesh:
		UINT numGVerts = sceneMeshes[i]->GetNumberOfVerts();
		UINT numTVerts = sceneMeshes[i]->GetNumberOfTexVerts();
		UINT numNVerts = sceneMeshes[i]->GetNumberOfNormals();
		UINT numCVerts = sceneMeshes[i]->GetNumberOfColorVerts();

		// Geometry Verts:
		for (UINT j = 0; j < numGVerts; j++)
		{
			Point3 curGVert;

            sceneMeshes[i]->GetVertex(j, curGVert, false);
			
			exportMesh.gVerts[j + gVertListOffset].x = curGVert.x;
			exportMesh.gVerts[j + gVertListOffset].y = curGVert.y;
			exportMesh.gVerts[j + gVertListOffset].z = curGVert.z;
		}

		// Texture Verts:
		for (UINT j = 0; j < numTVerts; j++)
		{
			Point2 curTVert;

			sceneMeshes[i]->GetTexVertex(j, curTVert);
			
			exportMesh.tVerts[j + tVertListOffset].x = curTVert.x;
			exportMesh.tVerts[j + tVertListOffset].y = curTVert.y;
		}

		// Normals:
		for (UINT j = 0; j < numNVerts; j++)
		{
			Point3 curNVert;

            curNVert = sceneMeshes[i]->GetNormal(j);
			
			exportMesh.nVerts[j + nVertListOffset].x = curNVert.x;
			exportMesh.nVerts[j + nVertListOffset].y = curNVert.y;
			exportMesh.nVerts[j + nVertListOffset].z = curNVert.z;
		}

		// Vertex Colors:
		for (UINT j = 0; j < numCVerts; j++)
		{
			Point3 curCVert;

            sceneMeshes[i]->GetColorVertex(j, curCVert);
			
			exportMesh.CPVColors[j + cVertListOffset].r = curCVert.x;
			exportMesh.CPVColors[j + cVertListOffset].g = curCVert.y;
			exportMesh.CPVColors[j + cVertListOffset].b = curCVert.z;
		}

		// Increment the list offsets:
		gVertListOffset += numGVerts;
		tVertListOffset += numTVerts;
		nVertListOffset += numNVerts;
		cVertListOffset += numCVerts;
	}

	//----------------------------------------------------------------------
	//	Copy the face data sorted by material
	//----------------------------------------------------------------------
	// Ok first off, we need to know how many materials we're dealing with. We want to allocate  
	// one materialInfo struct for each standard material. And one for each sub-material of a
	// multi-sub material. This will allow us to store the mesh faces on a per-material basis.

	OutputDebugString("Copying the face data sorted by material\n");

	int numSceneRootMaterials = p_iGame->GetRootMaterialCount();

	// Now we need to count up the sub-materials, if any. And figure out how many different
	// total materials we have.
	int numSceneMaterials = 0;

	for (i = 0; i < numSceneRootMaterials; i++)
	{
		IGameMaterial* curRootMat = p_iGame->GetRootMaterial(i);

		// Test for Material Type:
		if ((!curRootMat->IsMultiType()) && (!curRootMat->IsSubObjType()))	// Standard Material
		{
			numSceneMaterials += 1;
		}
		else if (curRootMat->IsSubObjType())									// Multi/Sub-Object Material
		{
			int subMatCount = curRootMat->GetSubMaterialCount();

			// Step through each sub-material.
			for (UINT j = 0; j < subMatCount; j++)
			{
				IGameMaterial* curSubMat = curRootMat->GetSubMaterial(j);
				
				// Check to make sure this is a standard material:
				if ((!curSubMat->IsMultiType()) && (!curSubMat->IsSubObjType()))
				{
					numSceneMaterials += 1;
				}
			}
		}
	}

	// Now that we have our complete material count, we can allocate the material arrays:

	// Array of pointers to the original IGameMaterials.
	IGameMaterial** sceneRootMaterials = new IGameMaterial*[numSceneMaterials];			// All top-level materials
	IGameMaterial** sceneMaterials     = new IGameMaterial*[numSceneMaterials];			// All materials, base and sub


	// Array of structs to store export-ready material data.
	materialInfo*   exportMaterials   = new materialInfo[numSceneMaterials];			
	
	//----------------------------------------------------------------------
	//	Material and Geometry interrogation
	//----------------------------------------------------------------------
	// And now we will go through all the scene materials and store pointers to them.

	OutputDebugString("Beginning Material and Geometry Interrogation\n");

	int curMatIndex = 0;

	for (i = 0; i < numSceneRootMaterials; i++)
	{
		IGameMaterial* curRootMat = p_iGame->GetRootMaterial(i);

		// Test for material type:
		if ((!curRootMat->IsMultiType()) && (!curRootMat->IsSubObjType()))		// Standard Material
		{
			// Store pointers to this material:
			sceneRootMaterials[curMatIndex] = p_iGame->GetRootMaterial(i);
			sceneMaterials[curMatIndex]     = p_iGame->GetRootMaterial(i);

			curMatIndex += 1;
		}
		else if (curRootMat->IsSubObjType())									// Multi/Sub-Object Material
		{
			// Store a pointer to this material:
			sceneRootMaterials[curMatIndex] = p_iGame->GetRootMaterial(i);

			int subMatCount = curRootMat->GetSubMaterialCount();

			// Step through each sub-material.
			for (UINT j = 0; j < subMatCount; j++)
			{
				IGameMaterial* curSubMat = curRootMat->GetSubMaterial(j);
				
				// Check to make sure this is a standard material:
				if ((!curSubMat->IsMultiType()) && (!curSubMat->IsSubObjType()))
				{
					// Store a pointer to this material:
					sceneMaterials[curMatIndex] = curRootMat->GetSubMaterial(j);

					curMatIndex += 1;
				}
			}
		}
	}
	
	OutputDebugString("Populating Material Structs\n");

	// Now we're ready to populate our material structs.
	for (i = 0; i < numSceneMaterials; i++)			// Loop through our stored material pointers.
	{
		// First we grab a pointer to the old-style Max material.
		Mtl* curMaxMat = sceneMaterials[i]->GetMaxMaterial();

		// Next we extract from that material all the info we need.
		Color ambient    = curMaxMat->GetAmbient();
		Color diffuse    = curMaxMat->GetDiffuse();
		Color specular   = curMaxMat->GetSpecular();
		float shininess  = curMaxMat->GetShininess();
		Color emissive   = curMaxMat->GetSelfIllumColor();

		// Save the ambient color:
		exportMaterials[i].ambient.r = ambient.r;
		exportMaterials[i].ambient.g = ambient.g;
		exportMaterials[i].ambient.b = ambient.b;
	
		// Save the diffuse color:
		exportMaterials[i].diffuse.r = diffuse.r;
		exportMaterials[i].diffuse.g = diffuse.g;
		exportMaterials[i].diffuse.b = diffuse.b;

		// Save the specular color:
		exportMaterials[i].specular.r = specular.r;
		exportMaterials[i].specular.g = specular.g;
		exportMaterials[i].specular.b = specular.b;

		// Save the shininess exponent;
		exportMaterials[i].shininess = (int)(shininess / 1.0 * 255.0f);

		// Save the emissive (self-illum) color:
		if (curMaxMat->GetSelfIllumColorOn())		// A color may be defined even if
													// self-illumination is off.
		{
			exportMaterials[i].emissive.r = emissive.r;
			exportMaterials[i].emissive.g = emissive.g;
			exportMaterials[i].emissive.b = emissive.b;
		}
		else
		{
			exportMaterials[i].emissive.r = 0.0f;
			exportMaterials[i].emissive.g = 0.0f;
			exportMaterials[i].emissive.b = 0.0f;
		}

		//----------------------------------------------------------------------
		// Now it's time to copy out the diffusemap data for each material.
		//----------------------------------------------------------------------
		// Loop through all the texture maps for this material.
		UINT numTexMaps = sceneMaterials[i]->GetNumberOfTextureMaps();

		for (UINT j = 0; j < numTexMaps; j++)
		{
			// Grab the current map.
			IGameTextureMap* curMap = sceneMaterials[i]->GetIGameTextureMap(j);

			// If this is a diffuseMap...
			if (curMap->GetStdMapSlot() == ID_DI)
			{
				Bitmap*	   diffuseBitmap;			// Pointer to a 3DSMax Bitmap Object.
				BitmapInfo diffuseBitmapInfo;		// Object to hold our bitmap's information.

				// Feed the filename to the info object.
				diffuseBitmapInfo.SetName(curMap->GetBitmapFileName());

				// Read in the file.
				BMMRES status;
				diffuseBitmap = TheManager->Load(&diffuseBitmapInfo, &status);
				
				// Number of map channels:
				if (diffuseBitmap->HasAlpha()){exportMaterials[i].numDiffuseMapChannels = 4;}
				else						  {exportMaterials[i].numDiffuseMapChannels = 3;}
				
				// Bitmap Dimensions:
				exportMaterials[i].diffuseMapSize.x = diffuseBitmap->Width();
				exportMaterials[i].diffuseMapSize.y = diffuseBitmap->Height();

				// Allocate memory for this material's diffusemap texture.
				UINT numDiffuseMapPixels = exportMaterials[i].diffuseMapSize.x * exportMaterials[i].diffuseMapSize.y;
				exportMaterials[i].diffuseMapData = new rgbaColor_8bit[numDiffuseMapPixels];

				OutputDebugString("About to export texture rows...\n");

				for (int k = (exportMaterials[i].diffuseMapSize.y - 1); k >= 0; k--)
				{
					// Allocate memory to hold a row of pixel data.
					BMM_Color_fl* curPixelRow = new BMM_Color_fl[exportMaterials[i].diffuseMapSize.x];

					// Get a row of Pixels.
					diffuseBitmap->GetPixels(0, k, exportMaterials[i].diffuseMapSize.x, curPixelRow);

					// Store the color for each pixel in this row.
					for (UINT m = 0; m < exportMaterials[i].diffuseMapSize.x; m++)
					{
						UINT curExportPixel = m + (exportMaterials[i].diffuseMapSize.y * k);

						byte redVal   = (UINT)((curPixelRow[m].r * 255.0f) + 0.5f);
						byte greenVal = (UINT)((curPixelRow[m].g * 255.0f) + 0.5f);
						byte blueVal  = (UINT)((curPixelRow[m].b * 255.0f) + 0.5f);
						byte alphaVal = (UINT)((curPixelRow[m].a * 255.0f) + 0.5f);

						exportMaterials[i].diffuseMapData[curExportPixel].r = redVal;
						exportMaterials[i].diffuseMapData[curExportPixel].g = greenVal;
						exportMaterials[i].diffuseMapData[curExportPixel].b = blueVal;
						exportMaterials[i].diffuseMapData[curExportPixel].a = alphaVal;
					}

					if (curPixelRow != NULL){delete[] curPixelRow;}
				}	
			}
		}
	}

	//----------------------------------------------------------------------
	// Now it's time to go through each original scene material and grab
	// the faces from each object that correspond to that material.
	//----------------------------------------------------------------------
	curMatIndex = 0;

	OutputDebugString("Beginning Material-Based Face Sort\n");
	for (i = 0; i < numSceneRootMaterials; i++)
	{
		UINT faceOffset  = 0;
		UINT gVertOffset = 0;
		UINT tVertOffset = 0;
		UINT nVertOffset = 0;
		UINT cVertOffset = 0;
		UINT edgeOffset  = 0;

		// Standard Material Test:
		if ((!sceneRootMaterials[i]->IsMultiType()) && (!sceneRootMaterials[i]->IsSubObjType()))
		{
			// Loop through the scene mesh indexes until we find a match.
			for (UINT j = 0; j < numSceneMeshes; j++)
			{
				// If this mesh's root material index matches this material's index...
				if (sceneMeshRootMatIndex[j] == i)			
				{	
					// Copy Geometry Faces:
					UINT numFaces = sceneMeshes[j]->GetNumberOfFaces();

					// This variable will keep track of which edge we're writing to later on.
					UINT curEdge = 0;

					// Record the first face that this material uses.
					exportMaterials[curMatIndex].firstMatFace = faceOffset;

					for (UINT k = 0; k < numFaces; k ++)
					{
						FaceEx* curFace = sceneMeshes[j]->GetFace(k);

						// Geometry Faces:
						exportMesh.gFaces[k + faceOffset].x = curFace->vert[0] + sceneMeshGVertOffsets[j];
						exportMesh.gFaces[k + faceOffset].y = curFace->vert[1] + sceneMeshGVertOffsets[j];
						exportMesh.gFaces[k + faceOffset].z = curFace->vert[2] + sceneMeshGVertOffsets[j];

						// Texture Faces
						exportMesh.tFaces[k + faceOffset].x = curFace->texCoord[0] + sceneMeshTVertOffsets[j];
						exportMesh.tFaces[k + faceOffset].y = curFace->texCoord[1] + sceneMeshTVertOffsets[j];
						exportMesh.tFaces[k + faceOffset].z = curFace->texCoord[2] + sceneMeshTVertOffsets[j];

						// Normal Faces
						exportMesh.nFaces[k + faceOffset].x = curFace->norm[0] + sceneMeshNVertOffsets[j];
						exportMesh.nFaces[k + faceOffset].y = curFace->norm[1] + sceneMeshNVertOffsets[j];
						exportMesh.nFaces[k + faceOffset].z = curFace->norm[2] + sceneMeshNVertOffsets[j];

						// Color Faces
						exportMesh.CPVFaces[k + faceOffset].x = curFace->color[0] + sceneMeshCVertOffsets[j];
						exportMesh.CPVFaces[k + faceOffset].x = curFace->color[1] + sceneMeshCVertOffsets[j];
						exportMesh.CPVFaces[k + faceOffset].x = curFace->color[2] + sceneMeshCVertOffsets[j];

						// Visible Edges
						if (curFace->edgeVis[0] == 1)
						{
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].x = curFace->vert[0] + sceneMeshGVertOffsets[j];
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].y = curFace->vert[1] + sceneMeshGVertOffsets[j];

							curEdge += 1;
						};
						if (curFace->edgeVis[1] == 1)
						{ 
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].x = curFace->vert[1] + sceneMeshGVertOffsets[j];
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].y = curFace->vert[2] + sceneMeshGVertOffsets[j];

							curEdge += 1;
						};
						if (curFace->edgeVis[2] == 1)
						{ 
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].x = curFace->vert[2] + sceneMeshGVertOffsets[j];
							exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].y = curFace->vert[0] + sceneMeshGVertOffsets[j];

							curEdge += 1;
						};
					}

					faceOffset  += sceneMeshes[j]->GetNumberOfFaces();		// is ok

					// Record the last face that this material uses.
					exportMaterials[curMatIndex].lastMatFace = faceOffset;
				}
			}

			curMatIndex += 1;
		}
		// Multi/Sub-Object Material Test:
		else if (sceneRootMaterials[i]->IsMultiType())
		{
			// Loop through each subMaterial ID:
			UINT numSubMaterials = sceneRootMaterials[i]->GetSubMaterialCount();

			for (UINT j = 0; j < numSubMaterials; j++)
			{
				// Loop through each mesh in the scene:
				for (UINT k = 0; k < numSceneMeshes; k++)
				{
					// If this mesh uses the current root material...
					if (sceneMeshRootMatIndex[k] == i)
					{
						// Grab a Tab of all the faces which use the current matID:
						Tab<FaceEx*> matFaces = sceneMeshes[k]->GetFacesFromMatID(j);

						// This variable will keep track of which edge we're writing to later on.
						UINT curEdge = 0;

						// Record the first face that this material uses.
						exportMaterials[curMatIndex].firstMatFace = faceOffset;

						// Loop through the faces we just grabbed and write them to the export mesh.
						for (UINT m = 0; m < matFaces.Count(); m++)
						{
							// Geometry Faces:
							exportMesh.gFaces[m + faceOffset].x = matFaces[m]->vert[0] + sceneMeshGVertOffsets[k];
							exportMesh.gFaces[m + faceOffset].y = matFaces[m]->vert[1] + sceneMeshGVertOffsets[k];
							exportMesh.gFaces[m + faceOffset].z = matFaces[m]->vert[2] + sceneMeshGVertOffsets[k];

							// Texture Faces:
							exportMesh.tFaces[m + faceOffset].x = matFaces[m]->texCoord[0] + sceneMeshTVertOffsets[k];
							exportMesh.tFaces[m + faceOffset].y = matFaces[m]->texCoord[1] + sceneMeshTVertOffsets[k];
							exportMesh.tFaces[m + faceOffset].z = matFaces[m]->texCoord[2] + sceneMeshTVertOffsets[k];

							// Normal Faces:
							exportMesh.nFaces[m + faceOffset].x = matFaces[m]->norm[0] + sceneMeshNVertOffsets[k];
							exportMesh.nFaces[m + faceOffset].y = matFaces[m]->norm[1] + sceneMeshNVertOffsets[k];
							exportMesh.nFaces[m + faceOffset].z = matFaces[m]->norm[2] + sceneMeshNVertOffsets[k];

							// Color Faces:
							exportMesh.CPVFaces[m + faceOffset].x = matFaces[m]->color[0] + sceneMeshCVertOffsets[k];
							exportMesh.CPVFaces[m + faceOffset].y = matFaces[m]->color[1] + sceneMeshCVertOffsets[k];
							exportMesh.CPVFaces[m + faceOffset].z = matFaces[m]->color[2] + sceneMeshCVertOffsets[k];

							// Visible Edges:
							if (matFaces[m]->edgeVis[0] == 1)
							{
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[k]].x = matFaces[m]->vert[0] + sceneMeshGVertOffsets[k];
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[k]].y = matFaces[m]->vert[1] + sceneMeshGVertOffsets[k];

								curEdge += 1;
							};
							if (matFaces[m]->edgeVis[1] == 1)
							{ 
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[k]].x = matFaces[m]->vert[1] + sceneMeshGVertOffsets[k];
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[k]].y = matFaces[m]->vert[2] + sceneMeshGVertOffsets[k];

								curEdge += 1;
							};
							if (matFaces[m]->edgeVis[2] == 1)
							{ 
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[k]].x = matFaces[m]->vert[2] + sceneMeshGVertOffsets[k];
								exportMesh.gEdges[curEdge + sceneMeshEdgeOffsets[j]].y = matFaces[m]->vert[0] + sceneMeshGVertOffsets[k];

								curEdge += 1;
							};

						}

						faceOffset += matFaces.Count();

						// Record the last face that this material uses.
						exportMaterials[curMatIndex].lastMatFace = faceOffset;
					}
				}

				curMatIndex += 1;
			}
		}
	}

	//----------------------------------------------------------------------
	// Write out the data file:
	//----------------------------------------------------------------------
	
	// Declare a filestream object for writing:
	ofstream outFile;

	// Open the filestream object using the supplied filename.
	outFile.open(someName, ios::binary);

	// Just in case we can't open the file.
	if (!outFile.is_open())
	{
		outFile.close();
		MessageBox(NULL, "Could not open Output File.", "ESSM Export Error", MB_OK);
		return false;
	}

	// Debug
	sprintf(buffer, "Writing %d GVerts\n",          exportMesh.numGVerts);		OutputDebugString(buffer);
	sprintf(buffer, "Writing %d GEdges\n",          exportMesh.numGEdges);		OutputDebugString(buffer);
	sprintf(buffer, "Writing %d GFaces\n",          exportMesh.numGFaces);		OutputDebugString(buffer);
	sprintf(buffer, "Writing %d TVerts\n",          exportMesh.numTVerts);		OutputDebugString(buffer);
	sprintf(buffer, "Writing %d NVerts\n",          exportMesh.numNVerts);		OutputDebugString(buffer);
	sprintf(buffer, "Writing %d CPVColors\n",       exportMesh.numCPVColors);	OutputDebugString(buffer);
	sprintf(buffer, "Writing %d Scene Materials\n", numSceneMaterials);			OutputDebugString(buffer);

	// Writing the file header information:
	outFile.write((char*) &exportMesh.numGVerts,    sizeof(exportMesh.numGVerts));
	outFile.write((char*) &exportMesh.numGEdges,    sizeof(exportMesh.numGEdges));
	outFile.write((char*) &exportMesh.numGFaces,    sizeof(exportMesh.numGFaces));
	outFile.write((char*) &exportMesh.numTVerts,    sizeof(exportMesh.numTVerts));
	outFile.write((char*) &exportMesh.numNVerts,    sizeof(exportMesh.numNVerts));
	outFile.write((char*) &exportMesh.numCPVColors, sizeof(exportMesh.numCPVColors));
	outFile.write((char*) &numSceneMaterials,	   sizeof(numSceneMaterials));
	
	// Writing the Mesh Data:
	outFile.write((char*) exportMesh.gVerts,    sizeof(float3)		   * exportMesh.numGVerts);
	outFile.write((char*) exportMesh.gEdges,    sizeof(point2)		   * exportMesh.numGEdges);
	outFile.write((char*) exportMesh.gFaces,    sizeof(point3)		   * exportMesh.numGFaces);
	outFile.write((char*) exportMesh.tVerts,    sizeof(float2)		   * exportMesh.numTVerts);
	outFile.write((char*) exportMesh.tFaces,    sizeof(point3)		   * exportMesh.numGFaces);
	outFile.write((char*) exportMesh.nVerts,    sizeof(float3)		   * exportMesh.numNVerts);
	outFile.write((char*) exportMesh.nFaces,    sizeof(point3)		   * exportMesh.numGFaces);
	outFile.write((char*) exportMesh.CPVFaces,  sizeof(point3)		   * exportMesh.numGFaces);
	outFile.write((char*) exportMesh.CPVColors, sizeof(rgbaColor_8bit) * exportMesh.numCPVColors);

	// Writing the material definitions:
	for (i = 0; i < numSceneMaterials; i++)
	{
		// Write out the material colors:
		outFile.write((char*) &exportMaterials[i].ambient,   sizeof(exportMaterials[i].ambient));
		outFile.write((char*) &exportMaterials[i].diffuse,   sizeof(exportMaterials[i].diffuse));
		outFile.write((char*) &exportMaterials[i].specular,  sizeof(exportMaterials[i].specular));
		outFile.write((char*) &exportMaterials[i].shininess, sizeof(exportMaterials[i].shininess));
		outFile.write((char*) &exportMaterials[i].emissive,  sizeof(exportMaterials[i].emissive));

		// Write out the number of faces that use this material:
		outFile.write((char*) &exportMaterials[i].numMatFaces, sizeof(exportMaterials[i].numMatFaces));

		// Write the index of the first face which uses this material:
		outFile.write((char*) &exportMaterials[i].firstMatFace, sizeof(exportMaterials[i].firstMatFace));
		
		// Write the index of the last face which uses this material:
		outFile.write((char*) &exportMaterials[i].lastMatFace,  sizeof(exportMaterials[i].lastMatFace));

		// Write the size of the material's diffuseMap:
		outFile.write((char*) &exportMaterials[i].diffuseMapSize.x, sizeof(exportMaterials[i].diffuseMapSize.x));
		outFile.write((char*) &exportMaterials[i].diffuseMapSize.y, sizeof(exportMaterials[i].diffuseMapSize.y));

		// Write out the diffuseMap texture data:
		UINT curDiffuseMemSize = (exportMaterials[i].diffuseMapSize.x * exportMaterials[i].diffuseMapSize.y) * 4;
		outFile.write((char*) exportMaterials[i].diffuseMapData, curDiffuseMemSize);
	}

	// Close the output file.
	outFile.close();
	
	OutputDebugString("Cleaning up allocated memory\n");

	// Memory cleanup:
	if (sceneMeshes            != NULL){delete[] sceneMeshes;}
	if (sceneMeshRootMatIndex  != NULL){delete[] sceneMeshRootMatIndex;}
	if (sceneMeshEdgeCounts    != NULL){delete[] sceneMeshEdgeCounts;}
	if (sceneRootMaterials     != NULL){delete[] sceneRootMaterials;}
	if (sceneMaterials         != NULL){delete[] sceneMaterials;}
	if (exportMaterials        != NULL){delete[] exportMaterials;}

	if (sceneMeshGVertOffsets != NULL){delete[] sceneMeshGVertOffsets;}
	if (sceneMeshTVertOffsets != NULL){delete[] sceneMeshTVertOffsets;}
	if (sceneMeshNVertOffsets != NULL){delete[] sceneMeshNVertOffsets;} 
	if (sceneMeshCVertOffsets != NULL){delete[] sceneMeshCVertOffsets;} 
	if (sceneMeshEdgeOffsets  != NULL){delete[] sceneMeshEdgeOffsets;}

	// return TRUE If the file is exported properly
	return TRUE;
}

// Returns the number of file name extensions supported by this plugin:
int CExportESSM::ExtCount()
{
	return ESSMEXP_FILEEXTENSIONCOUNT;
}

// Returns the 3 (or more) letter extension seen in the file browser (i.e. "3DS"):
const TCHAR* CExportESSM::Ext(int n)
{		
	return _T(ESSMEXP_FILEEXTENSION_ESSM);
}

// Returns a long description of the file type (i.e. "Targa 2.0 Image File"):
const TCHAR* CExportESSM::LongDesc()
{
	return _T(ESSMEXP_FILETYPE_ESSM_LONGDESCRIPTION);
}

// Returns a short description of the file type (i.e. "Targa"):
const TCHAR* CExportESSM::ShortDesc() 
{			
	return _T(ESSMEXP_FILETYPE_ESSM_SHORTDESCRIPTION);
}

// Returns the name of the plugin's author:
const TCHAR* CExportESSM::AuthorName()
{			
	return _T(ESSMEXP_PLUGIN_AUTHORNAME);
}

// Returns the plugin's copyright message:
const TCHAR* CExportESSM::CopyrightMessage() 
{	
	return _T(ESSMEXP_PLUGIN_COPYRIGHTMSG);
}

//Return Other message #1 if any:
const TCHAR* CExportESSM::OtherMessage1() 
{		
	return _T("");
}

//Return Other message #2 if any:
const TCHAR* CExportESSM::OtherMessage2() 
{		
	return _T("");
}

// Return version number * 100:
unsigned int CExportESSM::Version()
{				
	return ESSMEXP_PLUGIN_VERSION;
}

// Optional call to show an "About" box.
void CExportESSM::ShowAbout(HWND hWnd)
{			
	// nothing yet
}

// This function decides which 3DS "options" are supported. As yet, there
// is only one option. "SCENE_EXPORT_SELECTED". We'll get to that one in due time.
BOOL CExportESSM::SupportsOptions(int ext, DWORD options)
{
	return true;
}

