////////////////////////////////////////////////////////////////////////
// ESSM Exporter.cpp - DLL entry point for the ESSM Exporter.
//
// �2006 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////

// Our Precompiled header
#include "stdafx.h"				

// Our resource descriptor for the export options dialog:
#include "resource.h"

// Headers for our plugin's classes:
#include "exportESSM.h"
#include "ExportClassDescriptor.h"

// This is a workaround for the mangling of C-Style names that prevents
// my exported functions from being seen:
extern "C" __declspec(dllexport) const TCHAR* LibDescription();
extern "C" __declspec(dllexport) int		  LibNumberClasses();
extern "C" __declspec(dllexport) ClassDesc*	  LibClassDesc(int i);
extern "C" __declspec(dllexport) ULONG		  LibVersion();
extern "C" __declspec(dllexport) ULONG		  CanAutoDefer();

// Global variables and objects:
HINSTANCE				g_hInstance;						// Global handle to our application instance.
HWND					g_hWndMain;							// Global handle to our main window.
CExportClassDescriptor	g_ExportDescription;
int						g_controlsInitialized = false;			

//----------------------------------------------------------------------
// This is the main DLL entry function.
//----------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hinstDLL,ULONG fdwReason,LPVOID lpvReserved)
{
	g_hInstance = hinstDLL;					// Hang on to this DLL's instance handle.

	if (g_controlsInitialized == false) 
	{
		g_controlsInitialized = true;

		InitCustomControls(g_hInstance);		// Initialize MAX's custom controls
		InitCommonControls();					// Initialize Win95 controls
	}

	return true;
}

// Not sure what this is supposed to be returning. 
__declspec(dllexport) const TCHAR* LibDescription()
{
	return _T(ESSMEXP_LIB_DESCRIPTION);
}

// Returns the number of classes in this plugin:
__declspec(dllexport) int LibNumberClasses()
{
	// Change this number when adding new classes to this plugin.
	return ESSMEXP_NUM_PLUGIN_CLASSES;
}

__declspec(dllexport) ClassDesc* LibClassDesc(int i)
{
	switch(i) {
		case 0:  return GetExportDescription();
		default: return 0;
	}
}

__declspec(dllexport) ULONG LibVersion()
{
	return VERSION_3DSMAX;
}

// Let the plug-in register itself for deferred loading
__declspec(dllexport) ULONG CanAutoDefer()
{
	return 1;
}
