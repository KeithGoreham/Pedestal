//////////////////////////////////////////////////////////////
// Interface file for all UI related functions.
//
// �2006 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Preprocessor directives:
#pragma once

// Precompiled header files.
#include "stdafx.h"

// Other headers:
#include "resource.h"					// Resource script (defines things like our dialog panel).

// Externally defined variables:
extern HINSTANCE g_hInstance;			// Global handle to our application instance.
extern HWND		 g_hWndMain;			// Global handle to our main window.

// Window Callback Function Declarations:
BOOL CALLBACK DlgProc_ExportOptions(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam);