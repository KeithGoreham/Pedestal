//----------------------------------------------------------------------
// meshInfoStructs.h - A collection of useful structs for storing mesh
// data.
//
// �2006 by Keith Goreham - www.goreham.com
//----------------------------------------------------------------------

// Defines used with these structs:
#define RGB_MAP  3
#define RGBA_MAP 4


// Point3 struct for handling triangle definitions:
struct point3
{
	UINT x;
	UINT y;
	UINT z;
};

// Point2 struct for handling visible edge definitions:
struct point2
{
	UINT x;
	UINT y;
};

// Float3 struct for vertex positions and vertex normals.
struct float3
{
	float x;
	float y;
	float z;
};

// Float2 Struct for texture coordinates.
struct float2
{
	float x;
	float y;
};

// RGB struct for storing vertex colors.
struct rgbColor
{
	float r;
	float g;
	float b;
};

// RGB struct for storing texture colors.
struct rgbColor_8bit
{
	byte r;
	byte g;
	byte b;
};

// RGBA struct for storing texture colors.
struct rgbaColor_8bit
{
	byte r;
	byte g;
	byte b;
	byte a;
};

// Struct for storing all of a mesh's info.
struct meshInfo
{
	// Member Variables for Mesh File Data:
	UINT		  numGVerts;		// Stores the number of geometry verticies that will be written to the file.
	UINT		  numGEdges;		// Stores the number of visible geometry edges that will be written to the file.
	UINT		  numGFaces;		// Stores the number of geometry faces that will be written to the file.
	UINT		  numTVerts;		// Stores the number of texture verticies that will be written to the file.
	UINT		  numNVerts;		// Stores the number of vertex normals that will be written to the file.
	UINT		  numCPVColors;		// Stores the number of vertex colors in the mesh.
	UINT		  numMaterials;		// Stores the number of different materials used in this mesh.
	rgbColor_8bit wireColor;		// The wireframe color of the mesh.

	// 3D data pointers:
	float3*		gVerts;		// Pointer to an array of all the mesh's verticies.
	point2*		gEdges;		// Pointer to an array of all the mesh's visible edges.
	point3*		gFaces;		// Pointer to an array of all the mesh's face definitions.
	float2*		tVerts;		// Pointer to an array of all the mesh's texture verticies.
	point3*		tFaces;		// Pointer to an array of all the mesh's texture face definitions.
	float3*		nVerts;		// Pointer to an array of all the mesh's vertex normals.
	point3*		nFaces;		// Pointer to an array of all the mesh's normal face definitions.
	rgbColor*	CPVColors;	// Pointer to an array of all the mesh's vertex colors.
	point3*		CPVFaces;	// Pointer to an array of all the mesh's vertex color face definitions.

//	materialInfo*	materials;		// Pointer to an array of material definitions.

	// Constructor:
	meshInfo(void)
	{
		numGVerts    = 0;
		numGEdges    = 0;
		numGFaces    = 0;
		numTVerts    = 0;
		numNVerts    = 0;
		numCPVColors = 0;
//		numMaterials = 0;

		wireColor.r = 1.0;
		wireColor.g = 1.0;
		wireColor.b = 1.0;

		gVerts    = 0;
		gEdges    = 0;
		gFaces    = 0;
		tVerts    = 0;
		tFaces    = 0;
		nVerts    = 0;
		nFaces    = 0;
		CPVColors = 0;
		CPVFaces  = 0;
//		materials = 0;
	}

	// Destructor:
	~meshInfo(void)
	{
		if (gVerts	  != NULL){delete[] gVerts;    gVerts = 0;}
		if (gEdges	  != NULL){delete[] gEdges;    gEdges = 0;}
		if (gFaces	  != NULL){delete[] gFaces;    gEdges = 0;}
		if (tVerts	  != NULL){delete[] tVerts;    tVerts = 0;}
		if (tFaces	  != NULL){delete[] tFaces;    tFaces = 0;}
		if (nVerts	  != NULL){delete[] nVerts;    nVerts = 0;}
		if (nFaces	  != NULL){delete[] nFaces;	   nFaces = 0;}
		if (CPVColors != NULL){delete[] CPVColors; CPVColors = 0;}
		if (CPVFaces  != NULL){delete[] CPVFaces;  CPVFaces  = 0;}
//		if (materials != NULL){delete[] materials; materials = 0;}
	}
};

// Struct for storing a texture map's info.
struct mapInfo
{
	UINT numChannels;
	UINT xSize;
	UINT ySize;

	// Array pointer for pixel data.
	rgbaColor_8bit* pixelData;

	~mapInfo()
	{
		if (pixelData != NULL){delete[] pixelData;}
	}
};

// Struct for storing all of a material's info.
struct materialInfo
{
	rgbColor	ambient;			// Ambient Color
	rgbColor	diffuse;			// Diffuse Color
	rgbColor	specular;			// Specular Color
	char		shininess;			// Specular Exponent
	rgbColor	emissive;			// Emissive (Self-Illuminated) Color

	UINT		numMatFaces;		// Number of faces that use this material
	UINT		firstMatFace;		// First face index used by this material
	UINT		lastMatFace;		// Last face index used by this material

	UINT        numDiffuseMapChannels;
	point2		diffuseMapSize;

	// Array pointer for pixel data.
	rgbaColor_8bit* diffuseMapData;

	// Constructor
	materialInfo(void)
	{
		diffuseMapData = NULL;
	};

	// Destructor
	~materialInfo(void)
	{
		if (diffuseMapData != NULL){delete[] diffuseMapData;}
	};
};




