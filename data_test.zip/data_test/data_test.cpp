// data_test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <ostream>
#include "windows.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int intSize  = sizeof(int);
	int uintSize = sizeof(UINT);

	cout << "An int is " << intSize  << " bytes.\n";
	cout << "A UINT is " << uintSize << " bytes.\n";

	// The following is just here to keep the app from closing right  
	// away when we test it in Visual Studio.
	int foo;
	cin >> foo;

	return 0;


}

