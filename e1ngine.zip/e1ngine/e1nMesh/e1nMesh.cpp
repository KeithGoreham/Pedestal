#include "StdAfx.h"
#include ".\e1nmesh.h"

e1nMesh::e1nMesh(void)
{
}

e1nMesh::~e1nMesh(void)
{
}
