#pragma once

#define EIN_RGB  0x01
#define EIN_RGBA 0x02

class e1nMesh
{
	struct texture
	{

	};

	struct material
	{
//		eRGBf ambientColor;
//		eRGBf diffuseColor;
//		eRGBf specularColor;
//		eRGBf emissiveColor;

		char shininess;
	};


	struct header
	{
//		UINT ident;				// Magic Number Identifier for the file.
//		UINT version;			// Version number for the file.

//		UINT numVerts;			// Number of vertices in one frame of the model.
//		UINT numFrames;			// Number of vert sets used for animation. Total Verts = numVerts * numFrames.

		int skinWidth;			
		int skinHeight;

		int frameSize;

		int numSkins;
		int numVerts;

		int numTVerts;
		int numTriangles;
		int numGLCmds;
		int numFrames;

		int offsetSkins;
		int offsetTVerts;
		int offsetTriangles;
		int offsetFrames;
		int offsetGLCmds;
		int offsetEnd;
	};

	struct data
	{

	};


public:
	e1nMesh(void);
	~e1nMesh(void);
};
