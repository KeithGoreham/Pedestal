#pragma once

class Ce1nPlayer
{
public:
	Ce1nPlayer(void);
	~Ce1nPlayer(void);

	eVECT3 pos;
	eVECT3 vel;
	eVECT3 accel;
	eVECT3 rot;
	eVECT3 lat;
};