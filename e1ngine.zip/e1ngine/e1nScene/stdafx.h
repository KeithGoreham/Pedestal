// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


// Other Defines.
#define WIN32_LEAN_AND_MEAN			// Leaves out the Microsoft Foundation Classes.
#define WIN32_EXTRA_LEAN			// Leaves out other Windows crap we don't need.

// Standard C++ non-system include files:
#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <fstream>

// Windows API headers:
#include <windows.h>
#include <Commdlg.h>					// Common Dialog Boxes.

// DirectX Include Files:
#include <objbase.h>					// Needed for Input Device GUID definitions.

// e1ngine include files:
#include "e1nMath.h"

// TODO: reference additional headers your program requires here
