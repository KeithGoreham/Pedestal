#include "StdAfx.h"
#include "e1nScene.h"

Ce1nPlayer::Ce1nPlayer(void)
{
}

Ce1nPlayer::~Ce1nPlayer(void)
{
}
