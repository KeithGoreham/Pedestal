// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


// Standard C++ include files:
#include <iostream>
#include <cmath>

// Windows defines:
#define WIN32_LEAN_AND_MEAN			// Exclude rarely-used stuff from Windows headers
#define WIN32_EXTRA_LEAN			// Leaves out other Windows crap we don't need.

// TODO: reference additional headers your program requires here
