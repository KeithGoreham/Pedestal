//////////////////////////////////////////////////////////
// e1nVector2f.cpp - Implementation file for the Vector2
// class.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Includes:
#include "stdafx.h"

#include "e1nMath.h"

// Other directives:
using namespace std;		// Less typing when using cout.

//========================================================
// Constructors
//========================================================

// Default Constructor. No initialization.
Ce1nVector2f::Ce1nVector2f(void) {}

// 2D Copy Constructor
 Ce1nVector2f::Ce1nVector2f(const Ce1nVector2f &someVect2) : x(someVect2.x), y(someVect2.y) {}

// Initialization list constructor
Ce1nVector2f::Ce1nVector2f(const float xVal, const float yVal) : x(xVal), y(yVal) {}

// Destructor
Ce1nVector2f::~Ce1nVector2f() {}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nVector2f::print(ostream *os)
{
	*os << "Ce1nVector2f(" << x << ", " << y << ")";
}

//========================================================
// Non-Member functions.
//========================================================

// Print operator overload. So we can cout the vector.
ostream &operator <<(ostream &os, Ce1nVector2f &someVect)
{
	someVect.print(&os);
	return os;
}