//////////////////////////////////////////////////////////
// e1nVector3i.h - Implementation file for the 
// e1nVector3iu and e1nVector3i classes.
//
// �2005 by Keith Goreham
//////////////////////////////////////////////////////////

// Include Files:
#include "stdafx.h"				// Precompiled headers.
#include "e1nMath.h"			// The header file for this class.

// Other directives:
using namespace std;			// Less typing when using cout.

//========================================================
// Constructors
//========================================================

// Default Constructor
Ce1nVector3iu::Ce1nVector3iu(void) {}
Ce1nVector3i::Ce1nVector3i(void)   {}

// 3D Copy Constructor
Ce1nVector3iu::Ce1nVector3iu(const Ce1nVector3iu &somePOINT3U) : x(somePOINT3U.x), y(somePOINT3U.y), z(somePOINT3U.z) {}
Ce1nVector3i::Ce1nVector3i(const Ce1nVector3i &somePOINT3)     : x(somePOINT3.x),  y(somePOINT3.y),  z(somePOINT3.z) {}

// Initialization list constructor
Ce1nVector3iu::Ce1nVector3iu(const int xVal, const int yVal, const int zVal) : x(xVal), y(yVal), z(zVal) {}
Ce1nVector3i::Ce1nVector3i  (const int xVal, const int yVal, const int zVal) : x(xVal), y(yVal), z(zVal) {}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nVector3iu::print(ostream *os)
{
	*os << "Ce1nVector3iu(" << x << ", " << y << ", " << z << ")";
}

void Ce1nVector3i::print(ostream *os)
{
	*os << "Ce1nVector3i(" << x << ", " << y << ", " << z << ")";
}

//========================================================
// Non-Member functions.
//========================================================

// Print operator overload. So we can cout the Ce1nVector3iu.
ostream &operator <<(ostream &os, Ce1nVector3iu &someVect)
{
	someVect.print(&os);
	return os;
}

// Print operator overload. So we can cout the Ce1nVector3iu.
ostream &operator <<(ostream &os, Ce1nVector3i &someVect)
{
	someVect.print(&os);
	return os;
}