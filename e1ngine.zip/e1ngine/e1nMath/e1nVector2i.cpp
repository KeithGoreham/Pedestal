//////////////////////////////////////////////////////////
// e1nVector2i.cpp - Implementation file for the 
// e1nVector2iu and e1nVector2i classes.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Includes.
#include "stdafx.h"			// Precompiled headers.
#include "e1nMath.h"		// The header file for this class.

// Other declarations.
using namespace std;		// Less typing when using cout.		

//========================================================
// Constructors
//========================================================

// Default Constructor
Ce1nVector2iu::Ce1nVector2iu(void) {}	
Ce1nVector2i::Ce1nVector2i(void)   {}

// Copy Constructor
Ce1nVector2iu::Ce1nVector2iu(const Ce1nVector2iu &somePOINT2U) : x(somePOINT2U.x), y(somePOINT2U.y) {}
Ce1nVector2i::Ce1nVector2i(const Ce1nVector2i &somePOINT2)     : x(somePOINT2.x),  y(somePOINT2.y)  {}

// Initialization list constructor
Ce1nVector2iu::Ce1nVector2iu(const unsigned int xVal, const unsigned int yVal) : x(xVal), y(yVal) {}
Ce1nVector2i::Ce1nVector2i  (const int          xVal, const int          yVal) : x(xVal), y(yVal) {}

// Destructor
Ce1nVector2iu::~Ce1nVector2iu() {}
Ce1nVector2i::~Ce1nVector2i()   {}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nVector2iu::print(ostream *os)
{
	*os << "Ce1nVector2iu(" << x << ", " << y << ")";
}

void Ce1nVector2i::print(ostream *os)
{
	*os << "Ce1nVector2i(" << x << ", " << y << ")";
}

//========================================================
// Non-Member functions.
//========================================================

// Print operator overload. So we can cout the Ce1nVector2iu.
ostream &operator <<(ostream &os, Ce1nVector2iu &someVect)
{
	someVect.print(&os);
	return os;
}

ostream &operator <<(ostream &os, Ce1nVector2i &someVect)
{
	someVect.print(&os);
	return os;
}