//////////////////////////////////////////////////////////////
// Ce1nColorRGBAf.h - Implementation file for the 
// Ce1nColorRGBAf class.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Includes:
#include "stdafx.h"
#include "e1nMath.h"

// Preprocessor directives:
using namespace std;

//========================================================
// Constructors
//========================================================

// Default constructor.
Ce1nColorRGBAf::Ce1nColorRGBAf() 
{
	r = g = b = a = 0.0f;			// Zero out all components.
}														

// Floating point initialization list constructor.
Ce1nColorRGBAf::Ce1nColorRGBAf(const float rVal,
							   const float gVal,
							   const float bVal, 
							   const float aVal) : r(rVal),
												   g(gVal),
												   b(bVal),
												   a(aVal)
{
	// Do nothing else.
}			

//========================================================
// Destructor
//========================================================
Ce1nColorRGBAf::~Ce1nColorRGBAf(void)
{
	// Do Nothing
}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nColorRGBAf::print(ostream *os)
{
	*os << "Ce1nColorRGBAf(" << (float) r << ", " << (float) g << ", " << (float) b << "," << (float) a << ")";
}

//========================================================
// Non-Member functions.
//========================================================

// Print operator overload. So we can cout the color.
ostream &operator <<(ostream &os, Ce1nColorRGBAf &someColor)
{
	someColor.print(&os);
	return os;
}