//////////////////////////////////////////////////////////
// e1nVector3f.cpp - Implementation file for theCVector3
// class.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

// Includes:
#include "stdafx.h"

#include "e1nMath.h"

// Other directives:
using namespace std;		// Less typing when using cout.

//========================================================
// Constructors
//========================================================

// Default Constructor
Ce1nVector3f::Ce1nVector3f(void) {}

// 3D Copy Constructor
Ce1nVector3f::Ce1nVector3f(const Ce1nVector3f &someVect3) : x(someVect3.x), y(someVect3.y), z(someVect3.z) {}

// Initialization list constructor
Ce1nVector3f::Ce1nVector3f(const float xVal, const float yVal, const float zVal) : x(xVal), y(yVal), z(zVal) {}

// Destructor
Ce1nVector3f::~Ce1nVector3f() {}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nVector3f::print(ostream *os)
{
	*os << "Ce1nVector3f(" << x << ", " << y << ", " << z << ")";
}

//========================================================
// Non-Member functions.
//========================================================

// Print operator overload. So we can cout the vector.
ostream &operator <<(ostream &os, Ce1nVector3f &someVect)
{
	someVect.print(&os);
	return os;
}
