//////////////////////////////////////////////////////////////
// Ce1nColorRGBf.h - Implementation file for the Ce1nColorRGBf class.
//
// �2004 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////////

// Includes:
#include "stdafx.h"
#include "e1nMath.h"

// Preprocessor directives:
using namespace std;

//========================================================
// Constructors
//========================================================

// Default constructor.
Ce1nColorRGBf::Ce1nColorRGBf() 
{
	r = g = b = 0.0f;			// Zero out all components.
}														

// Floating point initialization list constructor.
Ce1nColorRGBf::Ce1nColorRGBf(const float rVal,
							 const float gVal,
							 const float bVal) : r(rVal),
												 g(gVal),
												 b(bVal)
{
	// Do nothing else.
}			

//========================================================
// Destructor
//========================================================
Ce1nColorRGBf::~Ce1nColorRGBf(void)
{
	// Do Nothing
}

//========================================================
// Standard Object Maintenance.
//========================================================

// Print function (for debugging).
void Ce1nColorRGBf::print(ostream *os)
{
	*os << "Ce1nColorRGBf(" << (float) r << ", " << (float) g << ", " << (float) b << ")";
}

//========================================================
// Non-Member functions.
//========================================================


//--------------------------------------------------------
// Print operator overload. So we can cout the color.
//--------------------------------------------------------
ostream &operator <<(ostream &os, Ce1nColorRGBf &someColor)
{
	someColor.print(&os);
	return os;
}