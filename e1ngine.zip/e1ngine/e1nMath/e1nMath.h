////////////////////////////////////////////////////////////////////////////////
// e1nMath.h - Interface file for the e1nMath library.
// Part of the e1ngine game engine.
//
// Member Classes:
// 
// Ce1nVector2iu - 2D integer vector class.
// Ce1nVector2f - 2D floating point vector class.
// Ce1nVector3iu - 3D integer vector class.
// Ce1nVector3f - 3D floating point vector class.
//
// Ce1nColorRGBf - RGB color class.
//
// �2005 by Keith Goreham - www.goreham.com
////////////////////////////////////////////////////////////////////////////////

#pragma once

// Includes:
#include "stdafx.h"			// Precompiled headers.

// Other declarations:
using namespace std;		// Less typing when using cout commands.

// Constants:
#define PI 3.1415927f		// PI

//==============================================================================
// Ce1nVector2iu - A 2d unsigned integer vector class.
//==============================================================================

typedef class Ce1nVector2iu
{
public:

	// Member variables:
	unsigned short int x;			// The variable for the vector's x component.
	unsigned short int y;			// The variable for the vector's y component.

	// Constructors
	Ce1nVector2iu(void);													// Default Constructor
	Ce1nVector2iu(const Ce1nVector2iu &somePOINT2U);						// Copy Constructor
	Ce1nVector2iu(const unsigned int xVal, const unsigned int yVal);		// Initialization list constructor

	// Destructor
	~Ce1nVector2iu();

	// Standard Object Maintenance.
	Ce1nVector2iu &operator =(const Ce1nVector2iu &somePOINT2U);		// 2D Assignment Operator.
	bool operator ==(const Ce1nVector2iu &somePOINT2U) const;			// Equality check.
	bool operator !=(const Ce1nVector2iu &somePOINT2U) const;			// Inequality check.
	void print(ostream *os);										// Print function (for debugging to console);

	// Vector Operations
	void zero();			// Sets the vector components to zero.
}ePOINT2U;

// Non-member function definitions:
ostream &operator <<(ostream &os, Ce1nVector2iu &someVect);		// Print operator overload. So we can cout the Ce1nVector2iu.

//------------------------------------------------------------------------------
// Ce1nVector2iu - Inline function definitions.
//------------------------------------------------------------------------------

// 2D Assignment Operator.
inline Ce1nVector2iu &Ce1nVector2iu::operator =(const Ce1nVector2iu &somePOINT2U)
{	
	x = somePOINT2U.x;
	y = somePOINT2U.y;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nVector2iu::operator ==(const Ce1nVector2iu &somePOINT2U)
const{
	return  x == somePOINT2U.x && 
			y == somePOINT2U.y;
}

// Inequality check.
inline bool Ce1nVector2iu::operator !=(const Ce1nVector2iu &somePOINT2U)
const{
	return  x != somePOINT2U.x || 
			y != somePOINT2U.y;
}

// Set the vector to zero.
inline void Ce1nVector2iu::zero()
{
	x = 0;
	y = 0;
}

//==============================================================================
// Ce1nVector2i - A 2d integer (signed) vector class.
//==============================================================================

typedef class Ce1nVector2i
{
public:

	// Member variables:
	short int x;			// The variable for the vector's x component.
	short int y;			// The variable for the vector's y component.

	// Constructors
	Ce1nVector2i(void);										// Default Constructor
	Ce1nVector2i(const Ce1nVector2i &somePOINT2);			// Copy Constructor
	Ce1nVector2i(const int xVal, const int yVal);			// Initialization list constructor

	// Destructor
	~Ce1nVector2i();

	// Standard Object Maintenance.
	Ce1nVector2i &operator =(const Ce1nVector2i &somePOINT2);		// 2D Assignment Operator.
	bool operator ==(const Ce1nVector2i &somePOINT2) const;			// Equality check.
	bool operator !=(const Ce1nVector2i &somePOINT2) const;			// Inequality check.
	void print(ostream *os);										// Print function (for debugging to console);

	// Vector Operations
	void zero();			// Sets the vector components to zero.
}ePOINT2;

// Non-member function definitions:
ostream &operator <<(ostream &os, Ce1nVector2i &someVect);		// Print operator overload. So we can cout the Ce1nVector2i.

//------------------------------------------------------------------------------
// Ce1nVector2i - Inline function definitions.
//------------------------------------------------------------------------------

// 2D Assignment Operator.
inline Ce1nVector2i &Ce1nVector2i::operator =(const Ce1nVector2i &somePOINT2)
{	
	x = somePOINT2.x;
	y = somePOINT2.y;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nVector2i::operator ==(const Ce1nVector2i &somePOINT2)
const{
	return  x == somePOINT2.x && 
			y == somePOINT2.y;
}

// Inequality check.
inline bool Ce1nVector2i::operator !=(const Ce1nVector2i &somePOINT2)
const{
	return  x != somePOINT2.x || 
			y != somePOINT2.y;
}

// Set the vector to zero.
inline void Ce1nVector2i::zero()
{
	x = 0;
	y = 0;
}

//==============================================================================
// Ce1nVector2f - A 2d floating point vector class.
//==============================================================================

typedef class Ce1nVector2f
{
public:

	// Member variables:

	float x;		// The variable for the vector's x component.
	float y;		// The variable for the vector's y component.

	// Constructors
	Ce1nVector2f(void);											// Default Constructor
	Ce1nVector2f(const Ce1nVector2f &someVect2);				// 2D Copy Constructor
	Ce1nVector2f(const float xVal, const float yVal);			// Initialization list constructor

	// Destructor
	~Ce1nVector2f();

	// Standard Object Maintenance.
	Ce1nVector2f &operator =(const Ce1nVector2f &someVect2);			// 2D Assignment Operator.
	bool operator ==(const Ce1nVector2f &someVect2) const;				// Equality check.
	bool operator !=(const Ce1nVector2f &someVect2) const;				// Inequality check.
	void print(ostream *os);											// Print function (for debugging to console).

	// Vector Operations
	void zero();														// Set the vector to zero.
	Ce1nVector2f operator -() const;									// Unary minus returns the negative of the vector.
	Ce1nVector2f operator +(const Ce1nVector2f &someVect2) const;		// Vector addition.
	Ce1nVector2f operator -(const Ce1nVector2f &someVect2) const;		// Vector subtraction.
	Ce1nVector2f operator *(const float someFloat) const;				// Multiplication by a Scalar.
	Ce1nVector2f operator /(const float someScalar) const;				// Division by a Scalar.	
	
	// Combined assignment operators.
	Ce1nVector2f &operator +=(const Ce1nVector2f &someVect2);			// Plus equals.
	Ce1nVector2f &operator -=(const Ce1nVector2f &someVect2);			// Minus equals.
	Ce1nVector2f &operator *=(const float &someScalar);					// Multiply equals.
	Ce1nVector2f &operator /=(const float &someScalar);					// Divide equals.
	
	// Other member functions.
	void normalize();													// Normalize the vector.	
	float operator *(const Ce1nVector2f &someVect) const;				// Vector Dot Product.
}eVECT2;

// Non-member function definitions:
float magnitude(const Ce1nVector2f &someVect2);							// Compute the magnetude of a vector.
float distance(const Ce1nVector2f &a, const Ce1nVector2f &b);			// Compute the distance between two points.
ostream &operator <<(ostream &os, Ce1nVector2f &someVect);				// Print operator overload. So we can cout the vector.

//------------------------------------------------------------------------------
// Ce1nVector2f - Inline function definitions.
//------------------------------------------------------------------------------

// 2D Assignment Operator.
inline Ce1nVector2f &Ce1nVector2f::operator =(const Ce1nVector2f &someVect2)
{
	x = someVect2.x;
	y = someVect2.y;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nVector2f::operator ==(const Ce1nVector2f &someVect2) const
{
	return  x == someVect2.x && 
			y == someVect2.y;
}

// Inequality check.
inline bool Ce1nVector2f::operator !=(const Ce1nVector2f &someVect2) const
{
	return  x != someVect2.x || 
			y != someVect2.y;
}

// Set the vector to zero.
inline void Ce1nVector2f::zero()
{
	x = 0.0f;
	y = 0.0f;
}

// Unary minus returns the negative of the vector.
inline Ce1nVector2f Ce1nVector2f::operator -() const
{
	return Ce1nVector2f(-x, -y);
}

// Vector addition.
inline Ce1nVector2f Ce1nVector2f::operator +(const Ce1nVector2f &someVect2) const
{
	return Ce1nVector2f(x + someVect2.x, y + someVect2.y);
}

// Vector subtraction.
inline Ce1nVector2f Ce1nVector2f::operator -(const Ce1nVector2f &someVect2) const
{
	return Ce1nVector2f(x - someVect2.x, y - someVect2.y);
}

// Multiplication by a Scalar.
inline Ce1nVector2f Ce1nVector2f::operator *(const float someFloat) const
{
	return Ce1nVector2f(x * someFloat, y * someFloat);
}

// Division by a Scalar.
inline Ce1nVector2f Ce1nVector2f::operator /(const float someScalar) const
{
	float divMult = 1.0f / someScalar;							// Multiplication is faster on x86 than division.
	return Ce1nVector2f(x * divMult, y * divMult);
}

// Plus equals.
inline Ce1nVector2f &Ce1nVector2f::operator +=(const Ce1nVector2f &someVect2)
{
	x += someVect2.x;
	y += someVect2.y;

	return *this;
}

// Minus equals.
inline Ce1nVector2f &Ce1nVector2f::operator -=(const Ce1nVector2f &someVect2)
{
	x -= someVect2.x;
	y -= someVect2.y;

	return *this;
}

// Multiply equals.
inline Ce1nVector2f &Ce1nVector2f::operator *=(const float &someScalar)
{
	x *= someScalar;
	y *= someScalar;

	return *this;
}

// Divide equals.
inline Ce1nVector2f &Ce1nVector2f::operator /=(const float &someScalar)
{
	float divMult = 1.0f / someScalar;

	x *= divMult;
	y *= divMult;

	return *this;
}

// Normalize the vector.
inline void Ce1nVector2f::normalize()
{
	float magSq = (x * x) + (y * y);

	if (magSq > 0.0f)		// Check for divide by zero.
	{
		float divMult = 1.0f / sqrt(magSq);

		x *= divMult;
		y *= divMult;
	}
}

// Vector Dot Product.
inline float Ce1nVector2f::operator *(const Ce1nVector2f &someVect) const
{
	return (x * someVect.x) + (y * someVect.y);
}

//------------------------------------------------------------------------------
// Ce1nVector2f - Non-Member inline functions
//------------------------------------------------------------------------------

// Compute the magnetude of a vector.
inline float magnitude(const Ce1nVector2f &someVect2)
{
	return sqrt((someVect2.x * someVect2.x) + (someVect2.y * someVect2.y));
}

// Compute the distance between two points.
inline float distance(const Ce1nVector2f &a, const Ce1nVector2f &b)
{
	float dx = a.x - b.x;
	float dy = a.y - b.y;

	return sqrt((dx * dx) + (dy * dy));
}


//==============================================================================
// Ce1nVector3iu - A 3d unsigned integer vector class.
//==============================================================================

typedef class Ce1nVector3iu  
{
public:

	unsigned short int x;		// The variable for the vector's x component.
	unsigned short int y;		// The variable for the vector's y component.
	unsigned short int z;		// The variable for the vector's z component.

	// Constructors
	Ce1nVector3iu(void);													// Default Constructor
	Ce1nVector3iu(const Ce1nVector3iu &somePOINT3U);						// Copy Constructor
	Ce1nVector3iu(const int xVal, const int yVal, const int zVal);		// Initialization list constructor
  	
	// Standard Object Maintenance.
	Ce1nVector3iu &operator =(const Ce1nVector3iu &somePOINT3U);			// 3D Assignment Operator
	bool operator ==(const Ce1nVector3iu &somePOINT3U) const;				// Equality check.
	bool operator !=(const Ce1nVector3iu &somePOINT3U) const;				// Inequality check.
	void print(ostream *os);											// Print function (for debugging to console.);

	// Vector Operations
	void zero();														// Set the vector to zero.
}ePOINT3U;

// Non-Member function definitions:
ostream &operator <<(ostream &os, Ce1nVector3iu &someVect);				// Print operator overload. So we can cout the Point3.

//------------------------------------------------------------------------------
// Ce1nVector3iu - Inline function definitions.
//------------------------------------------------------------------------------

// 3D Assignment Operator
inline Ce1nVector3iu &Ce1nVector3iu::operator =(const Ce1nVector3iu &somePOINT3U)
{
	x = somePOINT3U.x;
	y = somePOINT3U.y;
	z = somePOINT3U.z;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nVector3iu::operator ==(const Ce1nVector3iu &somePOINT3U)
const{
	return  x == somePOINT3U.x && 
			y == somePOINT3U.y && 
			z == somePOINT3U.z;
}

// Inequality check.
inline bool Ce1nVector3iu::operator !=(const Ce1nVector3iu &somePOINT3U)
const{
	return  x != somePOINT3U.x || 
			y != somePOINT3U.y || 
			z != somePOINT3U.z;
}

// Set the vector to zero.
inline void Ce1nVector3iu::zero()
{
	x = 0;
	y = 0;
	z = 0;
}

//==============================================================================
// Ce1nVector3i - A 3d signed integer vector class.
//==============================================================================

typedef class Ce1nVector3i  
{
public:

	short int x;		// The variable for the vector's x component.
	short int y;		// The variable for the vector's y component.
	short int z;		// The variable for the vector's z component.

	// Constructors
	Ce1nVector3i(void);													// Default Constructor
	Ce1nVector3i(const Ce1nVector3i &somePOINT3);						// Copy Constructor
	Ce1nVector3i(const int xVal, const int yVal, const int zVal);		// Initialization list constructor
  	
	// Standard Object Maintenance.
	Ce1nVector3i &operator =(const Ce1nVector3i &somePOINT3);			// 3D Assignment Operator
	bool operator ==(const Ce1nVector3i &somePOINT3) const;				// Equality check.
	bool operator !=(const Ce1nVector3i &somePOINT3) const;				// Inequality check.
	void print(ostream *os);											// Print function (for debugging to console.);

	// Vector Operations
	void zero();														// Set the vector to zero.
}ePOINT3;

// Non-Member function definitions:
ostream &operator <<(ostream &os, Ce1nVector3i &someVect);				// Print operator overload. So we can cout the Point3.

//------------------------------------------------------------------------------
// Ce1nVector3i - Inline function definitions.
//------------------------------------------------------------------------------

// 3D Assignment Operator
inline Ce1nVector3i &Ce1nVector3i::operator =(const Ce1nVector3i &somePOINT3)
{
	x = somePOINT3.x;
	y = somePOINT3.y;
	z = somePOINT3.z;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nVector3i::operator ==(const Ce1nVector3i &somePOINT3)
const{
	return  x == somePOINT3.x && 
			y == somePOINT3.y && 
			z == somePOINT3.z;
}

// Inequality check.
inline bool Ce1nVector3i::operator !=(const Ce1nVector3i &somePOINT3)
const{
	return  x != somePOINT3.x || 
			y != somePOINT3.y || 
			z != somePOINT3.z;
}

// Set the vector to zero.
inline void Ce1nVector3i::zero()
{
	x = 0;
	y = 0;
	z = 0;
}

//==============================================================================
// Ce1nVector3f - A 3d floating point vector class.
//==============================================================================

typedef class Ce1nVector3f  
{
public:

	float x;		// The variable for the vector's x component.
	float y;		// The variable for the vector's y component.
	float z;		// The variable for the vector's z component.

	// Constructors
	Ce1nVector3f(void);															// Default Constructor
	Ce1nVector3f(const Ce1nVector3f &someVect3);								// 3D Copy Constructor
	Ce1nVector3f(const float xVal, const float yVal, const float zVal);			// Initialization list constructor
  	
	// Destructor
	~Ce1nVector3f();

	// Standard Object Maintenance.
	Ce1nVector3f &operator =(const Ce1nVector3f &someVect3);			// 3D Assignment Operator
	bool operator ==(const Ce1nVector3f &someVect3) const;				// Equality check.
	bool operator !=(const Ce1nVector3f &someVect3) const;				// Inequality check.
	void print(ostream *os);											// Print function (for debugging);

	// Vector Operations
	void zero();														// Set the vector to zero.
	Ce1nVector3f operator -() const;									// Unary minus returns the negative of the vector.
	Ce1nVector3f operator +(const Ce1nVector3f &someVect3) const;		// Vector addition.
	Ce1nVector3f operator -(const Ce1nVector3f &someVect3) const;		// Vector subtraction.
	Ce1nVector3f operator *(const float someFloat) const;				// Multiplication by a Scalar.
	Ce1nVector3f operator /(const float someScalar) const;				// Division by a Scalar.
	
	// Combined assignment operators.
	Ce1nVector3f &operator +=(const Ce1nVector3f &someVect3);			// Plus equals.
	Ce1nVector3f &operator -=(const Ce1nVector3f &someVect3);			// Minus equals.
	Ce1nVector3f &operator *=(const float &someScalar);					// Multiply equals.
	Ce1nVector3f &operator /=(const float &someScalar);					// Divide equals.
	
	// Vector math functions.
	void normalize();													// Normalize the vector.
	float operator *(const Ce1nVector3f &someVect) const;				// Vector Dot Product.
}eVECT3;

// Non-member function definitions:
float magnitude(const Ce1nVector3f &someVect3);									// Compute the magnetude of a vector.
Ce1nVector3f crossProduct(const Ce1nVector3f &a, const Ce1nVector3f &b);		// Compute the cross product of two vectors.
inline float distance(const Ce1nVector3f &a, const Ce1nVector3f &b);			// Compute the distance between two points.
ostream &operator <<(ostream &os, Ce1nVector3f &someVect);						// Print operator overload. So we can cout the vector.

//------------------------------------------------------------------------------
// Ce1nVector3f - Inline function definitions.
//------------------------------------------------------------------------------

// 3D Assignment Operator
inline Ce1nVector3f &Ce1nVector3f::operator =(const Ce1nVector3f &someVect3)
{
	x = someVect3.x;
	y = someVect3.y;
	z = someVect3.z;

	return *this;
}

// Equality check.
inline bool Ce1nVector3f::operator ==(const Ce1nVector3f &someVect3)
const{
	return  x == someVect3.x && 
			y == someVect3.y && 
			z == someVect3.z;
}

// Inequality check.
inline bool Ce1nVector3f::operator !=(const Ce1nVector3f &someVect3)
const{
	return  x != someVect3.x || 
			y != someVect3.y || 
			z != someVect3.z;
}

// Set the vector to zero.
inline void Ce1nVector3f::zero()
{
	x = 0.0f;
	y = 0.0f;
	z = 0.0f;
}

// Unary minus returns the negative of the vector.
inline Ce1nVector3f Ce1nVector3f::operator -()
const{
	return Ce1nVector3f(-x, -y, -z);
}

// Vector addition.
inline Ce1nVector3f Ce1nVector3f::operator +(const Ce1nVector3f &someVect3)
const{
	return Ce1nVector3f(x + someVect3.x, y + someVect3.y, z + someVect3.z);
}

// Vector subtraction.
inline Ce1nVector3f Ce1nVector3f::operator -(const Ce1nVector3f &someVect3)
const{
	return Ce1nVector3f(x - someVect3.x, y - someVect3.y, z - someVect3.z);
}

// Multiplication by a Scalar.
inline Ce1nVector3f Ce1nVector3f::operator *(const float someFloat)
const{
	return Ce1nVector3f(x * someFloat, y * someFloat, z * someFloat);
}

// Division by a Scalar.
inline Ce1nVector3f Ce1nVector3f::operator /(const float someScalar)
const{
	float divMult = 1.0f / someScalar;							// Multiplication is faster on x86 than division.

	return Ce1nVector3f(x * divMult, y * divMult, z * divMult);
}

// Plus equals.
inline Ce1nVector3f &Ce1nVector3f::operator +=(const Ce1nVector3f &someVect3)
{
	x += someVect3.x;
	y += someVect3.y;
	z += someVect3.z;

	return *this;		
}

// Minus equals.
inline Ce1nVector3f &Ce1nVector3f::operator -=(const Ce1nVector3f &someVect3)
{
	x -= someVect3.x;
	y -= someVect3.y;
	z -= someVect3.z;

	return *this;
}

// Multiply equals.
inline Ce1nVector3f &Ce1nVector3f::operator *=(const float &someScalar)
{
	x *= someScalar;
	y *= someScalar;
	z *= someScalar;

	return *this;
}

// Divide equals.
inline Ce1nVector3f &Ce1nVector3f::operator /=(const float &someScalar)
{
	float divMult = 1.0f / someScalar;

	x *= divMult;
	y *= divMult;
	z *= divMult;

	return *this;
}

// Normalize the vector.
inline void Ce1nVector3f::normalize()
{
	float magSq = (x * x) + (y * y) + (z * z);

	if (magSq > 0.0f)		// Check for divide by zero.
	{
		float divMult = 1.0f / sqrt(magSq);

		x *= divMult;
		y *= divMult;
		z *= divMult;
	}
}

// Vector Dot Product.
inline float Ce1nVector3f::operator *(const Ce1nVector3f &someVect)
const{
	return (x * someVect.x) + (y * someVect.y) + (z * someVect.z);
}

//------------------------------------------------------------------------------
// Ce1nVector3f - Non-Member inline functions.
//------------------------------------------------------------------------------

// Compute the magnetude of a vector.
inline float magnitude(const Ce1nVector3f &someVect3)
{
	return sqrt((someVect3.x * someVect3.x) + (someVect3.y * someVect3.y) + (someVect3.z * someVect3.z));
}

// Compute the cross product of two vectors.
inline Ce1nVector3f crossProduct(const Ce1nVector3f &a, const Ce1nVector3f &b)
{
	return Ce1nVector3f((a.y * b.z) - (a.z * b.y),
					(a.z * b.x) - (a.x * b.z),
					(a.x * b.y) - (a.y * b.x));
}

// Compute the distance between two points.
inline float distance(const Ce1nVector3f &a, const Ce1nVector3f &b)
{
	float dx = a.x - b.x;
	float dy = a.y - b.y;
	float dz = a.z - b.z;

	return sqrt((dx * dx) + (dy * dy) + (dz * dz));
}

//==============================================================================
// Ce1nColorRGBf - A floating point RGB Color class.
//==============================================================================

typedef class Ce1nColorRGBf
{
public:

	float r;		// Variable to store the color's red component.
	float g;		// Variable to store the color's green component.
	float b;		// Variable to store the color's blue component.

	// Constructors:												
	
	Ce1nColorRGBf();															// Default constructor.
	Ce1nColorRGBf(const float rVal, const float gVal, const float bVal);		// Float initialization list constructor.

	// Destructor
	~Ce1nColorRGBf();

	// Standard object maintenance:
	Ce1nColorRGBf &operator =(const Ce1nColorRGBf &someColor);				// Assignment Operator
	Ce1nColorRGBf  operator +(const Ce1nColorRGBf &someColor) const;		// Color addition.
	Ce1nColorRGBf  operator -(const Ce1nColorRGBf &someColor) const;		// Color subtraction.
	Ce1nColorRGBf  operator +(const float &someFloat) const;				// Scalar addition.
	Ce1nColorRGBf  operator -(const float &someFloat) const;				// Scalar subtraction.
	Ce1nColorRGBf  operator *(const float &someFloat) const;				// Scalar multiplication.
	Ce1nColorRGBf  operator /(const float &someFloat) const;				// Scalar division.
	bool operator ==(const Ce1nColorRGBf &someColor)const;					// Equality check.
	bool operator !=(const Ce1nColorRGBf &someColor)const;					// Inequality check.
	void print(ostream *os);												// Print function (for debugging);
}eRGBf;

// Non-Member Functions.
ostream &operator <<(ostream &os, eRGBf &someColor);				// Print operator overload. So we can cout the color.


//------------------------------------------------------------------------------
// Ce1nColorRGBf - Inline member function definitions.
//------------------------------------------------------------------------------

// Assignment Operator
inline Ce1nColorRGBf &Ce1nColorRGBf::operator =(const Ce1nColorRGBf &someColor)
{
	r = someColor.r;
	g = someColor.g;
	b = someColor.b;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nColorRGBf::operator ==(const Ce1nColorRGBf &someColor)
const{
	return  r == someColor.r && 
			g == someColor.g && 
			b == someColor.b;
}

// Inequality check.
inline bool Ce1nColorRGBf::operator !=(const Ce1nColorRGBf &someColor)
const{
	return  r != someColor.r || 
			g != someColor.g || 
			b != someColor.b;
}

// Color Addition.
inline Ce1nColorRGBf Ce1nColorRGBf::operator +(const Ce1nColorRGBf &someColor)
const{
	return Ce1nColorRGBf(r + someColor.r, g + someColor.g, b + someColor.b);
}

// Color Subtraction.
inline Ce1nColorRGBf Ce1nColorRGBf::operator -(const Ce1nColorRGBf &someColor)
const{
	return Ce1nColorRGBf(r - someColor.r, g - someColor.g, b - someColor.b);
}

// Scalar Addition.
inline Ce1nColorRGBf Ce1nColorRGBf::operator +(const float &someFloat)
const{
	return Ce1nColorRGBf(r + someFloat, g + someFloat, b + someFloat);
}

// Scalar Subtraction.
inline Ce1nColorRGBf Ce1nColorRGBf::operator -(const float &someFloat)
const{
	return Ce1nColorRGBf(r - someFloat, g - someFloat, b - someFloat);
}

// Scalar Multiplication.
inline Ce1nColorRGBf Ce1nColorRGBf::operator *(const float &someFloat)
const{
	return Ce1nColorRGBf(r * someFloat, g * someFloat, b * someFloat);
}

// Scalar Division.
inline Ce1nColorRGBf Ce1nColorRGBf::operator /(const float &someFloat)
const{
	return Ce1nColorRGBf(r / someFloat, g / someFloat, b / someFloat);
}

//==============================================================================
// Ce1nColorRGBAf - A floating point RGBA (A for Alpha) Color class.
//==============================================================================

typedef class Ce1nColorRGBAf
{
public:

	float r;		// Variable to store the color's red component.
	float g;		// Variable to store the color's green component.
	float b;		// Variable to store the color's blue component.
	float a;		// Variable to store the color's alpha component.
		
	// Constructors:												
	
	Ce1nColorRGBAf();																			// Default constructor.
	Ce1nColorRGBAf(const float rVal, const float gVal, const float bVal, const float aVal);		// Float initialization list constructor.

	// Destructor
	~Ce1nColorRGBAf();

	// Standard object maintenance:
	Ce1nColorRGBAf &operator =(const Ce1nColorRGBAf &someColor);			// Assignment Operator
	Ce1nColorRGBAf  operator +(const Ce1nColorRGBAf &someColor) const;		// Color addition.
	Ce1nColorRGBAf  operator -(const Ce1nColorRGBAf &someColor) const;		// Color subtraction.
	Ce1nColorRGBAf  operator +(const float &someFloat) const;				// Scalar addition.
	Ce1nColorRGBAf  operator -(const float &someFloat) const;				// Scalar subtraction.
	Ce1nColorRGBAf  operator *(const float &someFloat) const;				// Scalar multiplication.
	Ce1nColorRGBAf  operator /(const float &someFloat) const;				// Scalar division.
	bool operator ==(const Ce1nColorRGBAf &someColor)const;					// Equality check.
	bool operator !=(const Ce1nColorRGBAf &someColor)const;					// Inequality check.
	void print(ostream *os);												// Print function (for debugging);
}eRGBAf;	

// Non-Member Functions.
ostream &operator <<(ostream &os, eRGBAf &someColor);			// Print operator overload. So we can cout the color.


//------------------------------------------------------------------------------
// Ce1nColorRGBAf - Inline member function definitions.
//------------------------------------------------------------------------------

// Assignment Operator
inline Ce1nColorRGBAf &Ce1nColorRGBAf::operator =(const Ce1nColorRGBAf &someColor)
{
	r = someColor.r;
	g = someColor.g;
	b = someColor.b;
	a = someColor.a;

	return *this;		// Returns an lvalue reference (C++ standard).
}

// Equality check.
inline bool Ce1nColorRGBAf::operator ==(const Ce1nColorRGBAf &someColor)
const{
	return  r == someColor.r && 
			g == someColor.g && 
			b == someColor.b &&
			a == someColor.a;
}

// Inequality check.
inline bool Ce1nColorRGBAf::operator !=(const Ce1nColorRGBAf &someColor)
const{
	return  r != someColor.r || 
			g != someColor.g || 
			b != someColor.b ||
			a != someColor.a;
}

// Color Addition.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator +(const Ce1nColorRGBAf &someColor)
const{
	return Ce1nColorRGBAf(r + someColor.r, g + someColor.g, b + someColor.b, a);
}

// Color Subtraction.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator -(const Ce1nColorRGBAf &someColor)
const{
	return Ce1nColorRGBAf(r - someColor.r, g - someColor.g, b - someColor.b, a);
}

// Scalar Addition.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator +(const float &someFloat)
const{
	return Ce1nColorRGBAf(r + someFloat, g + someFloat, b + someFloat, a);
}

// Scalar Subtraction.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator -(const float &someFloat)
const{
	return Ce1nColorRGBAf(r - someFloat, g - someFloat, b - someFloat, a);
}

// Scalar Multiplication.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator *(const float &someFloat)
const{
	return Ce1nColorRGBAf(r * someFloat, g * someFloat, b * someFloat, a);
}

// Scalar Division.
inline Ce1nColorRGBAf Ce1nColorRGBAf::operator /(const float &someFloat)
const{
	return Ce1nColorRGBAf(r / someFloat, g / someFloat, b / someFloat, a);
}