#include "stdafx.h"
#include "e1nInputDI8.h"

//----------------------------------------------------------------------
// Non-Member Functions
//----------------------------------------------------------------------

// This function creates the e1nInput object for DirectInput and returns a pointer to it.
//eINPUTDEVICE* e1nInputCreate(HINSTANCE		p_hInstance,			// Pointer to main application instance.
//							 HWND			p_hWndMain,				// Pointer to the main application window handle.
//							 EI_INTERFACE	eiInterface,			// Implementation to use. EI_DIRECTINPUT8 is the only choice so far.
//							 EI_INTERFACE   eiJoyInterface) 		// Joystick Implementation to use. EI_XIJOY (XBOX 360 Controllers) is the only choice so far.
//{
//	eINPUTDEVICE* tempPtr;
//	tempPtr = new Ce1nInputDI8(p_hInstance, p_hWndMain, false);
//	return tempPtr;
//}