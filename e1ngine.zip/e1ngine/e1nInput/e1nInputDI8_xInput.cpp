#include "StdAfx.h"
#include "e1nInput.h"
#include "e1nInputDI8.h"

// Constants for this Class:
#define XINPUT_JOYAXIS_LORANGE -32768
#define XINPUT_JOYAXIS_HIRANGE	32767
#define XINPUT_JOYTRIGGER_RANGE 255

//============================================================
// Nested Joystick Class Functions (XInput):
//============================================================

// Constructor
Ce1nInputDI8::Ce1nInputJoysticksXI::Ce1nInputJoysticksXI()
{
	// Ok, first we zero out the previous XInput states.
	ZeroMemory(xiStates, sizeof(EIXI_CONTROLLER_STATE) * MAX_EIJOYS);
}

// Destructor
Ce1nInputDI8::Ce1nInputJoysticksXI::~Ce1nInputJoysticksXI()
{
	// Do nothing
}

bool Ce1nInputDI8::Ce1nInputJoysticksXI::Aquire(void)
{
	return true;
}

bool Ce1nInputDI8::Ce1nInputJoysticksXI::Unaquire(void)
{
	return true;
}

bool Ce1nInputDI8::Ce1nInputJoysticksXI::Update()
{
	// Then we read the current XInput states.	
	DWORD readResult;
	UINT  numConnected = 0;

	for(UINT i = 0; i < MAX_EIJOYS; i++)
	{
		// Copy the current controller state to the last state.
		xiStates[i].joyStateLast = xiStates[i].joyState;

		// Get the state of the current controller from XInput.
		readResult = XInputGetState(i, &xiStates[i].joyState);
		
		// Update the wasConnected variable so that we can detect when joysticks get unplugged.
		xiStates[i].wasConnected = xiStates[i].isConnected;

		if(readResult == ERROR_SUCCESS)
		{
			numConnected += 1;
			xiStates[i].isConnected = true;
		}
		else
		{
			xiStates[i].isConnected = false;
		}
	}

	if (numConnected == 0){return false;}
	else				  {return true;}

	return true;
}

//----------------------------------------------------------------------
// JoystickIsActive Function
//
// This function returns true if the selected joystick is connected.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::JoystickIsActive (EI_JOYENUM someJoy)
{
	return xiStates[someJoy].isConnected;
}

//----------------------------------------------------------------------
// JoystickWasActive Function
//
// This function returns true if the selected joystick was connected
// during the last update.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::JoystickWasActive(EI_JOYENUM someJoy)
{
	return xiStates[someJoy].wasConnected;
}

//----------------------------------------------------------------------
// ButtonIsDown Function
//
// This function returns true if the selected button is currently 
// pressed.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::ButtonIsDown (EI_JOYENUM someJoy, EI_JOYBUTTON someButton)
{
	// The button tests:
	if (someButton & EI_JOYBUTTON_A)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_A)			 {return true;}}
	if (someButton & EI_JOYBUTTON_B)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_B)			 {return true;}}
	if (someButton & EI_JOYBUTTON_X)	    {if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_X)			 {return true;}}
	if (someButton & EI_JOYBUTTON_Y)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_Y)			 {return true;}}
	if (someButton & EI_JOYBUTTON_LB)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) {return true;}}
	if (someButton & EI_JOYBUTTON_RB)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER){return true;}}
	if (someButton & EI_JOYBUTTON_BACK)		{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_BACK)			 {return true;}}
	if (someButton & EI_JOYBUTTON_START)	{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_START)		 {return true;}}
	if (someButton & EI_JOYBUTTON_LTHUMB)	{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB)	 {return true;}}
	if (someButton & EI_JOYBUTTON_RTHUMB)	{if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB)	 {return true;}}
	
	// The D-Pad Tests:
	if (someButton & EI_JOYPOV_UP)			
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)) 
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPRIGHT)		
	{
		if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
		xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_RIGHT)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNRIGHT)	
	{
		if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) &&
             (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_DOWN)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)) 
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNLEFT)	
	{
		if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) &&
             (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))	 
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_LEFT)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)	
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)) 
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPLEFT)		
	{
		if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
			 (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))	 
		{
			return true;
		}
	}
	if (someButton & EI_JOYBUTTON_LTRIGGER)
	{
		if (xiStates[someJoy].joyState.Gamepad.bLeftTrigger  > 0) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RTRIGGER)
	{
		if (xiStates[someJoy].joyState.Gamepad.bRightTrigger > 0) {return true;}
	}

	// If no matches:
	return false;
}

//----------------------------------------------------------------------
// ButtonWasDown Function
//
// This function returns true if the selected button is currently
// NOT pressed AND was pressed in the previous update.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::ButtonWasDown(EI_JOYENUM someJoy, EI_JOYBUTTON someButton)
{
	if (someButton & EI_JOYBUTTON_A)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_A) &&
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_A)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_B)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_B) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_B)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_X)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_X) &&
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_X)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_Y)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_Y) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_Y)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_LB)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) &&
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RB)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_BACK)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) &&
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_BACK)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_START)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_START) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_START)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_LTHUMB)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB) &&
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RTHUMB)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB)) {return true;}
	}
	if (someButton & EI_JOYPOV_UP)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) 
		{
			if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) &&
				!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPRIGHT)
	{
		if (((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) &&
		   ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))) 
		{return true;}
	}
	if (someButton & EI_JOYPOV_RIGHT)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)) 
		{
			if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNRIGHT)
	{
		if (((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)) &&
		   ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))) 
		{return true;}
	}
	if (someButton & EI_JOYPOV_DOWN)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
		{
			if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) &&
				!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNLEFT)
	{
		if (((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)) &&
		   ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))) 
		{return true;}
	}
	if (someButton & EI_JOYPOV_LEFT)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && 
		   !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)) 
		{
			if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPLEFT)
	{
		if (((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) &&
		   ((xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))) 
		{return true;}
	}
	if (someButton & EI_JOYBUTTON_LTRIGGER)
	{
		if ((xiStates[someJoy].joyState.Gamepad.bLeftTrigger == 0) && (xiStates[someJoy].joyStateLast.Gamepad.bLeftTrigger  > 0))
		{
			return true;
		}
	}
	if (someButton & EI_JOYBUTTON_RTRIGGER)
	{
		if ((xiStates[someJoy].joyState.Gamepad.bRightTrigger == 0) && (xiStates[someJoy].joyStateLast.Gamepad.bRightTrigger > 0))
		{
			return true;
		}
	}
	return false;
}

//----------------------------------------------------------------------
// ButtonIsUp Function
//
// This function returns true if the selected button is NOT currently
// pressed.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::ButtonIsUp   (EI_JOYENUM someJoy, EI_JOYBUTTON someButton)
{
	// The button tests:
	if (someButton & EI_JOYBUTTON_A)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_A))				 {return true;}}
	if (someButton & EI_JOYBUTTON_B)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_B))				 {return true;}}
	if (someButton & EI_JOYBUTTON_X)	    {if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_X))				 {return true;}}
	if (someButton & EI_JOYBUTTON_Y)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_Y))				 {return true;}}
	if (someButton & EI_JOYBUTTON_LB)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER))  {return true;}}
	if (someButton & EI_JOYBUTTON_RB)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER)) {return true;}}
	if (someButton & EI_JOYBUTTON_BACK)		{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_BACK))			 {return true;}}
	if (someButton & EI_JOYBUTTON_START)	{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_START))			 {return true;}}
	if (someButton & EI_JOYBUTTON_LTHUMB)	{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB))	 {return true;}}
	if (someButton & EI_JOYBUTTON_RTHUMB)	{if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB))	 {return true;}}
	
	// The D-Pad Tests:
	if (someButton & EI_JOYPOV_UP)			
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)
		{
			if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) || (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))
			{
				return true;
			}
		}
		else if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_UPRIGHT)		
	{
		if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) ||
		    !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_RIGHT)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)
		{
			if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) || (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
		else if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_DOWNRIGHT)	
	{
		if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) &&
            !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_DOWN)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)
		{
			if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) || (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))
			{
				return true;
			}
		}
		else if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_DOWNLEFT)	
	{
		if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) &&
            !(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))	 
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_LEFT)		
	{
		if (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)
		{
			if ((xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) || (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
		else if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_UPLEFT)		
	{
		if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
			!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))	 
		{
			return true;
		}
	}
	if (someButton & EI_JOYBUTTON_LTRIGGER)
	{
		if (xiStates[someJoy].joyState.Gamepad.bLeftTrigger  == 0) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RTRIGGER)
	{
		if (xiStates[someJoy].joyState.Gamepad.bRightTrigger == 0) {return true;}
	}

	return false;
}

//----------------------------------------------------------------------
// ButtonWasUp Function
//
// This function returns true if the selected button is currently
// down AND was not down in the previous update.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputJoysticksXI::ButtonWasUp  (EI_JOYENUM someJoy, EI_JOYBUTTON someButton)
{
if (someButton & EI_JOYBUTTON_A)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_A) &&
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_A)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_B)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_B) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_B)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_X)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_X) &&
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_X)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_Y)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_Y) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_Y)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_LB)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) &&
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RB)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_BACK)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) &&
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_BACK)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_START)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_START) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_START)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_LTHUMB)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB) &&
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB)) {return true;}
	}
	if (someButton & EI_JOYBUTTON_RTHUMB)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB)) {return true;}
	}

	// And now for the D-Pad checks:
	if (someButton & EI_JOYPOV_UP)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) 
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPRIGHT)
	{
		if ((!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)    && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) &&
		    (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))) 
		{
			return true;
		}
	}
	if (someButton & EI_JOYPOV_RIGHT)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)) 
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNRIGHT)
	{
		if ((!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)  && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)) &&
		    (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))) 
		{return true;}
	}
	if (someButton & EI_JOYPOV_DOWN)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_DOWNLEFT)
	{
		if ((!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)) &&
		    (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))) 
		{return true;}
	}
	if (someButton & EI_JOYPOV_LEFT)
	{
		if (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && 
		     (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)) 
		{
			if (!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) &&
				!(xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN))
			{
				return true;
			}
		}
	}
	if (someButton & EI_JOYPOV_UPLEFT)
	{
		if ((!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)   && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) &&
		    (!(xiStates[someJoy].joyStateLast.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && (xiStates[someJoy].joyState.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT))) 
		{return true;}
	}
	if (someButton & EI_JOYBUTTON_LTRIGGER)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.bLeftTrigger == 0) && (xiStates[someJoy].joyState.Gamepad.bLeftTrigger  > 0))
		{
			return true;
		}
	}
	if (someButton & EI_JOYBUTTON_RTRIGGER)
	{
		if ((xiStates[someJoy].joyStateLast.Gamepad.bRightTrigger == 0) && (xiStates[someJoy].joyState.Gamepad.bRightTrigger > 0))
		{
			return true;
		}
	}
	return false;
}

bool Ce1nInputDI8::Ce1nInputJoysticksXI::AxisIsActive (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)
{
	float axisVal = 0.0f;

	// Get the data:
	switch (someAxis)
	{
	case EI_JOYAXIS_LX:
		{
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLX;

			if (axisVal > 0) {axisVal /= 32767.0f;}
			else			 {axisVal /= 32768.0f;}

			break;
		}
	case EI_JOYAXIS_LY:
		{
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLY;

			if (axisVal > 0) {axisVal /= 32767.0f;}
			else			 {axisVal /= 32768.0f;}

			break;
		}
	case EI_JOYAXIS_RX:
		{
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRX;

			if (axisVal > 0) {axisVal /= 32767.0f;}
			else			 {axisVal /= 32768.0f;}

			break;
		}
	case EI_JOYAXIS_RY:
		{	
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRY;

			if (axisVal > 0) {axisVal /= 32767.0f;}
			else			 {axisVal /= 32768.0f;}

			break;
		}
	case EI_JOYAXIS_LTRIGGER:
		{
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.bLeftTrigger;
			axisVal /= 255.0f;

			break;
		}
	case EI_JOYAXIS_RTRIGGER:
		{
			axisVal = (float)xiStates[someJoy].joyState.Gamepad.bRightTrigger;
			axisVal /= 255.0f;

			break;
		}
	}

	if (fabs(axisVal) > EI_JOY_DEADZONE) {return true;}

	return false;
}

bool Ce1nInputDI8::Ce1nInputJoysticksXI::AxisWasActive(EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)
{
	float axisVal;

	// Get the data:
	switch (someAxis)
	{
	case EI_JOYAXIS_LX:
		{
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.sThumbLX;
		}
	case EI_JOYAXIS_LY:
		{
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.sThumbLY;
		}
	case EI_JOYAXIS_RX:
		{
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.sThumbRX;
		}
	case EI_JOYAXIS_RY:
		{	
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.sThumbRY;
		}
	case EI_JOYAXIS_LTRIGGER:
		{
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.bLeftTrigger;
		}
	case EI_JOYAXIS_RTRIGGER:
		{
			axisVal = (float)xiStates[someJoy].joyStateLast.Gamepad.bRightTrigger;
		}
	}

	// Test the data:
	if (axisVal > 0) {axisVal /= 32767.0f;}
	else			 {axisVal /= 32768.0f;}

	if (fabs(axisVal) > EI_JOY_DEADZONE) {return true;}

	return false;
}

float Ce1nInputDI8::Ce1nInputJoysticksXI::GetAxisValue (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)
{
	switch (someAxis)
	{
	case EI_JOYAXIS_LX:
		{
			float xAxisVal;
			float yAxisVal;
			float dzAdj;
			float deadZone;

			// First we grab the raw axis values from the XINPUT driver.
			xAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLX;
			yAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLY;
	
			// Now, because we will be reducing the x-axis deadzone based upon the absolute value of the
			// joystick on the y-axis, we need to convert the y-axis value to a number between zero
			// and 1.0. 
			if		(yAxisVal < 0.0f) {yAxisVal /= XINPUT_JOYAXIS_LORANGE;}
			else if (yAxisVal > 0.0f) {yAxisVal /= XINPUT_JOYAXIS_HIRANGE;}

			// If the y-axis is zero, our deadzone multiplier will be 1.0, while if the y-axis is at 1.0,
			// our deadzone multiplier will be zero. This will give us a deadzone with a linear falloff
			// to zero at the extreme value of the y-axis. Multiplying that number to a power then gives
			// a curve that gets more biased torwards zero the closer we get to the extremes of the y-axis.
			dzAdj    = 1.0f - (float)fabs(yAxisVal);
			dzAdj    = pow(dzAdj, 2.8f);
			deadZone = (float)EI_JOY_DEADZONE * dzAdj;

			// Then we evaluate and convert the x-axis number to something between -1.0 and 1.0.
			if (xAxisVal < (XINPUT_JOYAXIS_LORANGE * deadZone))
			{
				xAxisVal -= (float)XINPUT_JOYAXIS_LORANGE * deadZone;
				xAxisVal /= -(XINPUT_JOYAXIS_LORANGE - ((float)XINPUT_JOYAXIS_LORANGE * deadZone));

				return xAxisVal;
			}
			else if(xAxisVal > (XINPUT_JOYAXIS_HIRANGE * deadZone))
			{
				xAxisVal -= (float)XINPUT_JOYAXIS_HIRANGE * deadZone;
				xAxisVal /= XINPUT_JOYAXIS_HIRANGE - ((float)XINPUT_JOYAXIS_HIRANGE * deadZone);

				return xAxisVal;
			}
			else
			{
				return 0.0f;
			}
		}
	case EI_JOYAXIS_LY:
		{
			float xAxisVal;
			float yAxisVal;
			float dzAdj;
			float deadZone;

			// First we grab the raw axis values from the XINPUT driver.
			xAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLX;
			yAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbLY;
	
			// Now, because we will be reducing the y-axis deadzone based upon the absolute value of the
			// joystick on the x-axis, we need to convert the x-axis value to a number between zero
			// and 1.0. 
			if		(xAxisVal < 0.0f) {xAxisVal /= XINPUT_JOYAXIS_LORANGE;}
			else if (xAxisVal > 0.0f) {xAxisVal /= XINPUT_JOYAXIS_HIRANGE;}

			// If the x-axis is zero, our deadzone multiplier will be 1.0, while if the x-axis is at 1.0,
			// our deadzone multiplier will be zero. This will give us a deadzone with a linear falloff
			// to zero at the extreme value of the x-axis. Multiplying that number to a power then gives
			// a curve that gets more biased torwards zero the closer we get to the extremes of the x-axis.
			dzAdj    = 1.0f - (float)fabs(xAxisVal);
			dzAdj    = pow(dzAdj, 2.8f);
			deadZone = (float)EI_JOY_DEADZONE * dzAdj;

			// Then we evaluate and convert the x-axis number to something between -1.0 and 1.0.
			if (yAxisVal < (XINPUT_JOYAXIS_LORANGE * deadZone))
			{
				yAxisVal -= (float)XINPUT_JOYAXIS_LORANGE * deadZone;
				yAxisVal /= -(XINPUT_JOYAXIS_LORANGE - ((float)XINPUT_JOYAXIS_LORANGE * deadZone));

				return yAxisVal;
			}
			else if(yAxisVal > (XINPUT_JOYAXIS_HIRANGE * deadZone))
			{
				yAxisVal -= (float)XINPUT_JOYAXIS_HIRANGE * deadZone;
				yAxisVal /= XINPUT_JOYAXIS_HIRANGE - ((float)XINPUT_JOYAXIS_HIRANGE * deadZone);

				return yAxisVal;
			}
			else
			{
				return 0.0f;
			}
		}
	case EI_JOYAXIS_RX:
		{
			float xAxisVal;
			float yAxisVal;
			float dzAdj;
			float deadZone;

			// First we grab the raw axis values from the XINPUT driver.
			xAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRX;
			yAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRY;
	
			// Now, because we will be reducing the x-axis deadzone based upon the absolute value of the
			// joystick on the y-axis, we need to convert the y-axis value to a number between zero
			// and 1.0. 
			if		(yAxisVal < 0.0f) {yAxisVal /= XINPUT_JOYAXIS_LORANGE;}
			else if (yAxisVal > 0.0f) {yAxisVal /= XINPUT_JOYAXIS_HIRANGE;}

			// If the y-axis is zero, our deadzone multiplier will be 1.0, while if the y-axis is at 1.0,
			// our deadzone multiplier will be zero. This will give us a deadzone with a linear falloff
			// to zero at the extreme value of the y-axis. Multiplying that number to a power then gives
			// a curve that gets more biased torwards zero the closer we get to the extremes of the y-axis.
			dzAdj    = 1.0f - (float)fabs(yAxisVal);
			dzAdj    = pow(dzAdj, 2.8f);
			deadZone = (float)EI_JOY_DEADZONE * dzAdj;

			// Then we evaluate and convert the x-axis number to something between -1.0 and 1.0.
			if (xAxisVal < (XINPUT_JOYAXIS_LORANGE * deadZone))
			{
				xAxisVal -= (float)XINPUT_JOYAXIS_LORANGE * deadZone;
				xAxisVal /= -(XINPUT_JOYAXIS_LORANGE - ((float)XINPUT_JOYAXIS_LORANGE * deadZone));

				return xAxisVal;
			}
			else if(xAxisVal > (XINPUT_JOYAXIS_HIRANGE * deadZone))
			{
				xAxisVal -= (float)XINPUT_JOYAXIS_HIRANGE * deadZone;
				xAxisVal /= XINPUT_JOYAXIS_HIRANGE - ((float)XINPUT_JOYAXIS_HIRANGE * deadZone);

				return xAxisVal;
			}
			else
			{
				return 0.0f;
			}
		}
	case EI_JOYAXIS_RY:
		{
			float xAxisVal;
			float yAxisVal;
			float dzAdj;
			float deadZone;

			// First we grab the raw axis values from the XINPUT driver.
			xAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRX;
			yAxisVal = (float)xiStates[someJoy].joyState.Gamepad.sThumbRY;
	
			// Now, because we will be reducing the y-axis deadzone based upon the absolute value of the
			// joystick on the x-axis, we need to convert the x-axis value to a number between zero
			// and 1.0. 
			if		(xAxisVal < 0.0f) {xAxisVal /= XINPUT_JOYAXIS_LORANGE;}
			else if (xAxisVal > 0.0f) {xAxisVal /= XINPUT_JOYAXIS_HIRANGE;}

			// If the x-axis is zero, our deadzone multiplier will be 1.0, while if the x-axis is at 1.0,
			// our deadzone multiplier will be zero. This will give us a deadzone with a linear falloff
			// to zero at the extreme value of the x-axis. Multiplying that number to a power then gives
			// a curve that gets more biased torwards zero the closer we get to the extremes of the x-axis.
			dzAdj    = 1.0f - (float)fabs(xAxisVal);
			dzAdj    = pow(dzAdj, 2.8f);
			deadZone = (float)EI_JOY_DEADZONE * dzAdj;

			// Then we evaluate and convert the x-axis number to something between -1.0 and 1.0.
			if (yAxisVal < (XINPUT_JOYAXIS_LORANGE * deadZone))
			{
				yAxisVal -= (float)XINPUT_JOYAXIS_LORANGE * deadZone;
				yAxisVal /= -(XINPUT_JOYAXIS_LORANGE - ((float)XINPUT_JOYAXIS_LORANGE * deadZone));

				return yAxisVal;
			}
			else if(yAxisVal > (XINPUT_JOYAXIS_HIRANGE * deadZone))
			{
				yAxisVal -= (float)XINPUT_JOYAXIS_HIRANGE * deadZone;
				yAxisVal /= XINPUT_JOYAXIS_HIRANGE - ((float)XINPUT_JOYAXIS_HIRANGE * deadZone);

				return yAxisVal;
			}
			else
			{
				return 0.0f;
			}
		}
	case EI_JOYAXIS_LTRIGGER:
		{
			float axisVal;

			axisVal = (float)xiStates[someJoy].joyState.Gamepad.bLeftTrigger / (float)XINPUT_JOYTRIGGER_RANGE;
			
			return axisVal;
		}
	case EI_JOYAXIS_RTRIGGER:
		{
			float axisVal;

			axisVal = (float)xiStates[someJoy].joyState.Gamepad.bRightTrigger / (float)XINPUT_JOYTRIGGER_RANGE;
			
			return axisVal;
		}
	}
	return 0;
}

UINT Ce1nInputDI8::Ce1nInputJoysticksXI::GetNumAttachedJoysticks(void)
{
	UINT numJoys = 0;

	for (UINT i = 0; i < 4; i++)
	{
		if (xiStates[i].isConnected){numJoys += 1;}
	}
	return numJoys;
}

UINT Ce1nInputDI8::Ce1nInputJoysticksXI::GetJoyName(EI_JOYENUM whichJoy, char* outString)
{
	if (xiStates[whichJoy].isConnected)
	{
		outString = "XBOX 360 Gamepad";
	}
	else
	{
		outString = "Unconnected";
	}
	return 0;
}


