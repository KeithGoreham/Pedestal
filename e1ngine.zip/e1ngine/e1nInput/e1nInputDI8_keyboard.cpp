#include "StdAfx.h"
#include "e1nInput.h"
#include "e1nInputDI8.h"

// Global Variables:
extern HWND				gp_appWinHandle;
extern LPDIRECTINPUT8	gp_dInput;

//============================================================
// Nested Keyboard Class Functions:
//============================================================

// Constructor:
Ce1nInputDI8::Ce1nInputKeyboardDI8::Ce1nInputKeyboardDI8(void)
{
	// Initialize the Keyboard.
	Ce1nInputDI8::Ce1nInputKeyboardDI8::Init();

	// Aquire the Keyboard.
	Ce1nInputDI8::Ce1nInputKeyboardDI8::Aquire();

	// Ok, first we zero out the memory for the keystates.
	ZeroMemory(curKeyState, sizeof(DI_KEYSTATE));
	ZeroMemory(lastKeyState, sizeof(DI_KEYSTATE));
}

// Destructor:
Ce1nInputDI8::Ce1nInputKeyboardDI8::~Ce1nInputKeyboardDI8(void)
{
	// Unaquire the keyboard
	Ce1nInputDI8::Ce1nInputKeyboardDI8::Unaquire();

	// Release the keyboard
	if (p_keyboard != NULL) {p_keyboard->Release();}
}

//----------------------------------------------------------------------
// This function initializes the keyboard.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::Init(void)
{
	HRESULT hr;			// Result variable for error catching.

	// Create a keyboard object:
	hr = gp_dInput->CreateDevice(GUID_SysKeyboard, &p_keyboard, NULL); 
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not create Keyboard.\n");
		return false; 
	}

	// Set the keyboard cooperation level:
	hr = p_keyboard->SetCooperativeLevel(gp_appWinHandle, DISCL_FOREGROUND | DISCL_EXCLUSIVE);
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not set keyboard cooperation level.\n");
		return false;
	}

	// Set the keyboard data format:
	hr = p_keyboard->SetDataFormat(&c_dfDIKeyboard);
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not set keyboard data format.\n");
		return false;
	}

	// Aquire the keyboard device:
	hr = p_keyboard->Acquire();
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not Aquire Keyboard.\n");
		return false;
	}

    return true;
}

//----------------------------------------------------------------------
// This function aquires the keyboard.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::Aquire(void)
{
	HRESULT hr;

	if (p_keyboard != NULL) 
	{
		hr = p_keyboard->Acquire();					// Aquire Keyboard.

		if (FAILED(hr))
		{
			OutputDebugString("ERROR! - Could not Aquire Keyboard.\n");
			return false;
		}
	}

	return true;
}

//----------------------------------------------------------------------
// This function unaquires the keyboard.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::Unaquire(void)
{
	if (p_keyboard != NULL) 
	{
		p_keyboard->Unacquire();
	}
	return true;
}

//----------------------------------------------------------------------
// This function updates the current keyboard state. It also copies the
// last keyboard state so that we can compare the two.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::Update(void)
{
	HRESULT hr;

	// Copy the current key state to replace the last key state.
	for (UINT i = 0; i < 256; i++)
	{
		lastKeyState[i] = curKeyState[i];
	}

	// Grab the current state for all keys on the keyboard.
	hr = p_keyboard->GetDeviceState(sizeof(curKeyState), curKeyState);

	if (FAILED(hr))		// If we didn't get the data...
	{
		switch(hr)
		{
		case DIERR_INPUTLOST:
			p_keyboard->Acquire();
			p_keyboard->GetDeviceState(sizeof(curKeyState), curKeyState);
			break;
		case DIERR_NOTACQUIRED:
			p_keyboard->Acquire();
			p_keyboard->GetDeviceState(sizeof(curKeyState), curKeyState);
			break;
		case DIERR_NOTINITIALIZED:
			Init();
			p_keyboard->Acquire();
			break;
		}
	}
	return true;
}

//----------------------------------------------------------------------
// This function returns true if the selected key is currently pressed.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::KeyIsDown(EI_KEY someKey)
{
	return (curKeyState[someKey] & 0x80);
}

//----------------------------------------------------------------------
// This function returns true if the selected key is currently pressed
// AND was not pressed during the last keyboard update.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::KeyWasDown(EI_KEY someKey)
{
	return (!(curKeyState[someKey] & 0x80) && (lastKeyState[someKey] & 0x80));
}

//----------------------------------------------------------------------
// This function returns true if the selected key is currently 
// unpressed.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::KeyIsUp(EI_KEY someKey)
{
	return !(curKeyState[someKey] & 0x80);
}

//----------------------------------------------------------------------
// This function returns true if the selected key is currently 
// pressed AND was not pressed during the last keyboard update.
//----------------------------------------------------------------------
bool Ce1nInputDI8::Ce1nInputKeyboardDI8::KeyWasUp(EI_KEY someKey)
{
	return ((curKeyState[someKey] & 0x80) && !(lastKeyState[someKey] & 0x80));
}

