//////////////////////////////////////////////////////////
// eInInput.h - Interface file for the eInInput library.
// Part of the eIngine game engine.
//
// This class is used for dealing with all input related
// hardware access. It abstracts out the details of
// DirectInput and lets us get information from a 
// keyboard, mouse, or joystick.
//
// �2005 by Keith Goreham - www.goreham.com
//////////////////////////////////////////////////////////

#pragma once

//============================================================
// e1nInput constants:
//============================================================

//------------------------------------------------------------
// Keyboard Device Enumerations (Same as DirectInput):
//------------------------------------------------------------

// Enumeration type for the following key states:
#define EI_KEY    unsigned char

// Key States:
#define	EIK_ESCAPE		   0x01
#define	EIK_1              0x02
#define	EIK_2              0x03
#define	EIK_3              0x04
#define	EIK_4              0x05
#define	EIK_5              0x06
#define	EIK_6              0x07
#define	EIK_7              0x08
#define	EIK_8              0x09
#define	EIK_9              0x0A
#define	EIK_0              0x0B
#define	EIK_MINUS          0x0C             // - on main keyboard 
#define	EIK_EQUALS         0x0D
#define	EIK_BACK           0x0E             // backspace 
#define	EIK_TAB            0x0F
#define	EIK_Q              0x10
#define	EIK_W              0x11
#define	EIK_E              0x12
#define	EIK_R              0x13
#define	EIK_T              0x14
#define	EIK_Y              0x15
#define	EIK_U              0x16
#define	EIK_I              0x17
#define	EIK_O              0x18
#define	EIK_P              0x19
#define	EIK_LBRACKET       0x1A
#define	EIK_RBRACKET       0x1B
#define	EIK_RETURN         0x1C             // Enter on main keyboard 
#define	EIK_LCONTROL       0x1D
#define	EIK_A              0x1E
#define	EIK_S              0x1F
#define	EIK_D              0x20
#define	EIK_F              0x21
#define	EIK_G              0x22
#define	EIK_H              0x23
#define	EIK_J              0x24
#define	EIK_K              0x25
#define	EIK_L              0x26
#define	EIK_SEMICOLON      0x27
#define	EIK_APOSTROPHE     0x28
#define	EIK_GRAVE          0x29             // accent grave 
#define	EIK_LSHIFT         0x2A
#define	EIK_BACKSLASH      0x2B
#define	EIK_Z              0x2C
#define	EIK_X              0x2D
#define	EIK_C              0x2E
#define	EIK_V              0x2F
#define	EIK_B              0x30
#define	EIK_N              0x31
#define	EIK_M              0x32
#define	EIK_COMMA          0x33
#define	EIK_PERIOD         0x34             // . on main keyboard 
#define	EIK_SLASH          0x35             // / on main keyboard 
#define	EIK_RSHIFT         0x36
#define	EIK_MULTIPLY       0x37             // * on numeric keypad 
#define	EIK_LMENU          0x38             // left Alt 
#define	EIK_SPACE          0x39
#define	EIK_CAPITAL        0x3A
#define	EIK_F1             0x3B
#define	EIK_F2             0x3C
#define	EIK_F3             0x3D
#define	EIK_F4             0x3E
#define	EIK_F5             0x3F
#define	EIK_F6             0x40
#define	EIK_F7             0x41
#define	EIK_F8             0x42
#define	EIK_F9             0x43
#define	EIK_F10            0x44
#define	EIK_NUMLOCK        0x45
#define	EIK_SCROLL         0x46             // Scroll Lock 
#define	EIK_NUMPAD7        0x47
#define	EIK_NUMPAD8        0x48
#define	EIK_NUMPAD9        0x49
#define	EIK_SUBTRACT       0x4A             // - on numeric keypad 
#define	EIK_NUMPAD4        0x4B
#define	EIK_NUMPAD5        0x4C
#define	EIK_NUMPAD6        0x4D
#define	EIK_ADD            0x4E             // + on numeric keypad 
#define	EIK_NUMPAD1        0x4F
#define	EIK_NUMPAD2        0x50
#define	EIK_NUMPAD3        0x51
#define	EIK_NUMPAD0        0x52
#define	EIK_DECIMAL        0x53             // . on numeric keypad 
#define	EIK_OEM_102        0x56             // <> or \| on RT 102-key keyboard (Non-U.S.) 
#define	EIK_F11            0x57
#define	EIK_F12            0x58
#define	EIK_F13            0x64             //                     (NEC PC98) 
#define	EIK_F14            0x65             //                     (NEC PC98) 
#define	EIK_F15            0x66             //                     (NEC PC98) 
#define	EIK_KANA           0x70             // (Japanese keyboard)            
#define	EIK_ABNT_C1        0x73             // /? on Brazilian keyboard 
#define	EIK_CONVERT        0x79             // (Japanese keyboard)            
#define	EIK_NOCONVERT      0x7B             // (Japanese keyboard)            
#define	EIK_YEN            0x7D             // (Japanese keyboard)            
#define	EIK_ABNT_C2        0x7E             // Numpad . on Brazilian keyboard 
#define	EIK_NUMPADEQUALS   0x8D             // = on numeric keypad (NEC PC98) 
#define	EIK_PREVTRACK      0x90             // Previous Track (EIK_CIRCUMFLEX on Japanese keyboard) 
#define	EIK_AT             0x91             //                     (NEC PC98) 
#define	EIK_COLON          0x92             //                     (NEC PC98) 
#define	EIK_UNDERLINE      0x93             //                     (NEC PC98) 
#define	EIK_KANJI          0x94             // (Japanese keyboard)            
#define	EIK_STOP           0x95             //                     (NEC PC98) 
#define	EIK_AX             0x96             //                     (Japan AX) 
#define	EIK_UNLABELED      0x97             //                        (J3100) 
#define	EIK_NEXTTRACK      0x99             // Next Track 
#define	EIK_NUMPADENTER    0x9C             // Enter on numeric keypad 
#define	EIK_RCONTROL       0x9D
#define	EIK_MUTE           0xA0             // Mute 
#define	EIK_CALCULATOR     0xA1             // Calculator 
#define	EIK_PLAYPAUSE      0xA2             // Play / Pause 
#define	EIK_MEDIASTOP      0xA4             // Media Stop 
#define	EIK_VOLUMEDOWN     0xAE             // Volume - 
#define	EIK_VOLUMEUP       0xB0             // Volume + 
#define	EIK_WEBHOME        0xB2             // Web home 
#define	EIK_NUMPADCOMMA    0xB3             // , on numeric keypad (NEC PC98) 
#define	EIK_DIVIDE         0xB5             // / on numeric keypad 
#define	EIK_SYSRQ          0xB7
#define	EIK_RMENU          0xB8             // right Alt 
#define	EIK_PAUSE          0xC5             // Pause 
#define	EIK_HOME           0xC7             // Home on arrow keypad 
#define	EIK_UP             0xC8             // UpArrow on arrow keypad 
#define	EIK_PRIOR          0xC9             // PgUp on arrow keypad 
#define	EIK_LEFT           0xCB             // LeftArrow on arrow keypad 
#define	EIK_RIGHT          0xCD             // RightArrow on arrow keypad 
#define	EIK_END            0xCF             // End on arrow keypad 
#define	EIK_DOWN           0xD0             // DownArrow on arrow keypad 
#define	EIK_NEXT           0xD1             // PgDn on arrow keypad 
#define	EIK_INSERT         0xD2             // Insert on arrow keypad 
#define	EIK_DELETE         0xD3             // Delete on arrow keypad 
#define	EIK_LWIN           0xDB             // Left Windows key 
#define	EIK_RWIN           0xDC             // Right Windows key 
#define	EIK_APPS           0xDD             // AppMenu key 
#define	EIK_POWER          0xDE             // System Power 
#define	EIK_SLEEP          0xDF             // System Sleep 
#define	EIK_WAKE           0xE3             // System Wake 
#define	EIK_WEBSEARCH      0xE5             // Web Search 
#define	EIK_WEBFAVORITES   0xE6             // Web Favorites 
#define	EIK_WEBREFRESH     0xE7             // Web Refresh 
#define	EIK_WEBSTOP        0xE8             // Web Stop 
#define	EIK_WEBFORWARD     0xE9             // Web Forward 
#define	EIK_WEBBACK        0xEA             // Web Back 
#define	EIK_MYCOMPUTER     0xEB             // My Computer 
#define	EIK_MAIL           0xEC             // Mail 
#define	EIK_MEDIASELECT    0xED             // Media Select 

// Alternate names for keys already defined.
#define	EIK_BACKSPACE      EIK_BACK         // backspace 
#define	EIK_NUMPADSTAR     EIK_MULTIPLY     // * on numeric keypad 
#define	EIK_LALT           EIK_LMENU        // left Alt 
#define	EIK_CAPSLOCK       EIK_CAPITAL      // CapsLock 
#define	EIK_NUMPADMINUS    EIK_SUBTRACT     // - on numeric keypad 
#define	EIK_NUMPADPLUS     EIK_ADD          // + on numeric keypad 
#define	EIK_NUMPADPERIOD   EIK_DECIMAL      // . on numeric keypad 
#define	EIK_NUMPADSLASH    EIK_DIVIDE       // / on numeric keypad 
#define	EIK_RALT           EIK_RMENU        // right Alt 
#define	EIK_UPARROW        EIK_UP           // UpArrow on arrow keypad 
#define	EIK_PGUP           EIK_PRIOR        // PgUp on arrow keypad 
#define	EIK_LEFTARROW      EIK_LEFT         // LeftArrow on arrow keypad 
#define	EIK_RIGHTARROW     EIK_RIGHT        // RightArrow on arrow keypad 
#define	EIK_DOWNARROW      EIK_DOWN         // DownArrow on arrow keypad 
#define	EIK_PGDN           EIK_NEXT         // PgDn on arrow keypad

//------------------------------------------------------------
// Mouse Device Enumerations:
//------------------------------------------------------------

// Enumeration type for the following button states:
#define EI_MBUTTON			unsigned char

// Button States:
#define	EI_MOUSEBUTTON_1	0x01
#define	EI_MOUSEBUTTON_2	0x02
#define	EI_MOUSEBUTTON_3	0x04
#define	EI_MOUSEBUTTON_4	0x08

// Axis States:
#define	EI_MOUSEAXIS_X		0x10
#define	EI_MOUSEAXIS_Y		0x20
#define EI_MOUSEAXIS_Z		0x40		// Mouse Wheel

// Mouse Exclusivity Options:
#define EI_MOUSEMODE			bool
#define EI_MOUSE_EXCLUSIVE		true
#define EI_MOUSE_NONEXCLUSIVE	false

//------------------------------------------------------------
// Joystick Device Enumerations:
//------------------------------------------------------------

// Enumeration type for the following button states:
#define EI_JOYBUTTON		unsigned int

// Button States (Generic):
#define	EI_JOYBUTTON_1			0x00000001
#define	EI_JOYBUTTON_2			0x00000002
#define	EI_JOYBUTTON_3			0x00000004
#define	EI_JOYBUTTON_4			0x00000008
#define	EI_JOYBUTTON_5			0x00000010
#define	EI_JOYBUTTON_6			0x00000020
#define	EI_JOYBUTTON_7			0x00000040
#define	EI_JOYBUTTON_8			0x00000080
#define	EI_JOYBUTTON_9			0x00000100
#define	EI_JOYBUTTON_10			0x00000200
#define	EI_JOYBUTTON_11			0x00000400	
#define	EI_JOYBUTTON_12			0x00000800
#define	EI_JOYBUTTON_13			0x00001000
#define	EI_JOYBUTTON_14			0x00002000
#define	EI_JOYBUTTON_15			0x00004000
#define	EI_JOYBUTTON_16			0x00008000

// Button States (XBOX 360 Controller Specific):
#define	EI_JOYBUTTON_A			0x00000001
#define	EI_JOYBUTTON_B			0x00000002
#define	EI_JOYBUTTON_X			0x00000004
#define	EI_JOYBUTTON_Y			0x00000008
#define	EI_JOYBUTTON_LB			0x00000010
#define	EI_JOYBUTTON_RB			0x00000020
#define	EI_JOYBUTTON_BACK		0x00000040
#define	EI_JOYBUTTON_START		0x00000080
#define	EI_JOYBUTTON_LTHUMB		0x00000100
#define	EI_JOYBUTTON_RTHUMB		0x00000200
#define EI_JOYBUTTON_LTRIGGER	0x00100000
#define EI_JOYBUTTON_RTRIGGER	0x00200000

// Analog Axis States (Generic):
#define	EI_JOYAXIS_1			0x00010000
#define	EI_JOYAXIS_2			0x00020000	
#define	EI_JOYAXIS_3			0x00040000
#define	EI_JOYAXIS_4			0x00080000
#define EI_JOYAXIS_5			0x00100000
#define EI_JOYAXIS_6			0x00200000
#define EI_JOYAXIS_7			0x00400000
#define EI_JOYAXIS_8			0x00800000

// Analog Axis States (XBOX 360 Controller Specific):	
#define	EI_JOYAXIS_LX			0x00010000
#define	EI_JOYAXIS_LY			0x00020000
#define EI_JOYAXIS_RX			0x00040000
#define EI_JOYAXIS_RY			0x00080000
#define	EI_JOYAXIS_LTRIGGER		0x00100000
#define	EI_JOYAXIS_RTRIGGER		0x00200000

// POV Hat States:
#define	EI_JOYPOV_UP			0x01000000
#define	EI_JOYPOV_UPRIGHT		0x02000000
#define	EI_JOYPOV_RIGHT			0x04000000
#define	EI_JOYPOV_DOWNRIGHT		0x08000000
#define	EI_JOYPOV_DOWN			0x10000000
#define	EI_JOYPOV_DOWNLEFT		0x20000000
#define	EI_JOYPOV_LEFT			0x40000000
#define	EI_JOYPOV_UPLEFT		0x80000000

//------------------------------------------------------------
// Other Enumerations:
//------------------------------------------------------------

#define CAPMOUSE_DEFAULT	false

#define MAX_EIJOYS			4			// The maximum number of joysticks that e1nInput will support.
#define MAX_EIAXIS			6			// The maximum number of joystick axis that e1nInput will support.

#define EI_JOYENUM			UINT
#define EI_JOY1				0
#define EI_JOY2				1
#define EI_JOY3				2
#define EI_JOY4				3

#define EI_JOY_DEADZONE  0.14

#define EI_INTERFACE		UINT
#define EI_DIRECTINPUT8		8000
#define EI_DIJOY			8000		// Enumeration for DirectInput Joystick Interface (Not implemented yet.)
#define EI_XIJOY			1111		// Enumeration for XInput Joytick Interface (XBOX 360 Controllers).

//============================================================
// e1nInput interface class:
//============================================================

// e1nInput Interface class:
typedef class Ie1nInput
{
public:
	// Nested Member Class Definitions:
	class Ie1nInputKeyboard					// Keyboard Class
	{
	public:
		
		virtual bool Aquire(void)   = 0;					// Keyboard Aquisition Function
		virtual bool Unaquire(void) = 0;					// Keyboard Un-Aquisition Function
		virtual bool Update(void)   = 0;					// Keyboard Processing Function

		// Keyboard Polling Functions:
		virtual bool KeyIsDown (EI_KEY someKey) = 0;
		virtual bool KeyWasDown(EI_KEY someKey) = 0;
		virtual bool KeyIsUp   (EI_KEY someKey) = 0;
		virtual bool KeyWasUp  (EI_KEY someKey) = 0;
	};

	class Ie1nInputMouse					// Mouse Class
	{
	public:

		virtual bool Aquire(EI_MOUSEMODE someMode) = 0;		// Mouse Aquisition Function
		virtual bool Unaquire(void) = 0;					// Mouse Un-Aquisition Function
		virtual bool Update(void)   = 0;					// Mouse Processing Function

		// Mouse Polling Functions:
		virtual bool ButtonIsDown (EI_MBUTTON someButton) = 0;
		virtual bool ButtonWasDown(EI_MBUTTON someButton) = 0;
		virtual bool ButtonIsUp   (EI_MBUTTON someButton) = 0;
		virtual bool ButtonWasUp  (EI_MBUTTON someButton) = 0;
		virtual bool AxisIsActive (EI_MBUTTON someAxis)   = 0;
		virtual bool AxisWasActive(EI_MBUTTON someAxis)   = 0;
		virtual int  getAxisValue (EI_MBUTTON someAxis)   = 0;
	};

	class Ie1nInputJoysticks					// Joystick Class
	{
	public:

		virtual bool Aquire  () = 0;				// Joystick Aquisition Function
		virtual bool Unaquire() = 0;				// Joystick Un-Aquisition Function
		virtual bool Update  () = 0;				// Joystick Processing Function

		virtual bool JoystickIsActive (EI_JOYENUM someJoy)	= 0;
		virtual bool JoystickWasActive(EI_JOYENUM someJoy)	= 0;

		// Joystick Polling Functions:
		virtual bool  ButtonIsDown     (EI_JOYENUM someJoy, EI_JOYBUTTON someButton) = 0;
		virtual bool  ButtonWasDown    (EI_JOYENUM someJoy, EI_JOYBUTTON someButton) = 0;
		virtual bool  ButtonIsUp       (EI_JOYENUM someJoy, EI_JOYBUTTON someButton) = 0;
		virtual bool  ButtonWasUp      (EI_JOYENUM someJoy, EI_JOYBUTTON someButton) = 0;
		virtual bool  AxisIsActive     (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)   = 0;
		virtual bool  AxisWasActive    (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)   = 0;
		virtual float GetAxisValue     (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis)   = 0;
		
		virtual UINT GetNumAttachedJoysticks(void) = 0;
		virtual UINT GetJoyName(EI_JOYENUM whichJoy, char* outString) = 0;
	};

	// Nested Member Class Declarations:
	Ie1nInputKeyboard*  p_keyboard;						// Keyboard Object Pointer
	Ie1nInputMouse*	    p_mouse;						// Mouse Object Pointer
	Ie1nInputJoysticks* p_controllers;					// Joystick Object Pointer

} eINPUTDEVICE;

//============================================================
// Non-member functions:
//============================================================

// This function creates the e1nInput object for DirectInput and returns a pointer to it.
//eINPUTDEVICE* e1nInputCreate(HINSTANCE		p_hInstance,			// Pointer to main application instance.
//							 HWND			p_hWndMain,				// Pointer to the main application window handle.
//							 EI_INTERFACE	eiInterface,			// Implementation to use. EI_DIRECTINPUT8 is the only choice so far.
//							 EI_INTERFACE   eiJoyInterface);		// Joystick Implementation to use. EI_XIJOY (XBOX 360 Controllers) is the only choice so far.




