#include "StdAfx.h"
#include "e1nInput.h"
#include "e1nInputDI8.h"

// Global Variables:
extern HWND				gp_appWinHandle;
extern LPDIRECTINPUT8	gp_dInput;

//============================================================
// Nested Mouse Class Functions:
//============================================================

// Constructor:
Ce1nInputDI8::Ce1nInputMouseDI8::Ce1nInputMouseDI8(void)
{
	// Set the exclusivity mode.
	isMouseExclusive = false;

	// Initialize the Mouse.
	Ce1nInputDI8::Ce1nInputMouseDI8::Init(isMouseExclusive);

	// Aquire the Mouse.
	Ce1nInputDI8::Ce1nInputMouseDI8::Aquire(isMouseExclusive);

	// Ok, now we zero out the memory for the mouse states.
	ZeroMemory(&curMouseState,  sizeof(DIMOUSESTATE));
	ZeroMemory(&lastMouseState, sizeof(DIMOUSESTATE));
}

// Destructor
Ce1nInputDI8::Ce1nInputMouseDI8::~Ce1nInputMouseDI8(void)
{
	if (p_mouse	   != NULL) {p_mouse->Unacquire();}	
	if (p_mouse	   != NULL) {p_mouse->Release();}
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::Init(EI_MOUSEMODE someMode)
{
	HRESULT hr;			// Result variable for error checking.

	// Create the mouse device:
	hr = gp_dInput->CreateDevice(GUID_SysMouse, &p_mouse, NULL);
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not create mouse device.\n");
		return false;
	}

	// Set the Data Format of the Mouse:
	hr = p_mouse->SetDataFormat(&c_dfDIMouse);
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not set mouse data format.\n");
		return false;
	}

	// Set the mouse cooperation level:
	hr = p_mouse->SetCooperativeLevel(gp_appWinHandle, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE);
	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not set mouse cooperation level.\n");
		return false;
	}

	return true;
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::Aquire(EI_MOUSEMODE someMode)
{
	HRESULT hr;

	if (isMouseExclusive != someMode)
	{
		isMouseExclusive = someMode;

		switch (isMouseExclusive)
		{
		case true:
			{
				p_mouse->SetCooperativeLevel(gp_appWinHandle, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
				break;
			}
		case false:
			{
				p_mouse->SetCooperativeLevel(gp_appWinHandle, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
				break;
			}
		}
	}

	if (p_mouse != NULL) 
	{
		hr = p_mouse->Acquire();					// Aquire Mouse.
		if (FAILED(hr))
		{
			OutputDebugString("ERROR! - Could not Aquire Mouse.\n");
			return false;
		}
	}

	return true;
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::Unaquire(void)
{
	if (p_mouse != NULL) 
	{
		p_mouse->Unacquire();
	}

	return true;
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::Update(void)
{
	HRESULT hr;						// Result variable for error catching.
	DIMOUSESTATE tmpMouseState;		

	hr = p_mouse->GetDeviceState(sizeof(DIMOUSESTATE), (LPVOID)&tmpMouseState);

	if (FAILED(hr))		// If we didn't get the data...
	{
		switch(hr)
		{
		case DIERR_INPUTLOST:
			p_mouse->Acquire();
			p_mouse->GetDeviceState(sizeof(DIMOUSESTATE), (LPVOID) &tmpMouseState);
			break;
		case DIERR_NOTACQUIRED:
			p_mouse->Acquire();
			p_mouse->GetDeviceState(sizeof(DIMOUSESTATE), (LPVOID) &tmpMouseState);
			break;
		case DIERR_NOTINITIALIZED:
			Init(isMouseExclusive);
			p_mouse->Acquire();
			break;
		}
	}
	else
	{
		lastMouseState = curMouseState;
		curMouseState  = tmpMouseState;
	}

	return true;
}

//------------------------------------------------------------
// Function for setting the current mouse input mode.
//------------------------------------------------------------
//inline void SetMouseInputMode(const eMOUSEMODE &someMode)
//{
//	if (someMode == MOUSEMODE_SHARED)
//	{
//		p_mouse->Unacquire();
//		p_mouse->SetCooperativeLevel(g_hWndMain, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
//		p_mouse->Acquire();
//
//		mouseMode = MOUSEMODE_SHARED;
//	}
//	else if (someMode == MOUSEMODE_EXCLUSIVE)
//	{
//		p_mouse->Unacquire();
//		p_mouse->SetCooperativeLevel(g_hWndMain, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
//		p_mouse->Acquire();
//
//		mouseMode = MOUSEMODE_EXCLUSIVE;
//	}
//}


int Ce1nInputDI8::Ce1nInputMouseDI8::getAxisValue(EI_MBUTTON someAxis)
{
	//if (someAxis == MOUSE_AXIS_X)
	//{
	//	return mouseAxis.x;
	//}
	//else if (someAxis == MOUSE_AXIS_Y)
	//{
	//	return mouseAxis.y;
	//}
	//else if (someAxis == MOUSE_AXIS_Z)
	//{
	//	return mouseAxis.z;
	//}

	return 0;
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::ButtonIsDown(EI_MBUTTON someButton)
{
	return (bool)(curMouseState.rgbButtons[someButton] & 0x80);
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::ButtonWasDown(EI_MBUTTON someButton)
{
	return (bool)(!(curMouseState.rgbButtons[someButton] & 0x80) && (lastMouseState.rgbButtons[someButton] & 0x80));
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::ButtonIsUp(EI_MBUTTON someButton)
{
	return (bool)!(curMouseState.rgbButtons[someButton] & 0x80);
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::ButtonWasUp(EI_MBUTTON someButton)
{
	return (bool)((curMouseState.rgbButtons[someButton] & 0x80) && !(lastMouseState.rgbButtons[someButton] & 0x80));
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::AxisIsActive(EI_MBUTTON someAxis)
{
	return true;
}

bool Ce1nInputDI8::Ce1nInputMouseDI8::AxisWasActive(EI_MBUTTON someAxis)
{
	return true;
}

