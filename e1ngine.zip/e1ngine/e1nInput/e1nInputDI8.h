#pragma once
#include "e1nInput.h"
#include "StdAfx.h"						// Precompiled headers.



typedef UCHAR DI_KEYSTATE[256];

// The Class
class Ce1nInputDI8 : public Ie1nInput
{
	// Initialization Function
	bool Init(void);

public:
	// Input Class Constructor
	Ce1nInputDI8(HINSTANCE &p_ai,					// Pointer to the application instance.
				 HWND      &p_awh,					// Pointer to the application window.
				 bool	   startMouseExclusive);	// Whether we want the mouse to start out exclusive or not.
	// Input Class Destructor
	~Ce1nInputDI8(void);

	// Nested member class definitions:
	class Ce1nInputKeyboardDI8 :  public Ie1nInput::Ie1nInputKeyboard
	{
	private:
		Ce1nInputDI8* parent;

		LPDIRECTINPUTDEVICE8 p_keyboard;		// Pointer to our keyboard device.
		DI_KEYSTATE			 curKeyState;		// Array to hold the current state of the keyboard keys.
		DI_KEYSTATE			 lastKeyState;		// Array to hold the last state of the keyboard keys.

		bool Init(void);						// Initialization Function.

	public:
		 Ce1nInputKeyboardDI8(void);			// Keyboard Constructor
		~Ce1nInputKeyboardDI8(void);			// Keyboard Destructor

		bool Aquire(void);						// Keyboard Aquisition Function
		bool Unaquire(void);					// Keyboard Un-Aquisition Function
		bool Update(void);						// Keyboard Processing Function

		// Keyboard Polling Functions:
		bool KeyIsDown (EI_KEY someKey);
		bool KeyWasDown(EI_KEY someKey);
		bool KeyIsUp   (EI_KEY someKey);
		bool KeyWasUp  (EI_KEY someKey);
	};

	class Ce1nInputMouseDI8 : public Ie1nInputMouse
	{
	private:
		LPDIRECTINPUTDEVICE8 p_mouse;			// Pointer to our DInput mouse device.
		DIMOUSESTATE		 curMouseState;		// Holds the current state of the mouse.
		DIMOUSESTATE		 lastMouseState;	// Holds the mouse state from the last test.
		bool				 isMouseExclusive;  // Stores whether the mouse is exclusive or not.

		bool Init(EI_MOUSEMODE someMode);		// Initialization Function.

	public:
		 Ce1nInputMouseDI8();					// Mouse Constructor
		~Ce1nInputMouseDI8(void);				// Mouse Destructor
						
		bool Aquire(EI_MOUSEMODE someMode);		// Mouse Aquisition Function
		bool Unaquire(void);					// Mouse Un-Aquisition Function
		bool Update(void);						// Mouse Processing Function

		// Mouse Polling Functions:
		bool ButtonIsDown (EI_MBUTTON someButton);
		bool ButtonWasDown(EI_MBUTTON someButton);
		bool ButtonIsUp   (EI_MBUTTON someButton);
		bool ButtonWasUp  (EI_MBUTTON someButton);
		bool AxisIsActive (EI_MBUTTON someAxis);
		bool AxisWasActive(EI_MBUTTON someAxis);
		int  getAxisValue (EI_MBUTTON someAxis);
	};

	class Ce1nInputJoysticksXI : public Ie1nInputJoysticks
	{
	private:

		// First our struct to hold the XInput joystick states.
		typedef struct SXIControllerState
		{
			XINPUT_STATE joyState;
			XINPUT_STATE joyStateLast;
			bool		 isConnected;
			bool		 wasConnected;
		}EIXI_CONTROLLER_STATE;

		// Private Member Variables:
		EIXI_CONTROLLER_STATE	xiStates[MAX_EIJOYS];		// Array of structs to hold our XInput Joystick States.

	public:
		// Constructor/Destructor
		Ce1nInputJoysticksXI(void);						
		~Ce1nInputJoysticksXI(void);								

		// Maintainence Functions:
		bool Aquire  ();				// Joystick Aquisition Function
		bool Unaquire();				// Joystick Un-Aquisition Function
		bool Update  ();				// Joystick Processing Function

		bool JoystickIsActive (EI_JOYENUM someJoy);
		bool JoystickWasActive(EI_JOYENUM someJoy);

		// Joystick Polling Functions:
		bool  ButtonIsDown (EI_JOYENUM someJoy, EI_JOYBUTTON someButton);
		bool  ButtonWasDown(EI_JOYENUM someJoy, EI_JOYBUTTON someButton);
		bool  ButtonIsUp   (EI_JOYENUM someJoy, EI_JOYBUTTON someButton);
		bool  ButtonWasUp  (EI_JOYENUM someJoy, EI_JOYBUTTON someButton);
		bool  AxisIsActive (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis);
		bool  AxisWasActive(EI_JOYENUM someJoy, EI_JOYBUTTON someAxis);
		float GetAxisValue (EI_JOYENUM someJoy, EI_JOYBUTTON someAxis);
		
		UINT GetNumAttachedJoysticks();
		UINT GetJoyName(EI_JOYENUM whichJoy, char* outString);
	};
};