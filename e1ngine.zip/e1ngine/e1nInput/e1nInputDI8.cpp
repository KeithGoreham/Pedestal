#pragma once

#include "StdAfx.h"
#include "e1nInput.h"
#include "e1nInputDI8.h"

//// Global Variables:
HINSTANCE		gp_appInstance;
HWND			gp_appWinHandle;
LPDIRECTINPUT8	gp_dInput;

//============================================================
// Base e1nInput DirectInput 8 Class Functions:
//============================================================

// Constructor:
Ce1nInputDI8::Ce1nInputDI8(HINSTANCE &p_ai,						// Pointer to the application instance.
						   HWND      &p_awh,					// Pointer to the application window.
						   bool		 startMouseExclusive)		// Whether we want the mouse to start out exclusive or not.
{
	gp_appInstance  = p_ai;
	gp_appWinHandle = p_awh;

	Init();
	
	// Then we intialize the keyboard, mouse, and game controller objects.
	p_keyboard    = new Ce1nInputDI8::Ce1nInputKeyboardDI8;
	p_mouse       = new Ce1nInputDI8::Ce1nInputMouseDI8;
	p_controllers = new Ce1nInputDI8::Ce1nInputJoysticksXI;
}

// Destructor
Ce1nInputDI8::~Ce1nInputDI8(void)
{
	// Lastly, we clean up our device objects and null out the pointers.
	if (p_controllers != NULL){delete p_controllers; p_controllers = NULL;}
	if (p_mouse       != NULL){delete p_mouse;	     p_mouse       = NULL;}
	if (p_keyboard    != NULL){delete p_keyboard;    p_keyboard    = NULL;}
}

// Initialization Function
bool Ce1nInputDI8::Init(void)
{
	// First off we init our directInput interface.
	HRESULT hr = 0;			// Result variable for error catching.

	// Release any previous objects if they exist:
	if (gp_dInput != NULL) {gp_dInput->Release();}

	// Create the DirectInput8 object:
	hr = DirectInput8Create(gp_appInstance,			// Handle to application window.
							DIRECTINPUT_VERSION,	// Specifies that we want the latest version of DirectInput.
							IID_IDirectInput8,		// Interface identifier for the com object.
							(void**)&gp_dInput,		// The address of the pointer we'll use to reference this object.
							NULL);					// Used for com aggregation (ignore).

	if (FAILED(hr))
	{
		OutputDebugString("ERROR! - Could not intialize DirectInput\n");
		return false;
	}

	return true;
}

