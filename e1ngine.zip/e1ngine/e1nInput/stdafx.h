// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

#pragma once

// Windows include files:
#include <windows.h>

// Other Defines.
#define WIN32_LEAN_AND_MEAN			// Leaves out the Microsoft Foundation Classes.
#define WIN32_EXTRA_LEAN			// Leaves out other Windows crap we don't need.
#define INITGUID					// Includes all GUIDs for input devices.

// Standard C++ non-system include files:
#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <fstream>

// Windows API headers:
#include <windows.h>
#include <Commdlg.h>					// Common Dialog Boxes.

// DirectX Version Defines:
#define DIRECTINPUT_VERSION 0x0800

// DirectX Include Files:
#include <dinput.h>
#include <objbase.h>					// Needed for Input Device GUID definitions.

// xInput Include Files (for XBOX 360 Compliant Controllers):
#include <XInput.h>

// e1ngine include files:
#include "..\e1nMath\e1nMath.h"





// TODO: reference additional headers your program requires here
